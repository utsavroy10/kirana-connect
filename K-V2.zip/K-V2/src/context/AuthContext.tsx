'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserRole, User } from '@/types';
import { auth } from '@/lib/firebaseClient';
import { onAuthStateChanged, signOut as fbSignOut } from 'firebase/auth';

interface AuthContextType {
  user: User | null;
  role: UserRole;
  token: string | null;
  loading: boolean;
  loginWithDemo: (role: UserRole, phone?: string, storeId?: string) => void;
  syncFirebaseUser: (firebaseUser: any) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  role: 'customer',
  token: null,
  loading: true,
  loginWithDemo: () => {},
  syncFirebaseUser: async () => {},
  logout: () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<UserRole>('customer');
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Restore saved POC session or Firebase state on mount
  useEffect(() => {
    const isDemoEnabled = process.env.NEXT_PUBLIC_ENABLE_DEMO === 'true';
    const savedToken = localStorage.getItem('kc_auth_token');
    const savedUser = localStorage.getItem('kc_auth_user');

    if (savedToken && savedToken.startsWith('DEMO_TOKEN_') && !isDemoEnabled) {
      localStorage.removeItem('kc_auth_token');
      localStorage.removeItem('kc_auth_user');
      setUser(null);
      setToken(null);
      setRole('customer');
    } else if (savedToken && savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
        setRole(parsedUser.role || 'customer');
        setToken(savedToken);
        setLoading(false);
        return;
      } catch (e) {
        console.error('Failed to parse saved user');
      }
    }

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const idToken = await fbUser.getIdToken();
        setToken(idToken);
        await syncFirebaseUser(fbUser);
      } else {
        if (!savedToken) {
          setUser(null);
          setToken(null);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const syncFirebaseUser = async (fbUser: any) => {
    try {
      const idToken = await fbUser.getIdToken();
      setToken(idToken);
      localStorage.setItem('kc_auth_token', idToken);

      const res = await fetch('/api/auth/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${idToken}`,
        },
        body: JSON.stringify(
          fbUser.displayName && fbUser.displayName.trim()
            ? { name: fbUser.displayName.trim() }
            : {}
        ),
      });

      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
        setRole(data.user.role);
        localStorage.setItem('kc_auth_user', JSON.stringify(data.user));
      }
    } catch (err) {
      console.error('Error syncing user:', err);
    }
  };

  const loginWithDemo = (selectedRole: UserRole, phone?: string, storeId?: string) => {
    const demoToken = `DEMO_TOKEN_${selectedRole.toUpperCase()}`;
    const demoUser: User = {
      uid: `demo_${selectedRole}_uid`,
      phone: phone || (selectedRole === 'merchant' ? '+919876543210' : selectedRole === 'admin' ? '+919999999999' : '+919811122233'),
      name: selectedRole === 'merchant' ? 'Ram Prasad (Gupta Kirana)' : selectedRole === 'admin' ? 'Kirana Connect Ops Admin' : 'Aman Sharma',
      role: selectedRole,
      storeId: selectedRole === 'merchant' ? (storeId || 'store_shree_ram') : undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setUser(demoUser);
    setRole(selectedRole);
    setToken(demoToken);
    localStorage.setItem('kc_auth_token', demoToken);
    localStorage.setItem('kc_auth_user', JSON.stringify(demoUser));
  };

  const logout = async () => {
    try {
      await fbSignOut(auth);
    } catch (e) {}
    setUser(null);
    setToken(null);
    setRole('customer');
    localStorage.removeItem('kc_auth_token');
    localStorage.removeItem('kc_auth_user');
  };

  return (
    <AuthContext.Provider value={{ user, role, token, loading, loginWithDemo, syncFirebaseUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
