import { Store, StoreProduct, PickupSlot } from '@/types';

export const INITIAL_STORES: Store[] = [
  {
    id: 'store_shree_ram',
    name: 'Gupta Kirana & General Store',
    tagline: 'Fresh staples, spices, pulses & daily essentials since 1998',
    merchantUid: 'demo_merchant_uid',
    ownerName: 'Ram Prasad Gupta',
    phone: '+919876543210',
    location: {
      address: 'Shop No. 12, Main Market, Rajwada Chowk',
      area: 'Rajwada',
      city: 'Indore',
      pincode: '452001',
      landmark: 'Opposite Old Clock Tower',
      lat: 22.7196,
      lng: 75.8577,
    },
    categories: ['Atta & Flour', 'Rice & Pulses', 'Cooking Oils', 'Spices & Masalas', 'Dairy & Bakery', 'Snacks'],
    bannerImage: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=800&auto=format&fit=crop&q=80',
    isOpen: true,
    openingTime: '07:30 AM',
    closingTime: '09:30 PM',
    isVerified: true,
    commissionRate: 3.5,
    rating: 4.8,
    totalOrdersCompleted: 142,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'store_balaji_provision',
    name: 'Sri Balaji Provision Store',
    tagline: 'Best quality grains, ghee, dry fruits & cleaning items',
    merchantUid: 'demo_merchant_balaji',
    ownerName: 'Venkatesh Rao',
    phone: '+919845012345',
    location: {
      address: 'Plot 45, Station Road, Near Shiv Temple',
      area: 'Sigra',
      city: 'Varanasi',
      pincode: '221002',
      landmark: 'Near Kashi Sweets',
      lat: 25.3176,
      lng: 82.9739,
    },
    categories: ['Rice & Pulses', 'Pure Desi Ghee', 'Dry Fruits', 'Beverages', 'Pooja Items'],
    bannerImage: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&auto=format&fit=crop&q=80',
    isOpen: true,
    openingTime: '08:00 AM',
    closingTime: '10:00 PM',
    isVerified: true,
    commissionRate: 3.5,
    rating: 4.6,
    totalOrdersCompleted: 98,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'store_sharma_daily',
    name: 'Sharma Daily Essentials',
    tagline: 'Quick pack & pick kirana store for all your kitchen needs',
    merchantUid: 'demo_merchant_sharma',
    ownerName: 'Dinesh Sharma',
    phone: '+919829034567',
    location: {
      address: 'Shop 4, Bapu Bazaar Main Line',
      area: 'Bapu Nagar',
      city: 'Jaipur',
      pincode: '302015',
      landmark: 'Behind Gandhi Circle',
      lat: 26.9124,
      lng: 75.7873,
    },
    categories: ['Atta & Flour', 'Spices & Masalas', 'Tea & Coffee', 'Biscuits & Cookies', 'Personal Care'],
    bannerImage: 'https://images.unsplash.com/photo-1604719312566-8912e9227c6a?w=800&auto=format&fit=crop&q=80',
    isOpen: true,
    openingTime: '07:00 AM',
    closingTime: '09:00 PM',
    isVerified: true,
    commissionRate: 3.5,
    rating: 4.7,
    totalOrdersCompleted: 215,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

export const INITIAL_PRODUCTS: StoreProduct[] = [
  // Products for Gupta Kirana
  {
    id: 'prod_aashirvaad_atta_5kg',
    storeId: 'store_shree_ram',
    name: 'Aashirvaad Shudh Chakki Atta',
    hindiName: 'आशीर्वाद आटा',
    brand: 'Aashirvaad',
    category: 'Atta & Flour',
    price: 245,
    mrp: 275,
    unit: '5 kg',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&auto=format&fit=crop&q=80',
    description: '100% pure whole wheat flour, fiber rich, soft rotis guaranteed.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_fortune_mustard_oil_1l',
    storeId: 'store_shree_ram',
    name: 'Fortune Kachi Ghani Pure Mustard Oil',
    hindiName: 'फॉर्च्यून सरसों का तेल',
    brand: 'Fortune',
    category: 'Cooking Oils',
    price: 155,
    mrp: 175,
    unit: '1 Litre Pouch',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&auto=format&fit=crop&q=80',
    description: 'Traditional cold pressed aroma and pungency for authentic taste.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_tata_sampann_toordal_1kg',
    storeId: 'store_shree_ram',
    name: 'Tata Sampann Unpolished Toor Dal',
    hindiName: 'अरहर / तुअर दाल',
    brand: 'Tata Sampann',
    category: 'Rice & Pulses',
    price: 180,
    mrp: 198,
    unit: '1 kg',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1585994407008-0db4c6a6f115?w=400&auto=format&fit=crop&q=80',
    description: 'Unpolished protein rich toor dal with natural taste.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_india_gate_basmati_1kg',
    storeId: 'store_shree_ram',
    name: 'India Gate Basmati Rice Feast Rozzana',
    hindiName: 'बासमती चावल',
    brand: 'India Gate',
    category: 'Rice & Pulses',
    price: 110,
    mrp: 130,
    unit: '1 kg',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&auto=format&fit=crop&q=80',
    description: 'Fragrant long grain rice suitable for daily pulao and meals.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_mdh_garam_masala_100g',
    storeId: 'store_shree_ram',
    name: 'MDH Garam Masala Powder',
    hindiName: 'एमडीएच गरम मसाला',
    brand: 'MDH',
    category: 'Spices & Masalas',
    price: 92,
    mrp: 100,
    unit: '100 g',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=400&auto=format&fit=crop&q=80',
    description: 'Blend of rare aromatic spices for curries and vegetables.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_amul_butter_500g',
    storeId: 'store_shree_ram',
    name: 'Amul Butter (Pasteurised)',
    hindiName: 'अमूल बटर मक्खन',
    brand: 'Amul',
    category: 'Dairy & Bakery',
    price: 275,
    mrp: 285,
    unit: '500 g',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=400&auto=format&fit=crop&q=80',
    description: 'Delicious utterly butterly Amul butter block.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_parle_g_gold_1kg',
    storeId: 'store_shree_ram',
    name: 'Parle-G Gold Glucose Biscuits Family Pack',
    hindiName: 'पारले-जी गोल्ड बिस्कुट',
    brand: 'Parle',
    category: 'Snacks',
    price: 120,
    mrp: 135,
    unit: '1 kg',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&auto=format&fit=crop&q=80',
    description: 'Classic tea companion, fortified with milk and wheat goodness.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'prod_tata_tea_gold_500g',
    storeId: 'store_shree_ram',
    name: 'Tata Tea Gold Leaf & Long Leaves',
    hindiName: 'टाटा टी गोल्ड चायपत्ती',
    brand: 'Tata Tea',
    category: 'Beverages',
    price: 310,
    mrp: 350,
    unit: '500 g',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=400&auto=format&fit=crop&q=80',
    description: 'Rich taste with irresistible long leaf aroma.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

const IST_TIME_ZONE = 'Asia/Kolkata';
const IST_OFFSET_MS = 5.5 * 60 * 60 * 1000; // India has no DST: fixed UTC+05:30

/** Calendar date (year, month 1-12, day) of the given instant in Asia/Kolkata. */
const getIstDateParts = (instant: Date): { year: number; month: number; day: number } => {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: IST_TIME_ZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(instant);
  const pick = (type: string) => Number(parts.find(p => p.type === type)?.value);
  return { year: pick('year'), month: pick('month'), day: pick('day') };
};

export const generatePickupSlots = (now = new Date()): PickupSlot[] => {
  const dateStr = 'Today';
  const cutoff = new Date(now.getTime() + 30 * 60 * 1000);
  const istToday = getIstDateParts(now);

  const timeRanges = [
    { id: 'slot_1', label: `${dateStr}, 04:00 PM - 05:00 PM`, timeRange: '04:00 PM - 05:00 PM', startHour: 16, isTomorrow: false },
    { id: 'slot_2', label: `${dateStr}, 05:00 PM - 06:00 PM`, timeRange: '05:00 PM - 06:00 PM', startHour: 17, isTomorrow: false },
    { id: 'slot_3', label: `${dateStr}, 06:00 PM - 07:00 PM`, timeRange: '06:00 PM - 07:00 PM', startHour: 18, isTomorrow: false },
    { id: 'slot_4', label: `${dateStr}, 07:00 PM - 08:00 PM`, timeRange: '07:00 PM - 08:00 PM', startHour: 19, isTomorrow: false },
    { id: 'slot_5', label: `${dateStr}, 08:00 PM - 09:00 PM`, timeRange: '08:00 PM - 09:00 PM', startHour: 20, isTomorrow: false },
    { id: 'slot_tomorrow_morn', label: `Tomorrow Morning, 08:00 AM - 10:00 AM`, timeRange: '08:00 AM - 10:00 AM', startHour: 8, isTomorrow: true },
  ];

  return timeRanges.map(t => {
    // Slot start instant = startHour:00 IST on the IST date (Date.UTC normalises day overflow).
    const dayOffset = t.isTomorrow ? 1 : 0;
    const slotStart = new Date(
      Date.UTC(istToday.year, istToday.month - 1, istToday.day + dayOffset, t.startHour, 0, 0, 0) - IST_OFFSET_MS
    );

    const isExpired = slotStart.getTime() <= cutoff.getTime();

    return {
      id: t.id,
      label: t.label,
      timeRange: t.timeRange,
      date: t.isTomorrow ? 'Tomorrow' : dateStr,
      isAvailable: !isExpired,
      ...(isExpired ? { reason: 'SLOT_EXPIRED' } : {}),
    };
  });
};
