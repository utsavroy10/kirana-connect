export const ALLOWED_PRODUCT_CATEGORIES = [
  'Atta & Flour',
  'Rice & Pulses',
  'Cooking Oils & Ghee',
  'Spices & Masalas',
  'Dairy & Eggs',
  'Snacks & Packaged Food',
  'Beverages',
  'Personal Care',
  'Cleaning & Household',
  'General Grocery',
] as const;

export type ProductCategory = (typeof ALLOWED_PRODUCT_CATEGORIES)[number];
