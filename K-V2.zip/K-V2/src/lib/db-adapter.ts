import 'server-only';
import { connectToDatabase } from './mongodb';
import { INITIAL_STORES, INITIAL_PRODUCTS } from './mock-data';
import { DatabaseUnavailableError } from './apiErrors';
import { Store, StoreProduct, Order, User, Cart, OrderStatus } from '@/types';
import type { Db } from 'mongodb';

// In-memory fallback caches. Used ONLY in development when MongoDB cannot be reached
// (never in production, and never in addition to a Mongo operation).
let memoryStores: Store[] = [...INITIAL_STORES];
let memoryProducts: StoreProduct[] = [...INITIAL_PRODUCTS];
let memoryOrders: Order[] = [];
let memoryUsers: User[] = [];
let memoryCarts: Record<string, Cart> = {};

/**
 * Returns the Mongo Db, or null when running in development and MongoDB is unreachable
 * (callers then use the in-memory branch). In production a connection failure throws
 * DatabaseUnavailableError, so there is never a silent fallback.
 */
export async function getDatabase(): Promise<Db | null> {
  try {
    const { db } = await connectToDatabase();
    return db;
  } catch (err: any) {
    if (process.env.NODE_ENV === 'production') {
      throw new DatabaseUnavailableError('MongoDB connection failed', err);
    }
    console.warn('[db] MongoDB connection failed; using in-memory fallback (development only):', err?.message || err);
    return null;
  }
}

/** A Mongo operation failed after a connection was established: never fall back to memory. */
function mongoFailure(operation: string, err: any): never {
  console.error(`[db] MongoDB ${operation} failed:`, err?.message || err);
  throw new DatabaseUnavailableError(`MongoDB ${operation} failed`, err);
}

/** Apply Mongo-style $set paths (e.g. 'payment.status') to an in-memory object. */
function applyDottedSet(target: any, fields: Record<string, any>) {
  for (const [path, value] of Object.entries(fields)) {
    const parts = path.split('.');
    let cur = target;
    for (let i = 0; i < parts.length - 1; i++) {
      cur[parts[i]] = { ...(cur[parts[i]] || {}) };
      cur = cur[parts[i]];
    }
    cur[parts[parts.length - 1]] = value;
  }
}

// Stores helper
export async function dbGetStores(filter?: { city?: string; area?: string }) {
  const db = await getDatabase();
  if (db) {
    try {
      const query: any = {};
      if (filter?.city) query['location.city'] = { $regex: filter.city, $options: 'i' };
      if (filter?.area) query['location.area'] = { $regex: filter.area, $options: 'i' };
      return await db.collection<Store>('stores').find(query).toArray();
    } catch (e) {
      mongoFailure('dbGetStores', e);
    }
  }
  return memoryStores.filter(s => {
    if (filter?.city && !s.location.city.toLowerCase().includes(filter.city.toLowerCase())) return false;
    if (filter?.area && !s.location.area.toLowerCase().includes(filter.area.toLowerCase())) return false;
    return true;
  });
}

export async function dbGetStoreById(id: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<Store>('stores').findOne({ id });
    } catch (e) {
      mongoFailure('dbGetStoreById', e);
    }
  }
  return memoryStores.find(s => s.id === id) || null;
}

export async function dbSaveStore(store: Store) {
  const db = await getDatabase();
  if (db) {
    try {
      const { _id, ...storeDoc } = store;
      await db.collection<Store>('stores').updateOne({ id: store.id }, { $set: storeDoc }, { upsert: true });
    } catch (e) {
      mongoFailure('dbSaveStore', e);
    }
    return store;
  }
  const idx = memoryStores.findIndex(s => s.id === store.id);
  if (idx >= 0) memoryStores[idx] = store;
  else memoryStores.push(store);
  return store;
}

/**
 * $set only the given fields (dotted paths such as 'location.address' allowed) so that a
 * concurrent change to other fields (e.g. admin isVerified/commissionRate) is not overwritten.
 * Returns the updated store, or null when the store does not exist.
 */
export async function dbUpdateStoreFields(storeId: string, fields: Record<string, any>): Promise<Store | null> {
  const db = await getDatabase();
  if (db) {
    try {
      return await db
        .collection<Store>('stores')
        .findOneAndUpdate({ id: storeId }, { $set: fields }, { returnDocument: 'after' });
    } catch (e) {
      mongoFailure('dbUpdateStoreFields', e);
    }
  }
  const idx = memoryStores.findIndex(s => s.id === storeId);
  if (idx < 0) return null;
  const updated: Store = { ...memoryStores[idx] };
  applyDottedSet(updated, fields);
  memoryStores[idx] = updated;
  return updated;
}

// Products helper
export async function dbGetProductsByStore(storeId: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<StoreProduct>('store_products').find({ storeId }).toArray();
    } catch (e) {
      mongoFailure('dbGetProductsByStore', e);
    }
  }
  return memoryProducts.filter(p => p.storeId === storeId);
}

export async function dbGetProductById(id: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<StoreProduct>('store_products').findOne({ id });
    } catch (e) {
      mongoFailure('dbGetProductById', e);
    }
  }
  return memoryProducts.find(p => p.id === id) || null;
}

export async function dbSaveProduct(product: StoreProduct) {
  const db = await getDatabase();
  if (db) {
    try {
      const { _id, ...productDoc } = product;
      await db.collection<StoreProduct>('store_products').updateOne({ id: product.id }, { $set: productDoc }, { upsert: true });
    } catch (e) {
      mongoFailure('dbSaveProduct', e);
    }
    return product;
  }
  const idx = memoryProducts.findIndex(p => p.id === product.id);
  if (idx >= 0) memoryProducts[idx] = product;
  else memoryProducts.push(product);
  return product;
}

// Users helper
export async function dbGetUser(uid: string): Promise<User | null> {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<User>('users').findOne({ uid });
    } catch (e) {
      mongoFailure('dbGetUser', e);
    }
  }
  return memoryUsers.find(u => u.uid === uid) || null;
}

export async function dbUpsertUserName(uid: string, name: string, phone: string): Promise<User> {
  const now = new Date().toISOString();
  const db = await getDatabase();
  if (db) {
    try {
      const result = await db.collection<User>('users').findOneAndUpdate(
        { uid },
        {
          $set: { name, updatedAt: now },
          // uid comes from the filter's equality match on upsert
          $setOnInsert: { role: 'customer', phone, createdAt: now },
        },
        { upsert: true, returnDocument: 'after' }
      );
      if (!result) {
        throw new Error('Upsert returned no document');
      }
      return result;
    } catch (e) {
      mongoFailure('dbUpsertUserName', e);
    }
  }
  const idx = memoryUsers.findIndex(u => u.uid === uid);
  if (idx >= 0) {
    memoryUsers[idx] = { ...memoryUsers[idx], name, updatedAt: now };
    return memoryUsers[idx];
  }
  const created: User = { uid, role: 'customer', phone, name, createdAt: now, updatedAt: now };
  memoryUsers.push(created);
  return created;
}

/**
 * Create the user on first login (role always 'customer') or refresh phone/name on later logins.
 * `name` is only applied when provided; an existing name is preserved otherwise.
 */
export async function dbSyncUser(uid: string, phone: string, name?: string): Promise<User> {
  const now = new Date().toISOString();
  const db = await getDatabase();
  if (db) {
    try {
      const $set: Record<string, any> = { updatedAt: now };
      if (phone) $set.phone = phone;
      if (name) $set.name = name;
      const $setOnInsert: Record<string, any> = { role: 'customer', createdAt: now };
      if (!phone) $setOnInsert.phone = '';
      if (!name) $setOnInsert.name = 'Kirana Customer';
      const result = await db
        .collection<User>('users')
        .findOneAndUpdate({ uid }, { $set, $setOnInsert }, { upsert: true, returnDocument: 'after' });
      if (!result) {
        throw new Error('Upsert returned no document');
      }
      return result;
    } catch (e) {
      mongoFailure('dbSyncUser', e);
    }
  }
  const idx = memoryUsers.findIndex(u => u.uid === uid);
  if (idx >= 0) {
    const existing = memoryUsers[idx];
    memoryUsers[idx] = { ...existing, phone: phone || existing.phone, name: name || existing.name, updatedAt: now };
    return memoryUsers[idx];
  }
  const created: User = {
    uid,
    phone,
    name: name || 'Kirana Customer',
    role: 'customer',
    createdAt: now,
    updatedAt: now,
  };
  memoryUsers.push(created);
  return created;
}

/** Admin role/store assignment. Returns the updated user or null when the user does not exist. */
export async function dbUpdateUserRole(uid: string, updateDoc: any): Promise<User | null> {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<User>('users').findOneAndUpdate({ uid }, updateDoc, { returnDocument: 'after' });
    } catch (e) {
      mongoFailure('dbUpdateUserRole', e);
    }
  }
  const idx = memoryUsers.findIndex(u => u.uid === uid);
  if (idx < 0) return null;
  const updated: any = { ...memoryUsers[idx], ...(updateDoc.$set || {}) };
  for (const key of Object.keys(updateDoc.$unset || {})) delete updated[key];
  memoryUsers[idx] = updated as User;
  return memoryUsers[idx];
}


// Carts helper (one cart per user, stored in the `carts` collection keyed by `uid`)
type CartDoc = Cart & { uid: string };

export async function dbGetCart(uid: string): Promise<Cart | null> {
  const db = await getDatabase();
  if (db) {
    try {
      const doc = await db
        .collection<CartDoc>('carts')
        .findOne({ uid }, { projection: { _id: 0, uid: 0 } });
      return (doc as unknown as Cart) || null;
    } catch (e) {
      mongoFailure('dbGetCart', e);
    }
  }
  return memoryCarts[uid] ? { ...memoryCarts[uid] } : null;
}

export async function dbSaveCart(cart: Cart): Promise<Cart> {
  const db = await getDatabase();
  if (db) {
    try {
      const { _id, ...rest } = cart;
      await db
        .collection<CartDoc>('carts')
        .updateOne({ uid: cart.userId }, { $set: { ...rest, uid: cart.userId } }, { upsert: true });
    } catch (e) {
      mongoFailure('dbSaveCart', e);
    }
    return cart;
  }
  memoryCarts[cart.userId] = cart;
  return cart;
}

export async function dbClearCart(uid: string): Promise<void> {
  const db = await getDatabase();
  if (db) {
    try {
      await db.collection<CartDoc>('carts').deleteOne({ uid });
    } catch (e) {
      mongoFailure('dbClearCart', e);
    }
    return;
  }
  delete memoryCarts[uid];
}

// Orders helper
export async function dbGetOrders(filter: { userId?: string; storeId?: string }) {
  const db = await getDatabase();
  if (db) {
    try {
      const q: any = {};
      if (filter.userId) q.userId = filter.userId;
      if (filter.storeId) q.storeId = filter.storeId;
      return await db.collection<Order>('orders').find(q).sort({ createdAt: -1 }).toArray();
    } catch (e) {
      mongoFailure('dbGetOrders', e);
    }
  }
  return memoryOrders
    .filter(o => {
      if (filter.userId && o.userId !== filter.userId) return false;
      if (filter.storeId && o.storeId !== filter.storeId) return false;
      return true;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function dbGetOrderById(id: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<Order>('orders').findOne({ orderNumber: id }) || await db.collection<Order>('orders').findOne({ _id: id as any });
    } catch (e) {
      mongoFailure('dbGetOrderById', e);
    }
  }
  return memoryOrders.find(o => o.orderNumber === id || o._id === id) || null;
}

function generateOrderNumber(): string {
  const now = new Date();
  const yy = now.getFullYear().toString().slice(-2);
  const mm = (now.getMonth() + 1).toString().padStart(2, '0');
  const seq = Math.floor(1000 + Math.random() * 9000);
  return `KC-${yy}${mm}-${seq}`;
}

export interface TransitionOrderUpdate {
  $set?: Record<string, any>;
  $push?: Record<string, any>;
}

export type TransitionOrderResult =
  | { success: true; order: Order }
  | { success: false; error: 'NOT_FOUND' | 'ORDER_CHANGED' };

export async function dbTransitionOrder(
  orderNumber: string,
  expectedStatus: OrderStatus | undefined,
  update: TransitionOrderUpdate
): Promise<TransitionOrderResult> {
  const db = await getDatabase();
  if (db) {
    try {
      const filter: any = { orderNumber };
      if (expectedStatus) {
        filter.status = expectedStatus;
      }
      const updateDoc: any = {};
      if (update.$set) updateDoc.$set = update.$set;
      if (update.$push) updateDoc.$push = update.$push;

      const result = await db.collection<Order>('orders').findOneAndUpdate(
        filter,
        updateDoc,
        { returnDocument: 'after' }
      );

      if (result) {
        return { success: true, order: result };
      }

      // Check if order exists to distinguish NOT_FOUND (404) vs ORDER_CHANGED (409)
      const existing = await db.collection<Order>('orders').findOne({ orderNumber });
      if (!existing) {
        return { success: false, error: 'NOT_FOUND' };
      }
      return { success: false, error: 'ORDER_CHANGED' };
    } catch (e: any) {
      mongoFailure('dbTransitionOrder', e);
    }
  }

  // In-memory branch
  const order = memoryOrders.find(o => o.orderNumber === orderNumber);
  if (!order) {
    return { success: false, error: 'NOT_FOUND' };
  }

  if (expectedStatus && order.status !== expectedStatus) {
    return { success: false, error: 'ORDER_CHANGED' };
  }

  if (update.$set) {
    applyDottedSet(order, update.$set);
  }
  if (update.$push) {
    for (const key of Object.keys(update.$push)) {
      if (Array.isArray((order as any)[key])) {
        (order as any)[key].push(update.$push[key]);
      }
    }
  }

  return { success: true, order: { ...order } };
}

export async function dbCreateOrder(order: Order): Promise<Order> {
  const maxAttempts = 10;
  const db = await getDatabase();

  if (db) {
    let currentOrder = { ...order };
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        if (!currentOrder.orderNumber) {
          currentOrder.orderNumber = generateOrderNumber();
        }
        await db.collection<Order>('orders').insertOne(currentOrder);
        return currentOrder;
      } catch (err: any) {
        const isDupKey =
          err?.code === 11000 ||
          (typeof err?.message === 'string' &&
            (err.message.includes('E11000') || err.message.includes('duplicate key')));
        if (isDupKey && attempt < maxAttempts) {
          currentOrder.orderNumber = generateOrderNumber();
          continue;
        }
        mongoFailure('dbCreateOrder', err);
      }
    }
    throw new DatabaseUnavailableError('MongoDB dbCreateOrder failed: could not generate a unique order number');
  }

  // In-memory branch
  let currentOrder = { ...order };
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    if (!currentOrder.orderNumber) {
      currentOrder.orderNumber = generateOrderNumber();
    }
    const exists = memoryOrders.some(o => o.orderNumber === currentOrder.orderNumber);
    if (exists) {
      if (attempt < maxAttempts) {
        currentOrder.orderNumber = generateOrderNumber();
        continue;
      }
      throw new Error('Failed to generate unique order number after retries');
    }
    memoryOrders.push(currentOrder);
    return currentOrder;
  }
  return currentOrder;
}

/**
 * @deprecated Use dbCreateOrder for new orders or dbTransitionOrder for status/payment updates.
 */
export async function dbSaveOrder(order: Order) {
  const db = await getDatabase();
  if (db) {
    try {
      const { _id, ...orderDoc } = order;
      await db.collection<Order>('orders').updateOne({ orderNumber: order.orderNumber }, { $set: orderDoc }, { upsert: true });
      return order;
    } catch (e) {
      mongoFailure('dbSaveOrder', e);
    }
  }
  const idx = memoryOrders.findIndex(o => o.orderNumber === order.orderNumber);
  if (idx >= 0) memoryOrders[idx] = order;
  else memoryOrders.push(order);
  return order;
}

// Seed helper
export async function dbSeedInitialData() {
  const db = await getDatabase();
  if (db) {
    try {
      const storesCol = db.collection('stores');
      const productsCol = db.collection('store_products');
      
      for (const store of INITIAL_STORES) {
        await storesCol.updateOne({ id: store.id }, { $set: store }, { upsert: true });
      }
      for (const product of INITIAL_PRODUCTS) {
        await productsCol.updateOne({ id: product.id }, { $set: product }, { upsert: true });
      }
      return { success: true, message: 'Database seeded in MongoDB Atlas' };
    } catch (e) {
      mongoFailure('dbSeedInitialData', e);
    }
  }
  memoryStores = [...INITIAL_STORES];
  memoryProducts = [...INITIAL_PRODUCTS];
  return { success: true, message: 'Seeded in-memory state' };
}
