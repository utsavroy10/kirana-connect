import { connectToDatabase } from './mongodb';
import { INITIAL_STORES, INITIAL_PRODUCTS } from './mock-data';
import { Store, StoreProduct, Order, User, Cart, OrderStatus } from '@/types';

// In-memory fallback caches for zero-configuration instant local POC running
let memoryStores: Store[] = [...INITIAL_STORES];
let memoryProducts: StoreProduct[] = [...INITIAL_PRODUCTS];
let memoryOrders: Order[] = [];
let memoryUsers: User[] = [];
let memoryCarts: Record<string, Cart> = {};

export async function getDatabase() {
  try {
    const { db } = await connectToDatabase();
    return db;
  } catch (err: any) {
    // Return null if MongoDB Atlas is not yet connected or in offline sandbox
    console.error('[db] MongoDB connection failed:', err?.message || err);
    return null;
  }
}

// Stores helper
export async function dbGetStores(filter?: { city?: string; area?: string }) {
  const db = await getDatabase();
  if (db) {
    try {
      const query: any = {};
      if (filter?.city) query['location.city'] = { $regex: filter.city, $options: 'i' };
      if (filter?.area) query['location.area'] = { $regex: filter.area, $options: 'i' };
      return await db.collection<Store>('stores').find(query).toArray();
    } catch (e) {
      console.warn('MongoDB query error, using memory stores fallback');
    }
  }
  return memoryStores.filter(s => {
    if (filter?.city && !s.location.city.toLowerCase().includes(filter.city.toLowerCase())) return false;
    if (filter?.area && !s.location.area.toLowerCase().includes(filter.area.toLowerCase())) return false;
    return true;
  });
}

export async function dbGetStoreById(id: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<Store>('stores').findOne({ id });
    } catch (e) {
      console.warn('MongoDB query error, fallback');
    }
  }
  return memoryStores.find(s => s.id === id) || null;
}

export async function dbSaveStore(store: Store) {
  const db = await getDatabase();
  if (db) {
    try {
      await db.collection<Store>('stores').updateOne({ id: store.id }, { $set: store }, { upsert: true });
    } catch (e) {
      console.warn('MongoDB save store error');
    }
  }
  const idx = memoryStores.findIndex(s => s.id === store.id);
  if (idx >= 0) memoryStores[idx] = store;
  else memoryStores.push(store);
  return store;
}

// Products helper
export async function dbGetProductsByStore(storeId: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<StoreProduct>('store_products').find({ storeId }).toArray();
    } catch (e) {
      console.warn('MongoDB query products error');
    }
  }
  return memoryProducts.filter(p => p.storeId === storeId);
}

export async function dbGetProductById(id: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<StoreProduct>('store_products').findOne({ id });
    } catch (e) {
      console.warn('MongoDB query product error');
    }
  }
  return memoryProducts.find(p => p.id === id) || null;
}

export async function dbSaveProduct(product: StoreProduct) {
  const db = await getDatabase();
  if (db) {
    try {
      await db.collection<StoreProduct>('store_products').updateOne({ id: product.id }, { $set: product }, { upsert: true });
    } catch (e) {}
  }
  const idx = memoryProducts.findIndex(p => p.id === product.id);
  if (idx >= 0) memoryProducts[idx] = product;
  else memoryProducts.push(product);
  return product;
}

// Orders helper
export async function dbGetOrders(filter: { userId?: string; storeId?: string }) {
  const db = await getDatabase();
  if (db) {
    try {
      const q: any = {};
      if (filter.userId) q.userId = filter.userId;
      if (filter.storeId) q.storeId = filter.storeId;
      return await db.collection<Order>('orders').find(q).sort({ createdAt: -1 }).toArray();
    } catch (e) {}
  }
  return memoryOrders
    .filter(o => {
      if (filter.userId && o.userId !== filter.userId) return false;
      if (filter.storeId && o.storeId !== filter.storeId) return false;
      return true;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function dbGetOrderById(id: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<Order>('orders').findOne({ orderNumber: id }) || await db.collection<Order>('orders').findOne({ _id: id as any });
    } catch (e) {}
  }
  return memoryOrders.find(o => o.orderNumber === id || o._id === id) || null;
}

function generateOrderNumber(): string {
  const now = new Date();
  const yy = now.getFullYear().toString().slice(-2);
  const mm = (now.getMonth() + 1).toString().padStart(2, '0');
  const seq = Math.floor(1000 + Math.random() * 9000);
  return `KC-${yy}${mm}-${seq}`;
}

export interface TransitionOrderUpdate {
  $set?: Record<string, any>;
  $push?: Record<string, any>;
}

export type TransitionOrderResult =
  | { success: true; order: Order }
  | { success: false; error: 'NOT_FOUND' | 'ORDER_CHANGED' };

export async function dbTransitionOrder(
  orderNumber: string,
  expectedStatus: OrderStatus | undefined,
  update: TransitionOrderUpdate
): Promise<TransitionOrderResult> {
  const db = await getDatabase();
  if (db) {
    try {
      const filter: any = { orderNumber };
      if (expectedStatus) {
        filter.status = expectedStatus;
      }
      const updateDoc: any = {};
      if (update.$set) updateDoc.$set = update.$set;
      if (update.$push) updateDoc.$push = update.$push;

      const result = await db.collection<Order>('orders').findOneAndUpdate(
        filter,
        updateDoc,
        { returnDocument: 'after' }
      );

      if (result) {
        return { success: true, order: result };
      }

      // Check if order exists to distinguish NOT_FOUND (404) vs ORDER_CHANGED (409)
      const existing = await db.collection<Order>('orders').findOne({ orderNumber });
      if (!existing) {
        return { success: false, error: 'NOT_FOUND' };
      }
      return { success: false, error: 'ORDER_CHANGED' };
    } catch (e: any) {
      console.error('[db] dbTransitionOrder MongoDB error, falling back to memory:', e?.message || e);
    }
  }

  // In-memory branch
  const order = memoryOrders.find(o => o.orderNumber === orderNumber);
  if (!order) {
    return { success: false, error: 'NOT_FOUND' };
  }

  if (expectedStatus && order.status !== expectedStatus) {
    return { success: false, error: 'ORDER_CHANGED' };
  }

  if (update.$set) {
    Object.assign(order, update.$set);
  }
  if (update.$push) {
    for (const key of Object.keys(update.$push)) {
      if (Array.isArray((order as any)[key])) {
        (order as any)[key].push(update.$push[key]);
      }
    }
  }

  return { success: true, order: { ...order } };
}

export async function dbCreateOrder(order: Order): Promise<Order> {
  const maxAttempts = 10;
  const db = await getDatabase();

  if (db) {
    let currentOrder = { ...order };
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        if (!currentOrder.orderNumber) {
          currentOrder.orderNumber = generateOrderNumber();
        }
        await db.collection<Order>('orders').insertOne(currentOrder);
        return currentOrder;
      } catch (err: any) {
        const isDupKey =
          err?.code === 11000 ||
          (typeof err?.message === 'string' &&
            (err.message.includes('E11000') || err.message.includes('duplicate key')));
        if (isDupKey && attempt < maxAttempts) {
          currentOrder.orderNumber = generateOrderNumber();
          continue;
        }
        throw err;
      }
    }
  }

  // In-memory branch
  let currentOrder = { ...order };
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    if (!currentOrder.orderNumber) {
      currentOrder.orderNumber = generateOrderNumber();
    }
    const exists = memoryOrders.some(o => o.orderNumber === currentOrder.orderNumber);
    if (exists) {
      if (attempt < maxAttempts) {
        currentOrder.orderNumber = generateOrderNumber();
        continue;
      }
      throw new Error('Failed to generate unique order number after retries');
    }
    memoryOrders.push(currentOrder);
    return currentOrder;
  }
  return currentOrder;
}

/**
 * @deprecated Use dbCreateOrder for new orders or dbTransitionOrder for status/payment updates.
 */
export async function dbSaveOrder(order: Order) {
  const db = await getDatabase();
  if (db) {
    try {
      await db.collection<Order>('orders').updateOne({ orderNumber: order.orderNumber }, { $set: order }, { upsert: true });
      return order;
    } catch (e) {}
  }
  const idx = memoryOrders.findIndex(o => o.orderNumber === order.orderNumber);
  if (idx >= 0) memoryOrders[idx] = order;
  else memoryOrders.push(order);
  return order;
}

// Seed helper
export async function dbSeedInitialData() {
  const db = await getDatabase();
  if (db) {
    try {
      const storesCol = db.collection('stores');
      const productsCol = db.collection('store_products');
      
      for (const store of INITIAL_STORES) {
        await storesCol.updateOne({ id: store.id }, { $set: store }, { upsert: true });
      }
      for (const product of INITIAL_PRODUCTS) {
        await productsCol.updateOne({ id: product.id }, { $set: product }, { upsert: true });
      }
      return { success: true, message: 'Database seeded in MongoDB Atlas' };
    } catch (e) {
      console.warn('MongoDB Atlas seed failed, using in-memory initialization', e);
    }
  }
  memoryStores = [...INITIAL_STORES];
  memoryProducts = [...INITIAL_PRODUCTS];
  return { success: true, message: 'Seeded in-memory state' };
}
