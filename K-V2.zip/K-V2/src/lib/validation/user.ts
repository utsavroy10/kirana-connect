import { z } from 'zod';

/** POST /api/auth/sync (strip: role / storeId / uid from the client are ignored). */
export const authSyncSchema = z.object({
  // Lenient on purpose (accepted payloads are unchanged): an unusable name is ignored, not rejected.
  name: z.string().trim().max(100).optional().catch(undefined),
});

/** PATCH /api/profile (strip). Phone is read-only. */
export const profilePatchSchema = z.object({
  name: z.string().trim().min(1).max(100),
});

/** PATCH /api/admin/users/[uid] (strip). Cross-field rules stay in the route. */
export const adminUserPatchSchema = z.object({
  role: z.enum(['customer', 'merchant', 'admin']).optional(),
  storeId: z.string().trim().min(1).max(64).optional(),
});

/** POST /api/admin/catalog/seed (strip). */
export const catalogSeedSchema = z.object({
  storeId: z.string().trim().min(1).max(64),
});
