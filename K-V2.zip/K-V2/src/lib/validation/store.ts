import { z } from 'zod';
import { PINCODE_RE, commissionRate, httpsUrl, nonEmptyObject, phoneNumber, timeOfDay } from './common';

/** Fields a merchant may change on their own store through PUT /api/stores/[id]. */
export const STORE_MERCHANT_FIELDS = ['tagline', 'phone', 'isOpen', 'openingTime', 'closingTime', 'bannerImage'] as const;
/** Additional fields only an admin may change. */
export const STORE_ADMIN_ONLY_FIELDS = ['name', 'ownerName', 'isVerified', 'commissionRate', 'merchantUid'] as const;
export const STORE_ALL_UPDATE_FIELDS: readonly string[] = [...STORE_MERCHANT_FIELDS, ...STORE_ADMIN_ONLY_FIELDS];

/** Only used to reject unknown/immutable keys before role checks (values are validated later). */
export const storeUpdateKeysSchema = z
  .object(Object.fromEntries(STORE_ALL_UPDATE_FIELDS.map((k) => [k, z.unknown()])) as Record<string, z.ZodTypeAny>)
  .strict();

export const storeUpdateSchema = z
  .object({
    tagline: z.string().max(100),
    phone: phoneNumber('phone'),
    isOpen: z.boolean(),
    openingTime: timeOfDay('openingTime'),
    closingTime: timeOfDay('closingTime'),
    bannerImage: httpsUrl('bannerImage'),
    name: z.string().trim().min(1).max(100),
    ownerName: z.string().trim().min(1).max(100),
    isVerified: z.boolean(),
    commissionRate,
    merchantUid: z.string().trim().min(1).max(128),
  })
  .partial()
  .strict()
  .refine(nonEmptyObject, { message: 'At least one field to update is required' });

export const storeCreateSchema = z
  .object({
    name: z.string().trim().min(1).max(100),
    ownerName: z.string().trim().min(1).max(100),
    phone: phoneNumber('phone'),
    tagline: z.string().max(100),
    description: z.string().max(500).optional(),
    location: z
      .object({
        address: z.string().trim().min(1).max(200),
        area: z.string().trim().min(1).max(100),
        city: z.string().trim().min(1).max(100),
        pincode: z.string().regex(PINCODE_RE, { message: 'pincode must be 6 digits' }),
        landmark: z.string().max(200).optional(),
        lat: z.number().min(-90).max(90).optional(),
        lng: z.number().min(-180).max(180).optional(),
      })
      .strict(),
    openingTime: timeOfDay('openingTime'),
    closingTime: timeOfDay('closingTime'),
    categories: z.array(z.string().trim().min(1).max(60)).max(20).optional(),
    bannerImage: httpsUrl('bannerImage').optional(),
    merchantUid: z.string().trim().min(1).max(128).optional(),
  })
  .strict();

export const adminMerchantPatchSchema = z
  .object({
    storeId: z.string().trim().min(1).max(64),
    isVerified: z.boolean().optional(),
    isOpen: z.boolean().optional(),
    commissionRate: commissionRate.optional(),
  })
  .strict()
  .refine((v) => v.isVerified !== undefined || v.isOpen !== undefined || v.commissionRate !== undefined, {
    message: 'At least one of isVerified, isOpen or commissionRate is required',
  });

export const storeQuerySchema = z.object({
  city: z.string().max(50).optional(),
  area: z.string().max(50).optional(),
});

/** PATCH /api/merchant/store (strip: unknown keys ignored). Business rules stay in the route. */
export const merchantStorePatchSchema = z.object({
  name: z.string().trim().min(1).max(100).optional(),
  tagline: z.string().max(100).optional(),
  description: z.string().max(500).optional(),
  address: z.string().trim().min(1).max(200).optional(),
  phone: z.string().optional(),
  openingTime: z.string().optional(),
  closingTime: z.string().optional(),
  isOpen: z.boolean().optional(),
});
