import { z } from 'zod';
import { PRODUCT_ID_RE, httpsUrl, nonEmptyObject, productCategoryEnum, rupeeAmount } from './common';

/** Keys a legacy caller can never set (HTTP 400 IMMUTABLE_FIELD). */
export const PRODUCT_IMMUTABLE_FIELDS = ['storeId', 'isActive', 'createdAt'] as const;

/** Legacy routes (PUT /api/products/[id], POST /api/stores/[id]/products): strict whitelist. */
const legacyFields = {
  name: z.string().trim().min(1).max(100),
  hindiName: z.string().max(150),
  brand: z.string().max(100),
  description: z.string().max(500),
  // Free string on purpose: the legacy inventory page sends seed categories such as "Cooking Oils".
  category: z.string().trim().min(1).max(60),
  price: rupeeAmount('price'),
  mrp: rupeeAmount('mrp'),
  unit: z.string().trim().min(1).max(30),
  inStock: z.boolean(),
  imageUrl: httpsUrl('imageUrl'),
};

export const legacyProductUpdateSchema = z
  .object(legacyFields)
  .partial()
  .strict()
  .refine(nonEmptyObject, { message: 'At least one field to update is required' });

export const legacyProductCreateSchema = z
  .object({
    id: z.string().regex(PRODUCT_ID_RE, { message: 'id must match [a-z0-9_] and be 3-64 characters' }),
    ...legacyFields,
  })
  .partial({ id: true, hindiName: true, brand: true, description: true, mrp: true, inStock: true, imageUrl: true })
  .strict();

/** Merchant catalog routes (strip: unknown keys ignored). */
const merchantFields = {
  name: z.string().trim().min(1).max(150),
  hindiName: z.string().max(150),
  description: z.string().max(500),
  category: productCategoryEnum,
  price: rupeeAmount('price'),
  mrp: rupeeAmount('mrp'),
  unit: z.string().trim().min(1).max(50),
  inStock: z.boolean(),
};

export const merchantProductCreateSchema = z
  .object(merchantFields)
  .partial({ hindiName: true, description: true, mrp: true, inStock: true });

export const merchantProductPatchSchema = z.object(merchantFields).partial();

export const merchantStockSchema = z.object({ inStock: z.boolean() });
