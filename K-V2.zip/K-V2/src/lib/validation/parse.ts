/**
 * Request parsing + validation helpers shared by every API route.
 * Pure module: only depends on zod and the web-standard Request/Response.
 *
 * Contract:
 *  - malformed JSON            -> 400 { error: 'INVALID_JSON', message }
 *  - schema failure            -> 400 { error: 'VALIDATION_ERROR' (or opts.code), message, details: [{ path, message }] }
 *  - messages are generated from the zod issue *code* (never zod's default text), so submitted
 *    values, stacks and library internals are never echoed back.
 */
import type { z, ZodIssue, ZodTypeAny } from 'zod';

export interface ValidationDetail {
  path: string;
  message: string;
}

export interface ValidateOptions {
  /** Error code for schema failures. Default 'VALIDATION_ERROR'. */
  code?: string;
  /** Per top-level field code overrides (used to keep legacy codes such as INVALID_NOTE). */
  codeByField?: Record<string, string>;
}

export type ParseResult<T> =
  | { data: T; errorResponse?: never }
  | { data?: never; errorResponse: Response };

export type JsonResult = { value: unknown; errorResponse?: never } | { value?: never; errorResponse: Response };

export function jsonError(status: number, error: string, message: string, extra?: Record<string, unknown>): Response {
  return new Response(JSON.stringify({ error, message, ...(extra || {}) }), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

const articleFor = (expected: string): string => {
  switch (expected) {
    case 'integer':
      return 'an integer';
    case 'object':
      return 'an object';
    case 'array':
      return 'an array';
    case 'unknown':
      return 'valid';
    default:
      return `a ${expected}`;
  }
};

const labelOf = (path: (string | number)[]): string => (path.length ? path.map(String).join('.') : 'body');

function describeIssue(issue: ZodIssue): string {
  const field = labelOf(issue.path);
  switch (issue.code) {
    case 'invalid_type':
      if (issue.received === 'undefined') return `${field} is required`;
      return `${field} must be ${articleFor(String(issue.expected))}`;
    case 'unrecognized_keys':
      return 'Unknown field(s) are not allowed';
    case 'invalid_enum_value':
    case 'invalid_literal':
    case 'invalid_union':
    case 'invalid_union_discriminator':
      return `${field} has an invalid value`;
    case 'too_small': {
      const min = String(issue.minimum);
      if (issue.type === 'string') return `${field} must be at least ${min} character(s)`;
      if (issue.type === 'array') return `${field} must contain at least ${min} item(s)`;
      return `${field} must be ${issue.inclusive ? 'at least' : 'greater than'} ${min}`;
    }
    case 'too_big': {
      const max = String(issue.maximum);
      if (issue.type === 'string') return `${field} must be at most ${max} character(s)`;
      if (issue.type === 'array') return `${field} must contain at most ${max} item(s)`;
      return `${field} must be ${issue.inclusive ? 'at most' : 'less than'} ${max}`;
    }
    case 'invalid_string':
    case 'custom':
      // These messages are written in our own schemas (or are zod's fixed "Invalid ..." text);
      // they never contain the submitted value.
      return issue.message;
    default:
      return `${field} is invalid`;
  }
}

function toDetails(issues: ZodIssue[]): ValidationDetail[] {
  const details: ValidationDetail[] = [];
  for (const issue of issues) {
    if (issue.code === 'unrecognized_keys') {
      for (const key of issue.keys) {
        details.push({ path: labelOf([...issue.path, String(key).slice(0, 64)]), message: 'Unknown field' });
      }
      continue;
    }
    details.push({ path: labelOf(issue.path), message: describeIssue(issue) });
  }
  return details;
}

/** Read and JSON-parse a request body. Empty body is INVALID_JSON unless allowEmpty (then `{}`). */
export async function parseJson(req: Request, opts: { allowEmpty?: boolean } = {}): Promise<JsonResult> {
  let text: string;
  try {
    text = await req.text();
  } catch {
    return { errorResponse: jsonError(400, 'INVALID_JSON', 'Invalid JSON body') };
  }
  if (!text.trim()) {
    if (opts.allowEmpty) return { value: {} };
    return { errorResponse: jsonError(400, 'INVALID_JSON', 'Invalid JSON body') };
  }
  try {
    return { value: JSON.parse(text) };
  } catch {
    return { errorResponse: jsonError(400, 'INVALID_JSON', 'Invalid JSON body') };
  }
}

/** Validate an already-parsed value against a schema. */
export function validate<S extends ZodTypeAny>(
  schema: S,
  value: unknown,
  opts: ValidateOptions = {}
): ParseResult<z.output<S>> {
  const result = schema.safeParse(value);
  if (result.success) {
    return { data: result.data };
  }
  const details = toDetails(result.error.issues);
  const firstIssue = result.error.issues[0];
  const firstField = firstIssue && firstIssue.path.length ? String(firstIssue.path[0]) : '';
  const code = (firstField && opts.codeByField && opts.codeByField[firstField]) || opts.code || 'VALIDATION_ERROR';
  const message = !firstIssue
    ? 'Invalid request'
    : firstIssue.code === 'unrecognized_keys'
      ? 'Unknown field(s) are not allowed'
      : describeIssue(firstIssue);
  return { errorResponse: jsonError(400, code, message, { details }) };
}

/** parseJson + validate in one step. */
export async function parseBody<S extends ZodTypeAny>(
  req: Request,
  schema: S,
  opts: ValidateOptions & { allowEmpty?: boolean } = {}
): Promise<ParseResult<z.output<S>>> {
  const json = await parseJson(req, { allowEmpty: opts.allowEmpty });
  if (json.errorResponse) {
    return { errorResponse: json.errorResponse };
  }
  return validate(schema, json.value, opts);
}

/** Names of `keys` that are present (own properties) on a plain-object value. */
export function findPresentKeys(value: unknown, keys: readonly string[]): string[] {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return [];
  return keys.filter((k) => Object.prototype.hasOwnProperty.call(value, k));
}
