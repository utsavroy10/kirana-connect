/**
 * Shared zod building blocks. Pure module (no server imports).
 * Custom messages never include the submitted value.
 */
import { z } from 'zod';
import { isValidRupeeAmount, RUPEE_AMOUNT_RULE } from '@/lib/money';
import { ALLOWED_PRODUCT_CATEGORIES } from '@/lib/productCategories';

export const PHONE_RE = /^\+?\d{10,13}$/;
export const TIME_RE = /^(0[1-9]|1[0-2]):[0-5]\d (AM|PM)$/;
export const PRODUCT_ID_RE = /^[a-z0-9_]{3,64}$/;
export const PINCODE_RE = /^\d{6}$/;
export const MAX_COMMISSION_RATE = 20;

export const phoneNumber = (label = 'phone') =>
  z.string().regex(PHONE_RE, { message: `${label} must be 10-13 digits, optionally starting with +` });

export const timeOfDay = (label: string) =>
  z.string().regex(TIME_RE, { message: `${label} must be in the format "08:00 AM"` });

export const httpsUrl = (label: string) =>
  z
    .string()
    .max(500)
    .refine(
      (v) => {
        try {
          return new URL(v).protocol === 'https:';
        } catch {
          return false;
        }
      },
      { message: `${label} must be a valid https URL` }
    );

/** Money is in rupees: > 0, <= 100000, at most 2 decimals (see src/lib/money.ts). */
export const rupeeAmount = (label: string) =>
  z.number().refine(isValidRupeeAmount, { message: `${label} (in rupees) must be ${RUPEE_AMOUNT_RULE}` });

/** Commission percent: 0 <= x <= 20, at most 2 decimals. */
export const commissionRate = z
  .number()
  .min(0)
  .max(MAX_COMMISSION_RATE)
  .refine((v) => Math.round(v * 100) / 100 === v, { message: 'commissionRate must have at most 2 decimal places' });

export const productCategoryEnum = z
  .string()
  .refine((v) => (ALLOWED_PRODUCT_CATEGORIES as readonly string[]).includes(v), {
    message: `category must be one of: ${ALLOWED_PRODUCT_CATEGORIES.join(', ')}`,
  });

export const nonEmptyObject = (value: object): boolean => Object.keys(value).length > 0;

/** Remove undefined values so they are never persisted as null. */
export function omitUndefined<T extends Record<string, unknown>>(obj: T): T {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) out[k] = v;
  }
  return out as T;
}
