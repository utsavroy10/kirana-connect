import { z } from 'zod';

/**
 * Optional free text. Like Phase 1-2, a non-string value is ignored (not rejected);
 * a string longer than `max` is rejected.
 */
const optionalText = (label: string, max: number) =>
  z
    .unknown()
    .superRefine((v, ctx) => {
      if (typeof v === 'string' && v.length > max) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: `${label} must be at most ${max} characters` });
      }
    })
    .transform((v) => (typeof v === 'string' ? v : undefined));

/** POST /api/orders (strip: userId, totals, status etc. from the client are ignored). */
export const createOrderSchema = z.object({
  storeId: z.string().trim().min(1).max(100),
  items: z
    .array(
      z.object({
        productId: z.string().trim().min(1).max(100),
        quantity: z.number().int().min(1).max(50),
      })
    )
    .min(1),
  // Slot id is read from `id` or `slotId`; the route answers SLOT_UNAVAILABLE when neither is a string.
  pickupSlot: z.object({ id: z.unknown().optional(), slotId: z.unknown().optional() }),
  customerName: optionalText('customerName', 80),
  customerPhone: optionalText('customerPhone', 20),
  customerNotes: optionalText('customerNotes', 500),
});

/**
 * PATCH /api/orders/[id] and /status (strip). `status` and `paymentStatus` stay unknown here so the
 * handler keeps its precise INVALID_STATUS / INVALID_PAYMENT_STATUS behaviour (and so a customer's
 * paymentStatus is ignored whatever it contains).
 */
export const patchOrderSchema = z.object({
  status: z.unknown().optional(),
  note: z.string().max(200).optional(),
  // Kept loose: the handler checks the caller's role first (403) and only then the value
  // (INVALID_MERCHANT_NOTES), exactly as in Phase 2.
  merchantNotes: z.unknown().optional(),
  paymentStatus: z.unknown().optional(),
});

/** Existing error codes per field. */
export const PATCH_ORDER_CODES: Record<string, string> = {
  note: 'INVALID_NOTE',
};

/** POST /api/cart (strip). */
export const cartUpdateSchema = z.object({
  productId: z.string().trim().min(1).max(100),
  quantity: z.number().int().min(0).max(50),
  clearPrevious: z.unknown().optional(),
});
