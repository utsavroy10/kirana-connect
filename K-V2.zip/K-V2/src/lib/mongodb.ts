import { MongoClient, Db } from 'mongodb';

if (!process.env.MONGODB_URI) {
  // If no env is set in local dev, provide safe fallback or warning
  console.warn('Please define the MONGODB_URI environment variable inside .env.local');
}

const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/kirana_connect';
const dbName = process.env.MONGODB_DB || 'kirana_connect';

let cachedClient: MongoClient | null = null;
let cachedDb: Db | null = null;
let indexesEnsured = false;

export async function ensureIndexes(db: Db): Promise<void> {
  if (indexesEnsured) return;
  indexesEnsured = true;

  try {
    // orders indexes
    await db.collection('orders').createIndex({ orderNumber: 1 }, { unique: true }).catch((err) => {
      console.error('[db index] orders.orderNumber (unique):', err?.message || err);
    });
    await db.collection('orders').createIndex({ userId: 1, createdAt: -1 }).catch((err) => {
      console.error('[db index] orders.{userId, createdAt}:', err?.message || err);
    });
    await db.collection('orders').createIndex({ storeId: 1, createdAt: -1 }).catch((err) => {
      console.error('[db index] orders.{storeId, createdAt}:', err?.message || err);
    });
    await db.collection('orders').createIndex({ createdAt: -1 }).catch((err) => {
      console.error('[db index] orders.createdAt:', err?.message || err);
    });

    // users index
    await db.collection('users').createIndex({ uid: 1 }, { unique: true }).catch((err) => {
      console.error('[db index] users.uid (unique):', err?.message || err);
    });

    // stores index
    await db.collection('stores').createIndex({ id: 1 }, { unique: true }).catch((err) => {
      console.error('[db index] stores.id (unique):', err?.message || err);
    });

    // store_products index
    await db.collection('store_products').createIndex({ id: 1 }, { unique: true }).catch((err) => {
      console.error('[db index] store_products.id (unique):', err?.message || err);
    });
    await db.collection('store_products').createIndex({ storeId: 1 }).catch((err) => {
      console.error('[db index] store_products.storeId:', err?.message || err);
    });
  } catch (err: any) {
    console.error('[db index] General error ensuring indexes:', err?.message || err);
  }
}

export async function connectToDatabase(): Promise<{ client: MongoClient; db: Db }> {
  if (cachedClient && cachedDb) {
    return { client: cachedClient, db: cachedDb };
  }

  const client = new MongoClient(uri, {
    maxPoolSize: 10,
    serverSelectionTimeoutMS: 5000,
  });

  await client.connect();
  const db = client.db(dbName);

  cachedClient = client;
  cachedDb = db;

  // Lazily ensure indexes once per process after connection
  ensureIndexes(db).catch((err) => {
    console.error('[db index] Async indexing error:', err?.message || err);
  });

  return { client, db };
}
