import 'server-only';
import { MongoClient, Db } from 'mongodb';
import { ensureIndexes } from './indexes';

if (!process.env.MONGODB_URI) {
  // If no env is set in local dev, provide safe fallback or warning
  console.warn('Please define the MONGODB_URI environment variable inside .env.local');
}

const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/kirana_connect';
const dbName = process.env.MONGODB_DB || 'kirana_connect';

let cachedClient: MongoClient | null = null;
let cachedDb: Db | null = null;

export async function connectToDatabase(): Promise<{ client: MongoClient; db: Db }> {
  if (cachedClient && cachedDb) {
    return { client: cachedClient, db: cachedDb };
  }

  const client = new MongoClient(uri, {
    maxPoolSize: 10,
    serverSelectionTimeoutMS: 5000,
  });

  await client.connect();
  const db = client.db(dbName);

  cachedClient = client;
  cachedDb = db;

  // Lazily ensure indexes once per process after connection
  ensureIndexes(db).catch((err) => {
    console.error('[db index] Async indexing error:', err?.message || err);
  });

  return { client, db };
}
