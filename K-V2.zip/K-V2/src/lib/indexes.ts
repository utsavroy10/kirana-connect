import 'server-only';
import type { Db } from 'mongodb';

let indexesEnsured = false;

export async function ensureIndexes(db: Db): Promise<void> {
  if (indexesEnsured) return;
  indexesEnsured = true;

  try {
    // orders indexes
    await db.collection('orders').createIndex({ orderNumber: 1 }, { unique: true })
      .then(() => {
        console.log('[db index] orderNumber unique index status: confirmed');
      })
      .catch((err) => {
        console.error('[db index] orderNumber unique index FAILED:', err?.message || err);
      });
    await db.collection('orders').createIndex({ userId: 1, createdAt: -1 }).catch((err) => {
      console.error('[db index] orders.{userId, createdAt}:', err?.message || err);
    });
    await db.collection('orders').createIndex({ storeId: 1, createdAt: -1 }).catch((err) => {
      console.error('[db index] orders.{storeId, createdAt}:', err?.message || err);
    });
    await db.collection('orders').createIndex({ createdAt: -1 }).catch((err) => {
      console.error('[db index] orders.createdAt:', err?.message || err);
    });

    // users index
    await db.collection('users').createIndex({ uid: 1 }, { unique: true }).catch((err) => {
      console.error('[db index] users.uid (unique):', err?.message || err);
    });

    // carts index (one cart per user)
    await db.collection('carts').createIndex({ uid: 1 }, { unique: true }).catch((err) => {
      console.error('[db index] carts.uid (unique):', err?.message || err);
    });

    // stores index
    await db.collection('stores').createIndex({ id: 1 }, { unique: true }).catch((err) => {
      console.error('[db index] stores.id (unique):', err?.message || err);
    });

    // store_products index
    await db.collection('store_products').createIndex({ id: 1 }, { unique: true }).catch((err) => {
      console.error('[db index] store_products.id (unique):', err?.message || err);
    });
    await db.collection('store_products').createIndex({ storeId: 1 }).catch((err) => {
      console.error('[db index] store_products.storeId:', err?.message || err);
    });
  } catch (err: any) {
    console.error('[db index] General error ensuring indexes:', err?.message || err);
  }
}
