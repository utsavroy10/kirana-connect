import 'server-only';
import { NextRequest, NextResponse } from 'next/server';
import { getAdminAuth } from '@/lib/firebaseAdmin';
import { dbGetUser } from '@/lib/db-adapter';
import { DatabaseUnavailableError, serviceUnavailableResponse } from '@/lib/apiErrors';
import { UserRole } from '@/types';

export interface AuthenticatedUser {
  uid: string;
  phone?: string;
  role: UserRole;
  storeId?: string;
}

export type AuthResult =
  | { user: AuthenticatedUser; errorResponse?: never }
  | { user?: never; errorResponse: NextResponse };

export async function verifyAuthToken(req: NextRequest): Promise<AuthenticatedUser | null> {
  const authHeader = req.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  const token = authHeader.split('Bearer ')[1].trim();
  if (!token) {
    return null;
  }

  // Accept DEMO_TOKEN_ only when server-only ALLOW_DEMO_AUTH === 'true' AND NODE_ENV !== 'production'
  const isDemoAuthAllowed = process.env.ALLOW_DEMO_AUTH === 'true' && process.env.NODE_ENV !== 'production';

  if (token.startsWith('DEMO_TOKEN_')) {
    if (!isDemoAuthAllowed) {
      return null;
    }

    const rolePart = token.replace('DEMO_TOKEN_', '').toLowerCase();
    const demoRole: UserRole = rolePart === 'merchant' ? 'merchant' : rolePart === 'admin' ? 'admin' : 'customer';
    const demoPhone = demoRole === 'merchant' ? '+919876543210' : demoRole === 'admin' ? '+919999999999' : '+919811122233';
    const demoUid = `demo_${demoRole}_uid`;
    const demoStoreId = demoRole === 'merchant' ? 'store_shree_ram' : undefined;

    return {
      uid: demoUid,
      phone: demoPhone,
      role: demoRole,
      storeId: demoStoreId,
    };
  }

  let decodedToken;
  try {
    decodedToken = await getAdminAuth().verifyIdToken(token);
  } catch (err) {
    console.error('Token verification failed:', err);
    return null;
  }

  let role: UserRole = 'customer';
  let storeId: string | undefined = undefined;
  let phone: string = decodedToken.phone_number || '';

  // A DB failure must not silently demote a merchant/admin to a customer:
  // DatabaseUnavailableError propagates and the route answers 503.
  const dbUser = await dbGetUser(decodedToken.uid);
  if (dbUser) {
    role = dbUser.role || 'customer';
    storeId = dbUser.storeId;
    if (!phone && dbUser.phone) {
      phone = dbUser.phone;
    }
  }

  return {
    uid: decodedToken.uid,
    phone,
    role,
    storeId,
  };
}

export async function requireAuth(
  req: NextRequest,
  allowedRoles?: UserRole[]
): Promise<AuthResult> {
  let user: AuthenticatedUser | null;
  try {
    user = await verifyAuthToken(req);
  } catch (err) {
    if (err instanceof DatabaseUnavailableError) {
      console.error('[authMiddleware] Database unavailable during role lookup:', err.message);
      return { errorResponse: serviceUnavailableResponse() };
    }
    throw err;
  }
  if (!user) {
    return {
      errorResponse: NextResponse.json({ error: 'Unauthorized' }, { status: 401 }),
    };
  }

  if (allowedRoles && allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    return {
      errorResponse: NextResponse.json({ error: 'Forbidden' }, { status: 403 }),
    };
  }

  return { user };
}
