import { NextResponse } from 'next/server';

/**
 * Thrown by the db-adapter when MongoDB is unreachable or a Mongo operation fails
 * and no safe fallback exists (always in production; in development only a failed
 * connection falls back to memory).
 */
export class DatabaseUnavailableError extends Error {
  public readonly originalError?: unknown;

  constructor(message = 'Database is unavailable', originalError?: unknown) {
    super(message);
    this.name = 'DatabaseUnavailableError';
    this.originalError = originalError;
  }
}

export function serviceUnavailableResponse(): NextResponse {
  return NextResponse.json(
    {
      error: 'SERVICE_UNAVAILABLE',
      message: 'The service is temporarily unavailable. Please try again shortly.',
    },
    { status: 503 }
  );
}

/**
 * Shared catch-block helper for every route: DatabaseUnavailableError -> 503
 * { error: 'SERVICE_UNAVAILABLE', message }, anything else -> 500 with the given message.
 */
export function handleApiError(error: unknown, label: string, internalMessage: string): NextResponse {
  if (error instanceof DatabaseUnavailableError) {
    console.error(`[${label}] Database unavailable:`, error.message, error.originalError ?? '');
    return serviceUnavailableResponse();
  }
  console.error(`[${label}] Error:`, error);
  return NextResponse.json({ error: 'INTERNAL_ERROR', message: internalMessage }, { status: 500 });
}
