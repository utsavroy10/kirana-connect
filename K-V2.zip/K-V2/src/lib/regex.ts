/** Escape a user-supplied string so it is matched literally inside a RegExp / Mongo $regex. */
export function escapeRegex(input: string): string {
  return input.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
