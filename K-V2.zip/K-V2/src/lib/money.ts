/** Money is stored in rupees everywhere. Valid amounts: > 0, <= 100000, at most 2 decimals. */
export const MAX_RUPEE_AMOUNT = 100000;

export function isValidRupeeAmount(value: unknown): value is number {
  return (
    typeof value === 'number' &&
    Number.isFinite(value) &&
    value > 0 &&
    value <= MAX_RUPEE_AMOUNT &&
    Math.round(value * 100) / 100 === value
  );
}

export const RUPEE_AMOUNT_RULE = 'greater than ₹0 and at most ₹1,00,000 with at most 2 decimal places';
