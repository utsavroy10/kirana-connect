import { OrderStatus, UserRole } from '@/types';

export const ORDER_STATUS_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  placed: ['accepted', 'cancelled'],
  accepted: ['preparing', 'cancelled'],
  preparing: ['ready_for_pickup', 'cancelled'],
  ready_for_pickup: ['completed', 'cancelled'],
  completed: [],
  cancelled: [],
};

export const VALID_ORDER_STATUSES: OrderStatus[] = [
  'placed',
  'accepted',
  'preparing',
  'ready_for_pickup',
  'completed',
  'cancelled',
];

export function isValidStatus(status: unknown): status is OrderStatus {
  return typeof status === 'string' && VALID_ORDER_STATUSES.includes(status as OrderStatus);
}

export function canTransition(from: OrderStatus, to: OrderStatus): boolean {
  const allowed = ORDER_STATUS_TRANSITIONS[from];
  return Boolean(allowed && allowed.includes(to));
}

export function canRoleTransition(
  role: UserRole,
  from: OrderStatus,
  to: OrderStatus,
  isStoreMerchant: boolean,
  isOrderOwner: boolean
): boolean {
  if (role === 'customer') {
    return isOrderOwner && from === 'placed' && to === 'cancelled';
  }

  if (role === 'merchant') {
    return isStoreMerchant && canTransition(from, to);
  }

  if (role === 'admin') {
    return canTransition(from, to);
  }

  return false;
}

export function isValidPaymentStatus(status: unknown): status is 'PENDING_AT_PICKUP' | 'COLLECTED' {
  return status === 'PENDING_AT_PICKUP' || status === 'COLLECTED';
}
