import 'server-only';
import admin from 'firebase-admin';

function initAdmin() {
  if (admin.apps.length) return;
  const projectId = process.env.FIREBASE_PROJECT_ID || process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  let privateKey = process.env.FIREBASE_PRIVATE_KEY;

  if (privateKey) {
    privateKey = privateKey.replace(/\\n/g, '\n');
  }

  try {
    if (projectId && clientEmail && privateKey) {
      admin.initializeApp({
        credential: admin.credential.cert({ projectId, clientEmail, privateKey }),
      });
    } else {
      admin.initializeApp({ projectId: projectId || 'kirana-connect-poc' });
    }
  } catch (e) {
    console.error('Firebase Admin initialization failed (check FIREBASE_* env values):', e);
  }
}

export function getAdminAuth() {
  initAdmin();
  return admin.auth();
}

export default admin;
