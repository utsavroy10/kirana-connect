export type UserRole = 'customer' | 'merchant' | 'admin';

export type OrderStatus = 
  | 'placed' 
  | 'accepted' 
  | 'preparing' 
  | 'ready_for_pickup' 
  | 'completed' 
  | 'cancelled';

export interface User {
  _id?: string;
  uid: string; // Firebase UID or simulated UID
  phone: string;
  name: string;
  role: UserRole;
  storeId?: string; // If role === 'merchant'
  createdAt: string;
  updatedAt: string;
}

export interface StoreLocation {
  address: string;
  area: string;
  city: string;
  pincode: string;
  landmark?: string;
  lat?: number;
  lng?: number;
}

export interface Store {
  _id?: string;
  id: string; // Slug/code
  name: string;
  tagline?: string;
  description?: string;
  merchantUid: string;
  ownerName: string;
  phone: string;
  location: StoreLocation;
  categories: string[];
  bannerImage?: string;
  isOpen: boolean;
  openingTime: string; // e.g. "08:00 AM"
  closingTime: string; // e.g. "09:30 PM"
  isVerified: boolean;
  commissionRate: number; // e.g. 3.5%
  rating?: number;
  totalOrdersCompleted?: number;
  createdAt: string;
  updatedAt: string;
}

export interface StoreProduct {
  _id?: string;
  id: string;
  storeId: string;
  name: string;
  hindiName?: string;
  brand?: string;
  category: string;
  price: number; // In INR (₹)
  mrp: number; // Original Price for discount display
  unit: string; // e.g., "1 kg", "500 g", "1 litre", "1 packet"
  inStock: boolean;
  isActive?: boolean;
  imageUrl?: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CartItem {
  productId: string;
  name: string;
  hindiName?: string;
  price: number;
  unit: string;
  quantity: number;
  imageUrl?: string;
  storeId: string;
}

export interface Cart {
  _id?: string;
  userId: string;
  storeId: string;
  storeName?: string;
  items: CartItem[];
  itemTotal: number;
  updatedAt: string;
}

export interface PickupSlot {
  id: string;
  label: string; // e.g. "Today, 4:00 PM - 5:00 PM"
  timeRange: string;
  date: string;
  isAvailable: boolean;
  reason?: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  hindiName?: string;
  price: number;
  unit: string;
  quantity: number;
  subtotal: number;
}

export interface OrderStatusHistoryItem {
  status: OrderStatus;
  timestamp: string;
  note?: string;
  changedBy?: string;
  changedByRole?: UserRole;
}

export interface Order {
  _id?: string;
  orderNumber: string; // e.g. "KC-2025-0814"
  userId: string;
  customerName: string;
  customerPhone: string;
  storeId: string;
  storeName: string;
  storePhone: string;
  storeAddress: string;
  items: OrderItem[];
  itemTotal: number;
  platformFee: number; // Zero or nominal (0)
  totalAmount: number; // Amount payable at store (Cash / UPI)
  commissionAmount: number; // platform earnings
  pickupSlot: {
    slotId: string;
    slotLabel: string;
  };
  payment: {
    method: 'PAY_AT_STORE'; // Cash or UPI at pickup
    status: 'PENDING_AT_PICKUP' | 'COLLECTED';
    collectedAt?: string;
  };
  status: OrderStatus;
  statusHistory: OrderStatusHistoryItem[];
  merchantNotes?: string;
  customerNotes?: string;
  createdAt: string;
  updatedAt: string;
}
