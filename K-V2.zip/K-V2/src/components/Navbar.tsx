'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ShoppingBag, Store as StoreIcon, ClipboardList, User, ShieldCheck, MapPin } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';

export const Navbar: React.FC = () => {
  const pathname = usePathname();
  const { role, user, logout } = useAuth();
  const { itemCount } = useCart();

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand */}
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-xl bg-kirana-600 flex items-center justify-center text-white shadow-md shadow-kirana-500/20 group-hover:scale-105 transition-transform">
            <StoreIcon className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xl tracking-tight text-slate-900">
                Kirana<span className="text-kirana-600">Connect</span>
              </span>
              <span className="text-[10px] bg-kirana-100 text-kirana-800 font-bold px-1.5 py-0.5 rounded uppercase">
                Pickup
              </span>
            </div>
            <p className="text-[11px] text-slate-500 hidden sm:block">
              Apne Bagal Ki Dukan Se Fast Pickup
            </p>
          </div>
        </Link>

        {/* Navigation Links based on Role */}
        <nav className="flex items-center gap-2 sm:gap-4">
          {role === 'customer' && (
            <>
              <Link
                href="/"
                className={`text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
                  pathname === '/'
                    ? 'text-kirana-700 bg-kirana-50 font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Stores
              </Link>
              <Link
                href="/orders"
                className={`text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
                  pathname.startsWith('/orders')
                    ? 'text-kirana-700 bg-kirana-50 font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                My Pickups
              </Link>
              <Link
                href="/cart"
                className="relative p-2 text-slate-700 hover:text-kirana-600 bg-slate-100 hover:bg-kirana-50 rounded-xl transition-all"
                title="View Cart"
              >
                <ShoppingBag className="w-5 h-5" />
                {itemCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-kirana-600 text-white font-bold text-xs w-5 h-5 rounded-full flex items-center justify-center shadow-md animate-bounce">
                    {itemCount}
                  </span>
                )}
              </Link>
            </>
          )}

          {role === 'merchant' && (
            <>
              <Link
                href="/merchant"
                className={`text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
                  pathname === '/merchant'
                    ? 'text-amber-800 bg-amber-50 font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Store Dashboard
              </Link>
              <Link
                href="/merchant/catalog"
                className={`text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
                  pathname === '/merchant/catalog'
                    ? 'text-amber-800 bg-amber-50 font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Product Catalog
              </Link>
              <Link
                href="/merchant/dashboard"
                className={`text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
                  pathname === '/merchant/dashboard'
                    ? 'text-amber-800 bg-amber-50 font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Settings
              </Link>
            </>
          )}

          {role === 'admin' && (
            <>
              <Link
                href="/admin"
                className={`text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
                  pathname === '/admin'
                    ? 'text-blue-800 bg-blue-50 font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Overview
              </Link>
              <Link
                href="/admin/merchants"
                className={`text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${
                  pathname === '/admin/merchants'
                    ? 'text-blue-800 bg-blue-50 font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Merchants & Stores
              </Link>
            </>
          )}

          {/* User Profile / Login link */}
          <Link
            href={!user ? '/login' : role === 'merchant' ? '/merchant/dashboard' : role === 'customer' ? '/customer/profile' : '/login'}
            className="flex items-center gap-1.5 text-xs text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-2.5 py-1.5 rounded-lg"
          >
            <User className="w-3.5 h-3.5 text-slate-500" />
            <span className="font-medium hidden sm:inline">
              {user ? user.name || user.phone : 'Sign In'}
            </span>
          </Link>
        </nav>
      </div>
    </header>
  );
};
