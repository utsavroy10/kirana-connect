'use client';

import React from 'react';
import { CheckCircle2, Clock, PackageCheck, ShoppingBag, Check } from 'lucide-react';
import { OrderStatus, OrderStatusHistoryItem } from '@/types';

interface OrderTimelineProps {
  currentStatus: OrderStatus;
  history: OrderStatusHistoryItem[];
}

const STEPS = [
  { key: 'placed', label: 'Order Placed', desc: 'Sent to Kirana Store' },
  { key: 'accepted', label: 'Accepted', desc: 'Shopkeeper confirmed stock' },
  { key: 'preparing', label: 'Packing Items', desc: 'Packed into your bag' },
  { key: 'ready_for_pickup', label: 'Ready for Pickup', desc: 'Visit store & collect' },
  { key: 'completed', label: 'Picked Up & Paid', desc: 'Payment completed at store' },
];

export const OrderTimeline: React.FC<OrderTimelineProps> = ({ currentStatus, history }) => {
  const getStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'placed': return 0;
      case 'accepted': return 1;
      case 'preparing': return 2;
      case 'ready_for_pickup': return 3;
      case 'completed': return 4;
      case 'cancelled': return -1;
      default: return 0;
    }
  };

  const currentIdx = getStepIndex(currentStatus);

  if (currentStatus === 'cancelled') {
    return (
      <div className="bg-red-50 border border-red-200 rounded-2xl p-4 text-center">
        <span className="inline-block px-3 py-1 bg-red-600 text-white font-bold text-xs rounded-full uppercase mb-2">
          Order Cancelled
        </span>
        <p className="text-xs text-red-700">
          This order was cancelled. Items have been restocked at the store.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
      <h3 className="font-bold text-sm text-slate-800 mb-4 flex items-center justify-between">
        <span>Order Status Timeline</span>
        <span className="text-[11px] font-normal text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-kirana-500 animate-pulse" />
          Live Polling Active
        </span>
      </h3>

      <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
        {STEPS.map((step, idx) => {
          const isDone = idx <= currentIdx;
          const isCurrent = idx === currentIdx;
          const historyItem = history.find(h => h.status === step.key);

          return (
            <div key={step.key} className="relative group">
              {/* Dot Icon */}
              <div
                className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                  isDone
                    ? 'bg-kirana-600 border-kirana-600 text-white'
                    : 'bg-white border-slate-300 text-transparent'
                } ${isCurrent ? 'ring-4 ring-kirana-100 scale-110' : ''}`}
              >
                {isDone && <Check className="w-3 h-3 stroke-[3]" />}
              </div>

              {/* Text */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <div>
                  <h4 className={`text-sm font-bold ${isCurrent ? 'text-kirana-700' : isDone ? 'text-slate-800' : 'text-slate-400'}`}>
                    {step.label}
                  </h4>
                  <p className="text-xs text-slate-500">{step.desc}</p>
                </div>

                {historyItem && (
                  <span className="text-[11px] text-slate-400 font-mono">
                    {new Date(historyItem.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
