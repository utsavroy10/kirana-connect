'use client';

import React from 'react';
import Link from 'next/link';
import { MapPin, Clock, CheckCircle2, Star, ShoppingBag, ArrowRight } from 'lucide-react';
import { Store } from '@/types';

interface StoreCardProps {
  store: Store;
}

export const StoreCard: React.FC<StoreCardProps> = ({ store }) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col group">
      {/* Store Banner */}
      <div className="relative h-40 w-full overflow-hidden bg-slate-100">
        <img
          src={store.bannerImage || 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=800&auto=format&fit=crop&q=80'}
          alt={store.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        
        {/* Status badges */}
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          {store.isOpen ? (
            <span className="bg-kirana-600/95 backdrop-blur-md text-white text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
              Open for Pickup
            </span>
          ) : (
            <span className="bg-slate-800/90 backdrop-blur-md text-slate-200 text-[11px] font-medium px-2 py-0.5 rounded-full">
              Closed
            </span>
          )}

          {store.isVerified && (
            <span className="bg-blue-600/90 backdrop-blur-md text-white text-[11px] font-semibold px-2 py-0.5 rounded-full flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              Verified Kirana
            </span>
          )}
        </div>

        {/* Rating */}
        {store.rating && (
          <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-md text-slate-800 text-xs font-bold px-2 py-0.5 rounded-lg flex items-center gap-1 shadow">
            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            {store.rating}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <h3 className="font-bold text-lg text-slate-900 group-hover:text-kirana-700 transition-colors">
            {store.name}
          </h3>
          <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
            {store.tagline || 'Local neighborhood groceries & daily staples'}
          </p>

          <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-600">
            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="truncate">
              {store.location.area}, {store.location.city} ({store.location.landmark || 'Main Road'})
            </span>
          </div>

          <div className="mt-1.5 flex items-center gap-1.5 text-xs text-slate-500">
            <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>Pickup hours: {store.openingTime} - {store.closingTime}</span>
          </div>

          {/* Categories tags */}
          <div className="mt-3 flex flex-wrap gap-1">
            {store.categories.slice(0, 3).map((cat, idx) => (
              <span
                key={idx}
                className="text-[10px] bg-slate-100 text-slate-600 font-medium px-2 py-0.5 rounded-md"
              >
                {cat}
              </span>
            ))}
            {store.categories.length > 3 && (
              <span className="text-[10px] text-slate-400 self-center">
                +{store.categories.length - 3} more
              </span>
            )}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-kirana-700 font-medium">
            No delivery fee • Pay at store
          </span>
          <Link
            href={`/stores/${store.id}`}
            className="inline-flex items-center gap-1 bg-kirana-50 hover:bg-kirana-600 text-kirana-700 hover:text-white px-3 py-1.5 rounded-xl font-semibold text-xs transition-colors"
          >
            Browse Store
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
};
