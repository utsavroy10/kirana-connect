'use client';

import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { useCart } from '@/context/CartContext';

export const SingleStoreConflictModal: React.FC = () => {
  const { conflictModal, resolveConflict } = useCart();

  if (!conflictModal.isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100">
        <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-6 h-6" />
        </div>

        <h3 className="text-lg font-bold text-slate-900 text-center mb-2">
          Replace Cart Items?
        </h3>

        <p className="text-sm text-slate-600 text-center mb-6">
          Your cart currently has items from{' '}
          <strong className="text-slate-900 font-semibold">{conflictModal.currentStoreName}</strong>.
          Kirana Connect orders are pickup-direct from a single neighborhood store at a time.
        </p>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => resolveConflict(false)}
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-medium text-sm hover:bg-slate-50 transition-colors"
          >
            Keep Existing Cart
          </button>
          <button
            onClick={() => resolveConflict(true)}
            className="flex-1 px-4 py-2.5 rounded-xl bg-kirana-600 hover:bg-kirana-700 text-white font-medium text-sm shadow-md shadow-kirana-600/20 transition-colors"
          >
            Discard & Start Fresh
          </button>
        </div>
      </div>
    </div>
  );
};
