'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Store, ShoppingBag, ClipboardList, User } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';

export const MobileBottomNav: React.FC = () => {
  const pathname = usePathname();
  const { role } = useAuth();
  const { itemCount } = useCart();

  if (role !== 'customer') return null;

  return (
    <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-slate-200 shadow-lg px-6 py-2 flex items-center justify-around">
      <Link
        href="/"
        className={`flex flex-col items-center gap-1 ${
          pathname === '/' ? 'text-kirana-600 font-bold' : 'text-slate-500'
        }`}
      >
        <Store className="w-5 h-5" />
        <span className="text-[11px]">Stores</span>
      </Link>

      <Link
        href="/cart"
        className={`flex flex-col items-center gap-1 relative ${
          pathname === '/cart' ? 'text-kirana-600 font-bold' : 'text-slate-500'
        }`}
      >
        <div className="relative">
          <ShoppingBag className="w-5 h-5" />
          {itemCount > 0 && (
            <span className="absolute -top-1.5 -right-2 bg-kirana-600 text-white font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
              {itemCount}
            </span>
          )}
        </div>
        <span className="text-[11px]">Cart</span>
      </Link>

      <Link
        href="/orders"
        className={`flex flex-col items-center gap-1 ${
          pathname.startsWith('/orders') ? 'text-kirana-600 font-bold' : 'text-slate-500'
        }`}
      >
        <ClipboardList className="w-5 h-5" />
        <span className="text-[11px]">Orders</span>
      </Link>

      <Link
        href="/customer/profile"
        className={`flex flex-col items-center gap-1 ${
          pathname === '/customer/profile' || pathname === '/login' ? 'text-kirana-600 font-bold' : 'text-slate-500'
        }`}
      >
        <User className="w-5 h-5" />
        <span className="text-[11px]">Account</span>
      </Link>
    </div>
  );
};
