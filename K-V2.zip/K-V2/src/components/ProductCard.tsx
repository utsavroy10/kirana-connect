'use client';

import React from 'react';
import { Plus, Minus, Check } from 'lucide-react';
import { StoreProduct } from '@/types';
import { useCart } from '@/context/CartContext';

interface ProductCardProps {
  product: StoreProduct;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { getItemQuantity, addToCart, updateQuantity } = useCart();
  const quantity = getItemQuantity(product.id);

  const discountPercent = product.mrp > product.price
    ? Math.round(((product.mrp - product.price) / product.mrp) * 100)
    : 0;

  return (
    <div className={`bg-white rounded-2xl border ${product.inStock ? 'border-slate-200/80 shadow-sm' : 'border-slate-200 opacity-75'} p-3.5 flex flex-col justify-between hover:shadow-md transition-all relative`}>
      {discountPercent > 0 && (
        <span className="absolute top-2 left-2 z-10 bg-amber-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-md shadow-sm">
          {discountPercent}% OFF
        </span>
      )}

      {/* Product Image */}
      <div className="relative h-32 w-full rounded-xl overflow-hidden bg-slate-50 mb-3 flex items-center justify-center">
        <img
          src={product.imageUrl || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&auto=format&fit=crop&q=80'}
          alt={product.name}
          className="w-full h-full object-cover"
        />
        {!product.inStock && (
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-[2px] flex items-center justify-center">
            <span className="bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
              Out of Stock
            </span>
          </div>
        )}
      </div>

      {/* Details */}
      <div className="flex-1 flex flex-col justify-between">
        <div>
          <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
            {product.brand || product.category}
          </span>
          <h4 className="font-semibold text-sm text-slate-900 line-clamp-2 leading-snug">
            {product.name}
          </h4>
          {product.hindiName && (
            <p className="text-xs text-kirana-700 font-medium mt-0.5">
              {product.hindiName}
            </p>
          )}
          <span className="inline-block mt-1 text-xs text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
            {product.unit}
          </span>
        </div>

        {/* Price & Action */}
        <div className="mt-4 pt-2 border-t border-slate-100 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-base font-extrabold text-slate-900">
                ₹{product.price}
              </span>
              {product.mrp > product.price && (
                <span className="text-xs text-slate-400 line-through">
                  ₹{product.mrp}
                </span>
              )}
            </div>
          </div>

          {/* Add / Quantity Controller */}
          {product.inStock ? (
            quantity === 0 ? (
              <button
                onClick={() => addToCart(product, 1)}
                className="bg-kirana-50 hover:bg-kirana-600 text-kirana-700 hover:text-white font-bold text-xs px-3.5 py-1.5 rounded-xl border border-kirana-300 hover:border-transparent transition-all flex items-center gap-1 shadow-sm active:scale-95"
              >
                <Plus className="w-3.5 h-3.5" />
                ADD
              </button>
            ) : (
              <div className="flex items-center bg-kirana-600 text-white rounded-xl shadow-sm overflow-hidden">
                <button
                  onClick={() => updateQuantity(product.id, quantity - 1)}
                  className="px-2 py-1.5 hover:bg-kirana-700 transition-colors"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="px-2 font-bold text-xs min-w-[20px] text-center">
                  {quantity}
                </span>
                <button
                  onClick={() => updateQuantity(product.id, quantity + 1)}
                  className="px-2 py-1.5 hover:bg-kirana-700 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            )
          ) : (
            <span className="text-xs text-slate-400 font-medium">Unavailable</span>
          )}
        </div>
      </div>
    </div>
  );
};
