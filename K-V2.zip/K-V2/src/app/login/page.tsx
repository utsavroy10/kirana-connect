'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Phone, KeyRound, Sparkles, ShieldCheck, Store, Check, ArrowRight, User, AlertCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { UserRole } from '@/types';
import { auth } from '@/lib/firebaseClient';
import { RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from 'firebase/auth';

export default function LoginPage() {
  const router = useRouter();
  const { user, loginWithDemo, syncFirebaseUser, logout } = useAuth();
  const isDemoEnabled = process.env.NEXT_PUBLIC_ENABLE_DEMO === 'true';

  const [phone, setPhone] = useState<string>('9811122233');
  const [otp, setOtp] = useState<string>('');
  const [role, setRole] = useState<UserRole>('customer');
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);

  const recaptchaVerifierRef = useRef<RecaptchaVerifier | null>(null);

  useEffect(() => {
    // Cleanup recaptcha on unmount
    return () => {
      if (recaptchaVerifierRef.current) {
        try {
          recaptchaVerifierRef.current.clear();
        } catch (e) {
          // Component is unmounting; there is no UI state to update, so only log.
          console.error('Failed to clear reCAPTCHA verifier:', e);
        }
      }
    };
  }, []);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length < 10) return;
    setLoading(true);
    setErrorMsg('');

    const fullPhone = phone.startsWith('+91') ? phone : `+91${phone}`;

    // Check if Firebase is configured with real API key
    const isRealFirebase = process.env.NEXT_PUBLIC_FIREBASE_API_KEY && !process.env.NEXT_PUBLIC_FIREBASE_API_KEY.includes('Fake');

    if (isRealFirebase) {
      try {
        if (!recaptchaVerifierRef.current) {
          recaptchaVerifierRef.current = new RecaptchaVerifier(auth, 'recaptcha-container', {
            size: 'invisible',
          });
        }

        const confirmation = await signInWithPhoneNumber(auth, fullPhone, recaptchaVerifierRef.current);
        setConfirmationResult(confirmation);
        setOtpSent(true);
      } catch (err: any) {
        console.warn('Real Firebase Phone Auth failed or unconfigured:', err);
        if (isDemoEnabled) {
          setErrorMsg(err.message || 'Firebase error. Switched to demo OTP.');
          setOtpSent(true);
          setOtp('123456');
        } else {
          setErrorMsg('Phone login is unavailable right now. Please try again.');
        }
      } finally {
        setLoading(false);
      }
    } else {
      // Firebase not configured with real key
      if (isDemoEnabled) {
        setTimeout(() => {
          setOtpSent(true);
          setOtp('123456');
          setLoading(false);
        }, 500);
      } else {
        setErrorMsg('Phone login is unavailable right now. Please try again.');
        setLoading(false);
      }
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');

    try {
      if (confirmationResult && otp !== '123456') {
        const userCredential = await confirmationResult.confirm(otp);
        await syncFirebaseUser(userCredential.user);
      } else if (isDemoEnabled) {
        const fullPhone = phone.startsWith('+91') ? phone : `+91${phone}`;
        loginWithDemo(role, fullPhone);
      } else {
        setErrorMsg('Phone login is unavailable right now. Please try again.');
        setLoading(false);
        return;
      }

      if (role === 'merchant') router.push('/merchant');
      else if (role === 'admin') router.push('/admin');
      else router.push('/');
    } catch (err: any) {
      setErrorMsg(err.message || 'Invalid OTP code.');
    } finally {
      setLoading(false);
    }
  };

  const handleOneClickPersona = (selectedRole: UserRole) => {
    loginWithDemo(selectedRole);
    if (selectedRole === 'merchant') router.push('/merchant');
    else if (selectedRole === 'admin') router.push('/admin');
    else router.push('/');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-12">
      <div id="recaptcha-container"></div>
      <div className="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-sm">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-kirana-600 flex items-center justify-center text-white mx-auto mb-3 shadow-md shadow-kirana-500/20">
            <Store className="w-6 h-6" />
          </div>
          <h1 className="text-xl font-extrabold text-slate-900">
            Sign In to Kirana Connect
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Mobile OTP Login for Customers, Merchants & Operators
          </p>
        </div>

        {errorMsg && (
          <div className="mb-4 p-2.5 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {user ? (
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-kirana-100 text-kirana-700 flex items-center justify-center mx-auto">
              <Check className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs text-slate-500">Currently Logged In As</p>
              <h3 className="font-bold text-slate-900 text-sm mt-0.5">{user.name}</h3>
              <p className="text-xs text-slate-600 font-mono">{user.phone}</p>
              <span className="inline-block mt-2 text-[11px] font-bold uppercase bg-kirana-100 text-kirana-800 px-2 py-0.5 rounded">
                Role: {user.role}
              </span>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => {
                  if (user.role === 'merchant') router.push('/merchant');
                  else if (user.role === 'admin') router.push('/admin');
                  else router.push('/');
                }}
                className="w-full bg-kirana-600 hover:bg-kirana-700 text-white font-bold text-xs py-2.5 rounded-xl shadow transition-colors"
              >
                Go to Dashboard
              </button>
              <button
                onClick={logout}
                className="w-full border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold text-xs py-2 rounded-xl transition-colors"
              >
                Sign Out
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Phone Login Form */}
            {!otpSent ? (
              <form onSubmit={handleSendOtp} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Select Your Role
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['customer', 'merchant', 'admin'] as UserRole[]).map((r) => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRole(r)}
                        className={`py-2 text-xs font-bold rounded-xl border capitalize transition-all ${
                          role === r
                            ? 'bg-kirana-50 border-kirana-600 text-kirana-800 ring-2 ring-kirana-500/20'
                            : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Mobile Number
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-500">
                      +91
                    </span>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-3 py-2 text-xs font-mono font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-kirana-500"
                      placeholder="9876543210"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading || phone.length < 10}
                  className="w-full bg-kirana-600 hover:bg-kirana-700 text-white font-bold text-xs py-3 rounded-xl shadow-md transition-all disabled:opacity-50"
                >
                  {loading ? 'Sending OTP...' : 'Send OTP via Firebase Phone Auth'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-4">
                <div className="text-center bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <p className="text-xs text-slate-500">OTP sent to +91 {phone}</p>
                  <span className="text-[11px] font-mono text-kirana-700 font-bold">
                    (Enter OTP received on mobile)
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Enter 6-Digit OTP
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-center text-lg font-mono font-bold tracking-widest text-slate-800 focus:outline-none focus:ring-2 focus:ring-kirana-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading || otp.length < 6}
                  className="w-full bg-kirana-600 hover:bg-kirana-700 text-white font-bold text-xs py-3 rounded-xl shadow-md transition-all"
                >
                  {loading ? 'Verifying...' : 'Verify OTP & Log In'}
                </button>

                <button
                  type="button"
                  onClick={() => setOtpSent(false)}
                  className="w-full text-center text-xs text-slate-500 hover:text-slate-800"
                >
                  Change Mobile Number
                </button>
              </form>
            )}

            {/* Fast 1-Click Evaluation Personas (Shown only when NEXT_PUBLIC_ENABLE_DEMO === 'true') */}
            {isDemoEnabled && (
              <div className="mt-8 pt-6 border-t border-slate-100">
                <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 text-center">
                  ⚡ 1-Click POC Demo Profiles
                </p>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => handleOneClickPersona('customer')}
                    className="w-full p-2.5 rounded-xl border border-slate-200 hover:border-kirana-500 text-left hover:bg-kirana-50/50 flex items-center justify-between text-xs transition-colors"
                  >
                    <div>
                      <span className="font-bold text-slate-800">Aman Sharma</span>
                      <p className="text-[10px] text-slate-500">Customer (Browse & Pickup)</p>
                    </div>
                    <span className="text-kirana-600 font-bold">Log in &rarr;</span>
                  </button>

                  <button
                    onClick={() => handleOneClickPersona('merchant')}
                    className="w-full p-2.5 rounded-xl border border-slate-200 hover:border-amber-500 text-left hover:bg-amber-50/50 flex items-center justify-between text-xs transition-colors"
                  >
                    <div>
                      <span className="font-bold text-slate-800">Ram Prasad Gupta</span>
                      <p className="text-[10px] text-slate-500">Merchant (Gupta Kirana Store)</p>
                    </div>
                    <span className="text-amber-600 font-bold">Log in &rarr;</span>
                  </button>

                  <button
                    onClick={() => handleOneClickPersona('admin')}
                    className="w-full p-2.5 rounded-xl border border-slate-200 hover:border-blue-500 text-left hover:bg-blue-50/50 flex items-center justify-between text-xs transition-colors"
                  >
                    <div>
                      <span className="font-bold text-slate-800">Platform Admin</span>
                      <p className="text-[10px] text-slate-500">Approvals & Governance</p>
                    </div>
                    <span className="text-blue-600 font-bold">Log in &rarr;</span>
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
