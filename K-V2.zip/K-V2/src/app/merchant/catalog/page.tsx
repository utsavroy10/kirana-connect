'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  Plus,
  Package,
  Edit2,
  Trash2,
  Check,
  X,
  Search,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  DollarSign,
  Layers,
  Power
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { StoreProduct } from '@/types';
import { ALLOWED_PRODUCT_CATEGORIES } from '@/app/api/merchant/products/route';

export default function MerchantCatalogPage() {
  const { user, token } = useAuth();
  const [products, setProducts] = useState<StoreProduct[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states (Prices in Rupees on UI)
  const [name, setName] = useState<string>('');
  const [hindiName, setHindiName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [category, setCategory] = useState<string>('Atta & Flour');
  const [priceRupees, setPriceRupees] = useState<string>('100');
  const [mrpRupees, setMrpRupees] = useState<string>('110');
  const [unit, setUnit] = useState<string>('1 kg');
  const [inStock, setInStock] = useState<boolean>(true);

  // Editing state
  const [editPriceRupees, setEditPriceRupees] = useState<string>('');
  const [editMrpRupees, setEditMrpRupees] = useState<string>('');
  const [editName, setEditName] = useState<string>('');
  const [editUnit, setEditUnit] = useState<string>('');

  // Notifications
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      setErrorMsg('');
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/merchant/products', { headers });
      if (res.ok) {
        const data = await res.json();
        setProducts(data.products || []);
      } else {
        const data = await res.json();
        setErrorMsg(data.message || 'Failed to fetch catalog');
      }
    } catch (e: any) {
      console.error('Error fetching merchant products:', e);
      setErrorMsg('Failed to load store products');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [token]);

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const priceNum = parseFloat(priceRupees);
    const mrpNum = parseFloat(mrpRupees);

    if (isNaN(priceNum) || priceNum < 1 || priceNum > 100000) {
      setErrorMsg('Selling price must be between ₹1 and ₹1,00,000');
      return;
    }

    if (isNaN(mrpNum) || mrpNum < priceNum) {
      setErrorMsg('MRP must be greater than or equal to selling price');
      return;
    }

    // Convert Rupees to integer Paise
    const pricePaise = Math.round(priceNum * 100);
    const mrpPaise = Math.round(mrpNum * 100);

    try {
      setSubmitting(true);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/merchant/products', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          name: name.trim(),
          hindiName: hindiName.trim() || undefined,
          description: description.trim() || undefined,
          category,
          price: pricePaise,
          mrp: mrpPaise,
          unit: unit.trim(),
          inStock,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || data.error || 'Failed to create product');
      }

      setProducts((prev) => [data.product, ...prev]);
      setSuccessMsg(`"${data.product.name}" added to catalog!`);
      setIsAddingNew(false);
      // Reset form
      setName('');
      setHindiName('');
      setDescription('');
      setPriceRupees('100');
      setMrpRupees('110');
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Something went wrong');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleStock = async (product: StoreProduct) => {
    const nextStock = !product.inStock;
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/merchant/products/${product.id}/stock`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ inStock: nextStock }),
      });

      if (res.ok) {
        const data = await res.json();
        setProducts((prev) =>
          prev.map((p) => (p.id === product.id ? data.product : p))
        );
      }
    } catch (e) {
      console.error('Failed to toggle stock', e);
    }
  };

  const startEditing = (p: StoreProduct) => {
    setEditingId(p.id);
    // Convert paise to rupees for display
    const currentPriceRs = p.price > 1000 ? (p.price / 100).toString() : p.price.toString();
    const currentMrpRs = (p.mrp || p.price) > 1000 ? ((p.mrp || p.price) / 100).toString() : (p.mrp || p.price).toString();
    setEditPriceRupees(currentPriceRs);
    setEditMrpRupees(currentMrpRs);
    setEditName(p.name);
    setEditUnit(p.unit);
  };

  const handleSaveEdit = async (productId: string) => {
    const priceNum = parseFloat(editPriceRupees);
    const mrpNum = parseFloat(editMrpRupees);

    if (isNaN(priceNum) || priceNum < 1) {
      setErrorMsg('Valid price in Rupees is required');
      return;
    }

    const pricePaise = Math.round(priceNum * 100);
    const mrpPaise = Math.round((mrpNum || priceNum) * 100);

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/merchant/products/${productId}`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({
          name: editName.trim(),
          unit: editUnit.trim(),
          price: pricePaise,
          mrp: mrpPaise,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || 'Failed to update product');
      }

      setProducts((prev) =>
        prev.map((p) => (p.id === productId ? data.product : p))
      );
      setEditingId(null);
      setSuccessMsg('Product updated successfully!');
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to save product');
    }
  };

  const handleDeleteProduct = async (product: StoreProduct) => {
    if (!confirm(`Are you sure you want to remove "${product.name}" from your catalog?`)) {
      return;
    }

    try {
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/merchant/products/${product.id}`, {
        method: 'DELETE',
        headers,
      });

      if (res.ok) {
        setProducts((prev) => prev.filter((p) => p.id !== product.id));
        setSuccessMsg(`"${product.name}" removed from catalog`);
        setTimeout(() => setSuccessMsg(''), 3000);
      }
    } catch (e) {
      console.error('Delete product failed', e);
    }
  };

  const formatPriceDisplay = (price: number) => {
    // If stored as paise (> 1000 or from new catalog), divide by 100; else rupees
    if (price >= 100) {
      // Check if likely paise or rupee integer
      return (price / 100).toFixed(0);
    }
    return price.toString();
  };

  const filteredProducts = products.filter((p) => {
    if (selectedCategory !== 'All' && p.category !== selectedCategory) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = p.name.toLowerCase().includes(q);
      const matchHindi = p.hindiName?.toLowerCase().includes(q);
      const matchCat = p.category.toLowerCase().includes(q);
      return matchName || matchHindi || matchCat;
    }
    return true;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 space-y-6">
      {/* Navigation */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200">
        <Link
          href="/merchant"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Orders Dashboard
        </Link>

        <div className="flex items-center gap-2">
          <Link
            href="/merchant/dashboard"
            className="text-xs font-semibold text-amber-800 hover:underline px-2.5 py-1"
          >
            Store Settings
          </Link>
          <button
            onClick={fetchProducts}
            className="p-1.5 text-slate-500 hover:text-amber-800 rounded-lg hover:bg-slate-100 flex items-center gap-1 text-xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Banner */}
      <div className="bg-amber-950 text-white rounded-3xl p-6 shadow-xl border border-amber-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded-md uppercase">
            Store Catalog Management
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">
            Products & Inventory Catalog
          </h1>
          <p className="text-xs text-amber-200/80 mt-1">
            Add grocery items, update daily rates in Rupees, and manage live shelf availability.
          </p>
        </div>

        <button
          onClick={() => setIsAddingNew(!isAddingNew)}
          className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow transition-colors flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          {isAddingNew ? 'Close Form' : 'Add New Item'}
        </button>
      </div>

      {successMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          {successMsg}
        </div>
      )}

      {errorMsg && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
          {errorMsg}
        </div>
      )}

      {/* Add New Product Drawer */}
      {isAddingNew && (
        <div className="bg-white rounded-2xl border border-amber-200 p-6 shadow-md space-y-4">
          <h2 className="text-sm font-bold text-slate-900 pb-2 border-b border-slate-100 flex items-center gap-2">
            <Plus className="w-4 h-4 text-amber-700" />
            Add New Grocery Product
          </h2>

          <form onSubmit={handleCreateProduct} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  required
                  maxLength={150}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="e.g. Fortune Mustard Oil"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Hindi Name (Optional)
                </label>
                <input
                  type="text"
                  value={hindiName}
                  onChange={(e) => setHindiName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="e.g. सरसों का तेल"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Category *
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  {ALLOWED_PRODUCT_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Selling Price (₹) *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max="100000"
                  step="0.01"
                  value={priceRupees}
                  onChange={(e) => setPriceRupees(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  placeholder="145"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  MRP (₹) *
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max="100000"
                  step="0.01"
                  value={mrpRupees}
                  onChange={(e) => setMrpRupees(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  placeholder="165"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Unit Specification *
                </label>
                <input
                  type="text"
                  required
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="e.g. 1 litre, 500g, 1 kg"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Description (Optional)
              </label>
              <input
                type="text"
                maxLength={500}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="Brief item description or packing quality note"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                <input
                  type="checkbox"
                  checked={inStock}
                  onChange={(e) => setInStock(e.target.checked)}
                  className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
                />
                Mark as In-Stock immediately
              </label>

              <button
                type="submit"
                disabled={submitting}
                className="bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold px-5 py-2.5 rounded-xl shadow transition-colors flex items-center gap-1.5 disabled:opacity-50"
              >
                <Check className="w-4 h-4" />
                {submitting ? 'Adding...' : 'Save Product'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-slate-200 shadow-sm">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
            placeholder="Search items by name / category..."
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto scrollbar-none pb-1 sm:pb-0">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
              selectedCategory === 'All'
                ? 'bg-amber-700 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Items ({products.length})
          </button>
          {ALLOWED_PRODUCT_CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-amber-700 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Catalog Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            Catalog Items ({filteredProducts.length})
          </h3>
          <span className="text-[11px] text-slate-400">
            Prices displayed in Indian Rupees (₹)
          </span>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="p-12 text-center">
            <Package className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="font-bold text-slate-800 text-sm">No products found</h4>
            <p className="text-xs text-slate-500 mt-1">
              Add your first item using the button above or adjust your search filter.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filteredProducts.map((p) => {
              const isEditing = editingId === p.id;
              // Format display price (support paise or rupees)
              const priceDisplay = p.price >= 100 ? Math.round(p.price / 100) : p.price;
              const mrpDisplay = (p.mrp || p.price) >= 100 ? Math.round((p.mrp || p.price) / 100) : (p.mrp || p.price);

              return (
                <div
                  key={p.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/60 transition-colors"
                >
                  {/* Left: Product Info */}
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900">{p.name}</span>
                      {p.hindiName && (
                        <span className="text-[11px] text-amber-800 font-medium">
                          ({p.hindiName})
                        </span>
                      )}
                      <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono">
                        {p.unit}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-slate-500">
                      <span className="font-medium text-slate-600">{p.category}</span>
                      {p.description && <span>• {p.description}</span>}
                    </div>
                  </div>

                  {/* Middle: Prices & Stock */}
                  <div className="flex items-center gap-4">
                    {isEditing ? (
                      <div className="flex items-center gap-2">
                        <div>
                          <label className="text-[10px] text-slate-400 block">Rate (₹)</label>
                          <input
                            type="number"
                            min="1"
                            step="1"
                            value={editPriceRupees}
                            onChange={(e) => setEditPriceRupees(e.target.value)}
                            className="w-18 bg-white border border-amber-300 rounded-lg px-2 py-1 text-xs font-mono font-bold"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] text-slate-400 block">MRP (₹)</label>
                          <input
                            type="number"
                            min="1"
                            step="1"
                            value={editMrpRupees}
                            onChange={(e) => setEditMrpRupees(e.target.value)}
                            className="w-18 bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs font-mono"
                          />
                        </div>

                        <button
                          onClick={() => handleSaveEdit(p.id)}
                          className="p-1.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 mt-3"
                          title="Save Rate"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="p-1.5 bg-slate-200 text-slate-600 rounded-lg hover:bg-slate-300 mt-3"
                          title="Cancel"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="text-sm font-extrabold text-slate-900">
                            ₹{priceDisplay}
                          </div>
                          {mrpDisplay > priceDisplay && (
                            <div className="text-[10px] text-slate-400 line-through">
                              MRP ₹{mrpDisplay}
                            </div>
                          )}
                        </div>

                        <button
                          onClick={() => startEditing(p)}
                          className="p-1.5 text-slate-400 hover:text-amber-700 rounded-lg hover:bg-amber-50"
                          title="Edit Rate & Name"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {/* Stock Status Toggle */}
                    <button
                      onClick={() => handleToggleStock(p)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                        p.inStock
                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                          : 'bg-red-100 text-red-800 hover:bg-red-200'
                      }`}
                    >
                      <Power className="w-3 h-3" />
                      {p.inStock ? 'In Stock' : 'Out of Stock'}
                    </button>

                    {/* Delete action */}
                    <button
                      onClick={() => handleDeleteProduct(p)}
                      className="p-1.5 text-slate-300 hover:text-red-600 rounded-lg hover:bg-red-50"
                      title="Delete Product"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
