'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Store,
  Clock,
  Phone,
  CheckCircle2,
  XCircle,
  Package,
  Sparkles,
  ShoppingBag,
  RefreshCw,
  Layers,
  Banknote,
  AlertCircle
} from 'lucide-react';
import { Order, OrderStatus } from '@/types';
import { useAuth } from '@/context/AuthContext';

export default function MerchantDashboardPage() {
  const { user, token } = useAuth();
  const storeId = user?.storeId || 'store_shree_ram';

  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'all' | 'new' | 'active' | 'ready' | 'completed'>('new');
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const fetchMerchantOrders = async (isBackground = false) => {
    try {
      if (!isBackground) setLoading(true);
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/orders?storeId=${storeId}`, { headers });
      if (res.ok) {
        const data = await res.json();
        setOrders(data.orders || []);
        setLastUpdated(new Date());
      }
    } catch (err) {
      console.error('Failed to fetch merchant orders', err);
    } finally {
      if (!isBackground) setLoading(false);
    }
  };

  useEffect(() => {
    fetchMerchantOrders();
    const interval = setInterval(() => {
      fetchMerchantOrders(true);
    }, 4000);
    return () => clearInterval(interval);
  }, [storeId, token]);

  const updateOrderStatus = async (
    orderId: string,
    newStatus: OrderStatus,
    note?: string,
    paymentStatus?: 'COLLECTED'
  ) => {
    try {
      setUpdatingId(orderId);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({
          status: newStatus,
          note,
          paymentStatus,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setOrders(prev => prev.map(o => o.orderNumber === orderId ? data.order : o));
      } else {
        await fetchMerchantOrders(true);
      }
    } catch (e) {
      console.error('Order status update failed', e);
    } finally {
      setUpdatingId(null);
    }
  };

  // Metrics
  const placedCount = orders.filter(o => o.status === 'placed').length;
  const preparingCount = orders.filter(o => o.status === 'accepted' || o.status === 'preparing').length;
  const readyCount = orders.filter(o => o.status === 'ready_for_pickup').length;
  const completedOrders = orders.filter(o => o.status === 'completed');
  const totalRevenue = completedOrders.reduce((sum, o) => sum + o.totalAmount, 0);

  const filteredOrders = orders.filter(order => {
    if (activeTab === 'new') return order.status === 'placed';
    if (activeTab === 'active') return order.status === 'accepted' || order.status === 'preparing';
    if (activeTab === 'ready') return order.status === 'ready_for_pickup';
    if (activeTab === 'completed') return order.status === 'completed' || order.status === 'cancelled';
    return true;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 space-y-6">
      {/* Merchant Header */}
      <div className="bg-amber-950 text-white rounded-3xl p-6 shadow-xl border border-amber-900 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded-md uppercase">
              Merchant Order Management
            </span>
            <span className="text-xs text-amber-300">🏪 Gupta Kirana & General Store</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">
            Store Orders Dashboard
          </h1>
          <p className="text-xs text-amber-200/80 mt-1">
            Accept incoming orders, pack items, notify customers & collect cash/UPI at pickup.
          </p>
        </div>

        <div className="flex items-center gap-3 self-stretch md:self-auto justify-between md:justify-end flex-wrap">
          <Link
            href="/merchant/catalog"
            className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl shadow transition-colors flex items-center gap-1.5"
          >
            Product Catalog
          </Link>
          <Link
            href="/merchant/dashboard"
            className="bg-amber-900/80 hover:bg-amber-800 text-amber-100 font-bold text-xs px-3.5 py-2.5 rounded-xl border border-amber-700 transition-colors"
          >
            Store Settings
          </Link>
          <Link
            href="/merchant/inventory"
            className="bg-amber-800 hover:bg-amber-700 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl border border-amber-700 transition-colors"
          >
            Quick Rates
          </Link>
          <button
            onClick={() => fetchMerchantOrders(false)}
            className="p-2.5 bg-amber-900/60 hover:bg-amber-900 text-amber-200 rounded-xl border border-amber-800"
            title="Refresh Orders"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Quick Summary Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
          <p className="text-xs font-bold text-slate-500">New Incoming</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className={`text-2xl font-extrabold ${placedCount > 0 ? 'text-amber-600 animate-pulse' : 'text-slate-800'}`}>
              {placedCount}
            </span>
            <span className="text-[11px] text-slate-400">awaiting action</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
          <p className="text-xs font-bold text-slate-500">Packing & Prep</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-extrabold text-blue-600">
              {preparingCount}
            </span>
            <span className="text-[11px] text-slate-400">in progress</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
          <p className="text-xs font-bold text-slate-500">Ready for Pickup</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-extrabold text-kirana-600">
              {readyCount}
            </span>
            <span className="text-[11px] text-slate-400">at counter</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
          <p className="text-xs font-bold text-slate-500">Completed Sales</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-extrabold text-slate-900">
              ₹{totalRevenue}
            </span>
            <span className="text-[11px] text-slate-400">({completedOrders.length} orders)</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('new')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
            activeTab === 'new'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          <span>New Orders</span>
          {placedCount > 0 && (
            <span className="bg-white text-amber-700 text-[10px] px-1.5 py-0.2 rounded-full font-extrabold">
              {placedCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('active')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
            activeTab === 'active'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          <span>Packing ({preparingCount})</span>
        </button>

        <button
          onClick={() => setActiveTab('ready')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
            activeTab === 'ready'
              ? 'bg-kirana-600 text-white shadow-sm'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          <span>Ready for Pickup ({readyCount})</span>
        </button>

        <button
          onClick={() => setActiveTab('completed')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'completed'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          Completed & History
        </button>

        <button
          onClick={() => setActiveTab('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'all'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          All ({orders.length})
        </button>
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
            <Package className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h3 className="font-bold text-slate-800 text-sm">No orders in this tab</h3>
            <p className="text-xs text-slate-500 mt-1">
              New customer pickup orders will appear here automatically via live polling.
            </p>
          </div>
        ) : (
          filteredOrders.map((order) => {
            const isUpdating = updatingId === order.orderNumber;

            return (
              <div
                key={order.orderNumber}
                className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-sm space-y-4"
              >
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-100 gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-extrabold text-slate-900 bg-slate-100 px-2.5 py-0.5 rounded">
                      #{order.orderNumber}
                    </span>
                    <span className="text-xs text-slate-500">
                      • {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-kirana-600" />
                      Pickup Slot: <strong className="text-slate-900">{order.pickupSlot.slotLabel}</strong>
                    </span>
                  </div>
                </div>

                {/* Customer Details */}
                <div className="flex flex-col sm:flex-row justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs">
                  <div>
                    <span className="text-slate-500 font-medium">Customer:</span>{' '}
                    <strong className="text-slate-900">{order.customerName}</strong>
                    <a
                      href={`tel:${order.customerPhone}`}
                      className="ml-3 inline-flex items-center gap-1 text-kirana-700 font-bold hover:underline"
                    >
                      <Phone className="w-3 h-3" />
                      {order.customerPhone}
                    </a>
                  </div>

                  {order.customerNotes && (
                    <div className="text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      <strong>Customer Note:</strong> {order.customerNotes}
                    </div>
                  )}
                </div>

                {/* Items to Pack */}
                <div className="bg-slate-50/50 rounded-xl p-3 border border-slate-100">
                  <h4 className="text-xs font-bold text-slate-700 mb-2">
                    Items to Pack ({order.items.length}):
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {order.items.map((item, idx) => (
                      <div
                        key={idx}
                        className="bg-white p-2 rounded-lg border border-slate-200/60 flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-800">{item.name}</span>
                          {item.hindiName && <span className="text-kirana-700 ml-1">({item.hindiName})</span>}
                          <p className="text-[11px] text-slate-500">
                            Unit: {item.unit} • Rate: ₹{item.price}
                          </p>
                        </div>
                        <span className="bg-kirana-100 text-kirana-800 font-extrabold text-xs px-2 py-1 rounded-md">
                          Qty: {item.quantity}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Amount & Status Action Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="text-xs">
                      <span className="text-slate-500">Order Total:</span>{' '}
                      <strong className="text-base font-extrabold text-slate-900">₹{order.totalAmount}</strong>
                    </div>
                    <span className="text-[11px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono">
                      Pay at Pickup ({order.payment.status === 'COLLECTED' ? 'Paid' : 'Unpaid'})
                    </span>
                  </div>

                  {/* Status Action Buttons */}
                  <div className="flex flex-wrap items-center gap-2">
                    {order.status === 'placed' && (
                      <>
                        <button
                          onClick={() => updateOrderStatus(order.orderNumber, 'cancelled', 'Stock unavailable / Merchant declined')}
                          disabled={isUpdating}
                          className="px-3 py-1.5 rounded-xl border border-red-300 text-red-600 hover:bg-red-50 text-xs font-bold transition-colors"
                        >
                          Decline
                        </button>
                        <button
                          onClick={() => updateOrderStatus(order.orderNumber, 'accepted', 'Store accepted order and is confirming items')}
                          disabled={isUpdating}
                          className="px-4 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow transition-colors"
                        >
                          {isUpdating ? 'Updating...' : 'Accept Order'}
                        </button>
                      </>
                    )}

                    {order.status === 'accepted' && (
                      <button
                        onClick={() => updateOrderStatus(order.orderNumber, 'preparing', 'Merchant started packing order in bags')}
                        disabled={isUpdating}
                        className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow transition-colors flex items-center gap-1.5"
                      >
                        <Package className="w-3.5 h-3.5" />
                        {isUpdating ? 'Updating...' : 'Start Packing Items'}
                      </button>
                    )}

                    {order.status === 'preparing' && (
                      <button
                        onClick={() => updateOrderStatus(order.orderNumber, 'ready_for_pickup', 'Items packed and kept on counter for pickup')}
                        disabled={isUpdating}
                        className="px-4 py-1.5 rounded-xl bg-kirana-600 hover:bg-kirana-700 text-white text-xs font-bold shadow transition-colors flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {isUpdating ? 'Updating...' : 'Mark Ready for Pickup'}
                      </button>
                    )}

                    {order.status === 'ready_for_pickup' && (
                      <button
                        onClick={() => updateOrderStatus(order.orderNumber, 'completed', 'Order picked up by customer, payment collected', 'COLLECTED')}
                        disabled={isUpdating}
                        className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow transition-colors flex items-center gap-1.5"
                      >
                        <Banknote className="w-3.5 h-3.5" />
                        {isUpdating ? 'Updating...' : 'Mark Picked Up & Paid'}
                      </button>
                    )}

                    {order.status === 'completed' && (
                      <span className="text-xs font-bold text-kirana-700 bg-kirana-50 border border-kirana-200 px-3 py-1 rounded-lg flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Completed & Settled
                      </span>
                    )}

                    {order.status === 'cancelled' && (
                      <span className="text-xs font-bold text-red-700 bg-red-50 border border-red-200 px-3 py-1 rounded-lg">
                        Cancelled
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
