'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  Store,
  User,
  Clock,
  Phone,
  MapPin,
  FileText,
  Save,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Power
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Store as StoreType } from '@/types';

function parseTimeToMinutes(timeStr: string): number | null {
  if (!timeStr || typeof timeStr !== 'string') return null;
  const t = timeStr.trim().toUpperCase();

  const match12 = t.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/);
  if (match12) {
    let hours = parseInt(match12[1], 10);
    const minutes = parseInt(match12[2], 10);
    const meridian = match12[3];
    if (hours < 1 || hours > 12 || minutes < 0 || minutes > 59) return null;
    if (meridian === 'AM' && hours === 12) hours = 0;
    if (meridian === 'PM' && hours !== 12) hours += 12;
    return hours * 60 + minutes;
  }

  const match24 = t.match(/^(\d{1,2}):(\d{2})$/);
  if (match24) {
    const hours = parseInt(match24[1], 10);
    const minutes = parseInt(match24[2], 10);
    if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) return null;
    return hours * 60 + minutes;
  }

  return null;
}

export default function MerchantDashboardSettingsPage() {
  const { user, token } = useAuth();
  const [store, setStore] = useState<StoreType | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [savingStore, setSavingStore] = useState<boolean>(false);
  const [savingProfile, setSavingProfile] = useState<boolean>(false);

  // Store form state
  const [storeName, setStoreName] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [openingTime, setOpeningTime] = useState<string>('08:00 AM');
  const [closingTime, setClosingTime] = useState<string>('09:30 PM');
  const [isOpen, setIsOpen] = useState<boolean>(true);

  // Profile form state
  const [merchantName, setMerchantName] = useState<string>('');

  // Notifications
  const [storeSuccess, setStoreSuccess] = useState<string>('');
  const [storeError, setStoreError] = useState<string>('');
  const [profileSuccess, setProfileSuccess] = useState<string>('');
  const [profileError, setProfileError] = useState<string>('');

  const fetchStoreAndProfile = async () => {
    try {
      setLoading(true);
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const [storeRes, profileRes] = await Promise.all([
        fetch('/api/merchant/store', { headers }),
        fetch('/api/profile', { headers }),
      ]);

      if (storeRes.ok) {
        const storeData = await storeRes.json();
        const s: StoreType = storeData.store;
        setStore(s);
        setStoreName(s.name || '');
        setDescription(s.description || s.tagline || '');
        setAddress(s.location?.address || '');
        setPhone(s.phone ? s.phone.replace(/^\+91/, '') : '');
        setOpeningTime(s.openingTime || '08:00 AM');
        setClosingTime(s.closingTime || '09:30 PM');
        setIsOpen(s.isOpen !== undefined ? s.isOpen : true);
      }

      if (profileRes.ok) {
        const profileData = await profileRes.json();
        setMerchantName(profileData.user?.name || user?.name || '');
      }
    } catch (e) {
      console.error('Failed to load store or profile', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStoreAndProfile();
  }, [token]);

  const handleSaveStore = async (e: React.FormEvent) => {
    e.preventDefault();
    setStoreSuccess('');
    setStoreError('');

    if (!storeName.trim()) {
      setStoreError('Store name is required');
      return;
    }

    const openMin = parseTimeToMinutes(openingTime);
    const closeMin = parseTimeToMinutes(closingTime);

    if (openMin === null || closeMin === null) {
      setStoreError('Invalid time format for opening or closing hours (e.g. 08:00 AM)');
      return;
    }

    if (closeMin <= openMin) {
      setStoreError('Closing time must be later than opening time');
      return;
    }

    const cleanPhone = phone.replace(/^\+91/, '').trim();
    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      setStoreError('Please provide a valid 10-digit mobile number starting with 6-9');
      return;
    }

    try {
      setSavingStore(true);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/merchant/store', {
        method: 'PATCH',
        headers,
        body: JSON.stringify({
          name: storeName.trim(),
          description: description.trim(),
          address: address.trim(),
          phone: cleanPhone,
          openingTime: openingTime.trim(),
          closingTime: closingTime.trim(),
          isOpen,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || data.error || 'Failed to update store');
      }

      setStore(data.store);
      setStoreSuccess('Store settings updated successfully!');
      setTimeout(() => setStoreSuccess(''), 4000);
    } catch (err: any) {
      setStoreError(err.message || 'Something went wrong');
    } finally {
      setSavingStore(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileSuccess('');
    setProfileError('');

    if (!merchantName.trim()) {
      setProfileError('Name is required');
      return;
    }

    try {
      setSavingProfile(true);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/profile', {
        method: 'PATCH',
        headers,
        body: JSON.stringify({
          name: merchantName.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || data.error || 'Failed to update profile');
      }

      setProfileSuccess('Merchant profile updated successfully!');
      setTimeout(() => setProfileSuccess(''), 4000);
    } catch (err: any) {
      setProfileError(err.message || 'Something went wrong');
    } finally {
      setSavingProfile(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 animate-pulse space-y-6">
        <div className="h-8 bg-slate-200 rounded w-1/4" />
        <div className="h-48 bg-slate-200 rounded-2xl" />
        <div className="h-48 bg-slate-200 rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 pb-24 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200">
        <Link
          href="/merchant"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Orders Dashboard
        </Link>

        <button
          onClick={fetchStoreAndProfile}
          className="p-1.5 text-slate-500 hover:text-amber-700 rounded-lg hover:bg-slate-100 flex items-center gap-1 text-xs"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Reload
        </button>
      </div>

      <div className="bg-amber-950 text-white rounded-3xl p-6 shadow-xl border border-amber-900">
        <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold px-2 py-0.5 rounded-md uppercase">
          Merchant Settings
        </span>
        <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">
          Store Operations & Profile
        </h1>
        <p className="text-xs text-amber-200/80 mt-1">
          Manage your store schedule, instant open/closed status, counter address, and merchant profile.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8">
        {/* Store Settings Section */}
        <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Store className="w-5 h-5 text-amber-700" />
              Store Settings
            </h2>

            <button
              type="button"
              onClick={() => setIsOpen(!isOpen)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors ${
                isOpen
                  ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                  : 'bg-red-100 text-red-800 hover:bg-red-200'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              {isOpen ? 'Store is OPEN' : 'Store is CLOSED'}
            </button>
          </div>

          {storeSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              {storeSuccess}
            </div>
          )}

          {storeError && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              {storeError}
            </div>
          )}

          <form onSubmit={handleSaveStore} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Store Name *
                </label>
                <input
                  type="text"
                  required
                  maxLength={100}
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="e.g. Gupta Kirana & General Store"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Contact Mobile Number *
                </label>
                <div className="flex">
                  <span className="inline-flex items-center px-3 rounded-l-xl border border-r-0 border-slate-200 bg-slate-100 text-slate-600 text-xs font-mono">
                    +91
                  </span>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-r-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                    placeholder="9876543210"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Store Description / Tagline
              </label>
              <input
                type="text"
                maxLength={500}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="e.g. Daily grocery essentials, fresh grains & spices at wholesale rates"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Counter Pickup Address
              </label>
              <input
                type="text"
                maxLength={200}
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="Shop No. 4, Main Market, Near Clock Tower"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-700" />
                  Daily Opening Time
                </label>
                <input
                  type="text"
                  required
                  value={openingTime}
                  onChange={(e) => setOpeningTime(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  placeholder="08:00 AM"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">Format: 08:00 AM or 08:00</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-700" />
                  Daily Closing Time
                </label>
                <input
                  type="text"
                  required
                  value={closingTime}
                  onChange={(e) => setClosingTime(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                  placeholder="09:30 PM"
                />
                <span className="text-[10px] text-slate-400 mt-0.5 block">Format: 09:30 PM or 21:30</span>
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                type="submit"
                disabled={savingStore}
                className="bg-amber-700 hover:bg-amber-800 text-white text-xs font-bold px-5 py-2.5 rounded-xl shadow transition-colors flex items-center gap-2 disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {savingStore ? 'Saving Store...' : 'Save Store Settings'}
              </button>
            </div>
          </form>
        </section>

        {/* My Profile Section */}
        <section className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
          <div className="pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <User className="w-5 h-5 text-amber-700" />
              My Merchant Profile
            </h2>
          </div>

          {profileSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              {profileSuccess}
            </div>
          )}

          {profileError && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              {profileError}
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Your Full Name *
              </label>
              <input
                type="text"
                required
                maxLength={100}
                value={merchantName}
                onChange={(e) => setMerchantName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="e.g. Ram Prasad Gupta"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={savingProfile}
                className="bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold px-5 py-2.5 rounded-xl shadow transition-colors flex items-center gap-2 disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                {savingProfile ? 'Saving Profile...' : 'Save Profile'}
              </button>
            </div>
          </form>
        </section>
      </div>
    </div>
  );
}
