'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  Plus,
  Check,
  Edit2,
  Trash2,
  Package,
  Sparkles,
  RefreshCw,
  Search
} from 'lucide-react';
import { StoreProduct } from '@/types';
import { useAuth } from '@/context/AuthContext';

export default function MerchantInventoryPage() {
  const { user, token } = useAuth();
  const storeId = user?.storeId || 'store_shree_ram';

  const [products, setProducts] = useState<StoreProduct[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);

  // New product form
  const [newName, setNewName] = useState<string>('');
  const [newHindiName, setNewHindiName] = useState<string>('');
  const [newCategory, setNewCategory] = useState<string>('Atta & Flour');
  const [newPrice, setNewPrice] = useState<number>(100);
  const [newMrp, setNewMrp] = useState<number>(110);
  const [newUnit, setNewUnit] = useState<string>('1 kg');

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/stores/${storeId}/products`);
      if (res.ok) {
        const data = await res.json();
        setProducts(data.products || []);
      }
    } catch (err) {
      console.error('Failed to fetch merchant inventory', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [storeId]);

  const toggleStock = async (product: StoreProduct) => {
    try {
      const updatedStock = !product.inStock;
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/products/${product.id}`, {
        method: 'PUT',
        headers,
        body: JSON.stringify({ inStock: updatedStock }),
      });

      if (res.ok) {
        setProducts(prev =>
          prev.map(p => (p.id === product.id ? { ...p, inStock: updatedStock } : p))
        );
      }
    } catch (e) {
      console.error('Stock toggle failed', e);
    }
  };

  const savePrice = async (productId: string) => {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/products/${productId}`, {
        method: 'PUT',
        headers,
        body: JSON.stringify({ price: Number(editPrice) }),
      });

      if (res.ok) {
        setProducts(prev =>
          prev.map(p => (p.id === productId ? { ...p, price: Number(editPrice) } : p))
        );
        setEditingId(null);
      }
    } catch (e) {
      console.error('Price update failed', e);
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/stores/${storeId}/products`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          name: newName,
          hindiName: newHindiName,
          category: newCategory,
          price: Number(newPrice),
          mrp: Number(newMrp),
          unit: newUnit,
          inStock: true,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setProducts(prev => [...prev, data.product]);
        setIsAddingNew(false);
        setNewName('');
        setNewHindiName('');
      }
    } catch (e) {
      console.error('Create product error', e);
    }
  };

  const filteredProducts = products.filter(
    p =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.hindiName && p.hindiName.includes(searchQuery)) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 pb-24 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <Link
            href="/merchant"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-900 mb-1"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Orders Dashboard
          </Link>
          <h1 className="text-2xl font-extrabold text-slate-900">
            Store Inventory & Daily Rates
          </h1>
          <p className="text-xs text-slate-500">
            Update in-stock availability and daily grocery prices instantly for customers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsAddingNew(!isAddingNew)}
            className="bg-kirana-600 hover:bg-kirana-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Add New Item
          </button>
          <button
            onClick={fetchProducts}
            className="p-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Add New Product Modal / Form */}
      {isAddingNew && (
        <form onSubmit={handleCreateProduct} className="bg-white rounded-2xl border border-kirana-300 p-5 shadow-md space-y-4 animate-fade-in">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Package className="w-4 h-4 text-kirana-600" />
            Add New Item to Store Catalog
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Product Name (English)</label>
              <input
                type="text"
                required
                value={newName}
                onChange={e => setNewName(e.target.value)}
                placeholder="e.g. Fortune Sunflower Oil"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Hindi Name (Optional)</label>
              <input
                type="text"
                value={newHindiName}
                onChange={e => setNewHindiName(e.target.value)}
                placeholder="उदा. सूरजमुखी का तेल"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={newCategory}
                onChange={e => setNewCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs"
              >
                <option value="Atta & Flour">Atta & Flour</option>
                <option value="Rice & Pulses">Rice & Pulses</option>
                <option value="Cooking Oils">Cooking Oils</option>
                <option value="Spices & Masalas">Spices & Masalas</option>
                <option value="Dairy & Bakery">Dairy & Bakery</option>
                <option value="Snacks">Snacks</option>
                <option value="Beverages">Beverages</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Unit / Pack</label>
              <input
                type="text"
                required
                value={newUnit}
                onChange={e => setNewUnit(e.target.value)}
                placeholder="1 kg, 500g, 1L"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Selling Price (₹)</label>
              <input
                type="number"
                required
                value={newPrice}
                onChange={e => setNewPrice(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">MRP (₹)</label>
              <input
                type="number"
                required
                value={newMrp}
                onChange={e => setNewMrp(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="px-3.5 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-kirana-600 hover:bg-kirana-700 text-white font-bold text-xs px-4 py-1.5 rounded-xl shadow"
            >
              Save to Catalog
            </button>
          </div>
        </form>
      )}

      {/* Search Input */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
        <input
          type="text"
          placeholder="Filter inventory by name or category..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
        />
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[10px]">
            <tr>
              <th className="p-3.5">Product Name</th>
              <th className="p-3.5">Category & Unit</th>
              <th className="p-3.5">Price (₹)</th>
              <th className="p-3.5">Availability</th>
              <th className="p-3.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredProducts.map(product => (
              <tr key={product.id} className="hover:bg-slate-50/60 transition-colors">
                <td className="p-3.5">
                  <div className="font-bold text-slate-900">{product.name}</div>
                  {product.hindiName && (
                    <div className="text-[11px] text-kirana-700 font-medium">{product.hindiName}</div>
                  )}
                </td>

                <td className="p-3.5">
                  <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] font-semibold">
                    {product.category}
                  </span>
                  <span className="text-slate-400 ml-1.5">[{product.unit}]</span>
                </td>

                <td className="p-3.5">
                  {editingId === product.id ? (
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        value={editPrice}
                        onChange={e => setEditPrice(Number(e.target.value))}
                        className="w-20 bg-slate-50 border border-slate-300 rounded px-1.5 py-0.5 text-xs font-bold"
                        autoFocus
                      />
                      <button
                        onClick={() => savePrice(product.id)}
                        className="p-1 bg-kirana-600 text-white rounded hover:bg-kirana-700"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">₹{product.price}</span>
                      {product.mrp > product.price && (
                        <span className="text-slate-400 line-through text-[11px]">₹{product.mrp}</span>
                      )}
                      <button
                        onClick={() => {
                          setEditingId(product.id);
                          setEditPrice(product.price);
                        }}
                        className="p-1 text-slate-400 hover:text-slate-700"
                        title="Edit price"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </td>

                <td className="p-3.5">
                  <button
                    onClick={() => toggleStock(product)}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all ${
                      product.inStock
                        ? 'bg-kirana-100 text-kirana-800 border border-kirana-300 hover:bg-red-50 hover:text-red-700'
                        : 'bg-red-100 text-red-800 border border-red-300 hover:bg-kirana-50 hover:text-kirana-700'
                    }`}
                  >
                    {product.inStock ? '● In Stock' : '✕ Out of Stock'}
                  </button>
                </td>

                <td className="p-3.5 text-right">
                  <button
                    onClick={() => toggleStock(product)}
                    className="text-xs text-slate-500 hover:text-slate-900 font-medium"
                  >
                    Toggle Stock
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
