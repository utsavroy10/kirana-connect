import type { Metadata } from 'next';
import './globals.css';
import { AuthProvider } from '@/context/AuthContext';
import { CartProvider } from '@/context/CartContext';
import { Navbar } from '@/components/Navbar';
import { RoleSwitcher } from '@/components/RoleSwitcher';
import { MobileBottomNav } from '@/components/MobileBottomNav';
import { SingleStoreConflictModal } from '@/components/SingleStoreConflictModal';

export const metadata: Metadata = {
  title: 'Kirana Connect | Pickup-First Hyperlocal Grocery Platform',
  description: 'Order groceries online from your trusted neighborhood kirana store. Pick up packed and ready. Zero delivery fees.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 flex flex-col antialiased selection:bg-kirana-500 selection:text-white">
        <AuthProvider>
          <CartProvider>
            {/* POC Persona Switcher bar */}
            <RoleSwitcher />

            {/* Main Header */}
            <Navbar />

            {/* Single store conflict popup */}
            <SingleStoreConflictModal />

            {/* Main Content Area */}
            <main className="flex-1">
              {children}
            </main>

            {/* Mobile Bottom Navigation Bar */}
            <MobileBottomNav />

            {/* Minimal footer */}
            <footer className="border-t border-slate-200 bg-white py-6 text-center text-xs text-slate-500 hidden sm:block">
              <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
                <p>© {new Date().getFullYear()} Kirana Connect POC • Hyperlocal In-Store Pickup Model</p>
                <p className="text-slate-400">MongoDB Atlas • Firebase Phone Auth • Next.js App Router</p>
              </div>
            </footer>
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
