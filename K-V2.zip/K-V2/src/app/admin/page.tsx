'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ShieldCheck,
  Store,
  Users,
  ShoppingBag,
  TrendingUp,
  Database,
  CheckCircle2,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { Order, Store as StoreType } from '@/types';
import { useAuth } from '@/context/AuthContext';

export default function AdminDashboardPage() {
  const { user, token } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [merchants, setMerchants] = useState<StoreType[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [seeding, setSeeding] = useState<boolean>(false);
  const [seedSuccess, setSeedSuccess] = useState<string>('');
  const [seedError, setSeedError] = useState<string>('');

  const fetchAdminData = async () => {
    try {
      setLoading(true);
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const [orderRes, merchRes] = await Promise.all([
        fetch('/api/orders', { headers }),
        fetch('/api/admin/merchants', { headers }),
      ]);

      if (orderRes.ok) {
        const orderData = await orderRes.json();
        setOrders(orderData.orders || []);
      }
      if (merchRes.ok) {
        const merchData = await merchRes.json();
        setMerchants(merchData.merchants || []);
      }
    } catch (err) {
      console.error('Failed to load admin overview', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, [token]);

  const handleSeedDatabase = async () => {
    try {
      setSeeding(true);
      setSeedSuccess('');
      setSeedError('');
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/seed', { method: 'POST', headers });
      const data = await res.json();
      if (res.ok) {
        setSeedSuccess(data.message || 'Sample database data seeded successfully!');
        await fetchAdminData();
      } else {
        setSeedError(data.error || 'Failed to seed database.');
      }
    } catch (err: any) {
      console.error('Seed error', err);
      setSeedError(err.message || 'Seed failed');
    } finally {
      setSeeding(false);
    }
  };

  const totalGMV = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const totalCommission = orders.reduce((sum, o) => sum + (o.commissionAmount || 0), 0);
  const completedOrders = orders.filter(o => o.status === 'completed');

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 pb-24 space-y-6">
      {/* Admin Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 shadow-xl border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-bold px-2 py-0.5 rounded-md uppercase">
              Platform Admin Console
            </span>
            <span className="text-xs text-slate-400">Kirana Connect Operations</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold mt-1">
            Marketplace Overview & Pilot Governance
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Approve partner merchants, configure commission rates, monitor GMV & order completion.
          </p>
        </div>

        <div className="flex items-center gap-3 self-stretch md:self-auto justify-between md:justify-end">
          <Link
            href="/admin/merchants"
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow transition-colors"
          >
            Manage Merchants & Approvals
          </Link>
          <button
            onClick={fetchAdminData}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700"
            title="Refresh Admin Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {seedSuccess && (
        <div className="p-3 bg-kirana-50 border border-kirana-200 text-kirana-800 rounded-xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-kirana-600" />
          {seedSuccess}
        </div>
      )}

      {seedError && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-600" />
          {seedError}
        </div>
      )}

      {/* Metrics Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold">Total Orders</span>
            <ShoppingBag className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-extrabold text-slate-900">{orders.length}</p>
          <span className="text-[11px] text-slate-400 font-medium">
            {completedOrders.length} completed pickups
          </span>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold">Active Stores</span>
            <Store className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-extrabold text-blue-600">{merchants.length}</p>
          <span className="text-[11px] text-slate-400 font-medium">
            {merchants.filter(m => m.isVerified).length} verified partners
          </span>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold">Total Platform GMV</span>
            <TrendingUp className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-extrabold text-slate-900">₹{totalGMV}</p>
          <span className="text-[11px] text-slate-400 font-medium">Gross merchandise value</span>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-xs font-bold">Est. Commission</span>
            <ShieldCheck className="w-4 h-4 text-kirana-600" />
          </div>
          <p className="text-2xl font-extrabold text-kirana-700">₹{totalCommission}</p>
          <span className="text-[11px] text-slate-400 font-medium">Avg ~3.5% model</span>
        </div>
      </div>

      {/* Database Quick Seeder Panel */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <Database className="w-4 h-4 text-blue-600" />
            MongoDB Atlas Sample Data Seeder
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Reset or populate realistic Indian kirana stores (Indore, Varanasi, Jaipur) and grocery catalogs.
          </p>
        </div>

        <button
          onClick={handleSeedDatabase}
          disabled={seeding}
          className="bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs px-4 py-2 rounded-xl transition-colors shrink-0 disabled:opacity-50"
        >
          {seeding ? 'Seeding...' : 'Seed Sample Kiranas & Products'}
        </button>
      </div>

      {/* Platform-wide Orders Stream */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-sm text-slate-900">
            Marketplace Orders Live Feed
          </h3>
          <span className="text-xs text-slate-500">Showing all store transactions</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px]">
              <tr>
                <th className="p-3">Order ID</th>
                <th className="p-3">Store Name</th>
                <th className="p-3">Customer</th>
                <th className="p-3">Slot</th>
                <th className="p-3">Amount (₹)</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {orders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    No orders placed across the marketplace yet.
                  </td>
                </tr>
              ) : (
                orders.map((o) => (
                  <tr key={o.orderNumber} className="hover:bg-slate-50">
                    <td className="p-3 font-mono font-bold text-slate-800">
                      {o.orderNumber}
                    </td>
                    <td className="p-3 font-semibold text-slate-900">
                      {o.storeName}
                    </td>
                    <td className="p-3 text-slate-600">
                      {o.customerName} ({o.customerPhone})
                    </td>
                    <td className="p-3 text-slate-600">
                      {o.pickupSlot.slotLabel}
                    </td>
                    <td className="p-3 font-bold text-slate-900">
                      ₹{o.totalAmount}
                    </td>
                    <td className="p-3">
                      <span className="capitalize px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-800">
                        {o.status.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="p-3 text-right text-slate-400 font-mono">
                      {new Date(o.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
