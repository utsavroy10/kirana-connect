'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  ArrowLeft,
  CheckCircle2,
  XCircle,
  Store,
  ShieldCheck,
  Edit,
  RefreshCw,
  MapPin,
  Percent
} from 'lucide-react';
import { Store as StoreType } from '@/types';
import { useAuth } from '@/context/AuthContext';

export default function AdminMerchantsPage() {
  const { token } = useAuth();
  const [merchants, setMerchants] = useState<StoreType[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const fetchMerchants = async () => {
    try {
      setLoading(true);
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/admin/merchants', { headers });
      if (res.ok) {
        const data = await res.json();
        setMerchants(data.merchants || []);
      }
    } catch (err) {
      console.error('Failed to fetch merchants', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMerchants();
  }, [token]);

  const updateMerchantVerification = async (storeId: string, isVerified: boolean) => {
    try {
      setUpdatingId(storeId);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/admin/merchants', {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ storeId, isVerified }),
      });

      if (res.ok) {
        setMerchants(prev =>
          prev.map(m => (m.id === storeId ? { ...m, isVerified } : m))
        );
      }
    } catch (e) {
      console.error('Verification update failed', e);
    } finally {
      setUpdatingId(null);
    }
  };

  const updateCommissionRate = async (storeId: string, commissionRate: number) => {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/admin/merchants', {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ storeId, commissionRate }),
      });

      if (res.ok) {
        setMerchants(prev =>
          prev.map(m => (m.id === storeId ? { ...m, commissionRate } : m))
        );
      }
    } catch (e) {
      console.error('Commission update failed', e);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 pb-24 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <Link
            href="/admin"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-900 mb-1"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Marketplace Overview
          </Link>
          <h1 className="text-2xl font-extrabold text-slate-900">
            Merchant Partners & Onboarding Approvals
          </h1>
          <p className="text-xs text-slate-500">
            Verify neighborhood kirana stores, verify business credentials, and configure pilot commission.
          </p>
        </div>

        <button
          onClick={fetchMerchants}
          className="p-2 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 self-start sm:self-auto"
          title="Refresh"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Merchants Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px]">
            <tr>
              <th className="p-3.5">Store / Merchant</th>
              <th className="p-3.5">Location</th>
              <th className="p-3.5">Commission Rate</th>
              <th className="p-3.5">Verification Status</th>
              <th className="p-3.5 text-right">Approval Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {merchants.map((merchant) => (
              <tr key={merchant.id} className="hover:bg-slate-50/60 transition-colors">
                <td className="p-3.5">
                  <div className="font-bold text-slate-900 text-sm">{merchant.name}</div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Owner: {merchant.ownerName} • {merchant.phone}
                  </div>
                </td>

                <td className="p-3.5">
                  <div className="flex items-center gap-1 text-slate-700">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{merchant.location.area}, {merchant.location.city}</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                    PIN: {merchant.location.pincode}
                  </div>
                </td>

                <td className="p-3.5">
                  <div className="flex items-center gap-1">
                    <span className="font-extrabold text-slate-800 text-xs">
                      {merchant.commissionRate || 3.5}%
                    </span>
                    <button
                      onClick={() => {
                        const newRate = prompt('Enter new commission % for this store:', String(merchant.commissionRate || 3.5));
                        if (newRate && !isNaN(Number(newRate))) {
                          updateCommissionRate(merchant.id, Number(newRate));
                        }
                      }}
                      className="p-1 text-slate-400 hover:text-blue-600"
                      title="Adjust commission"
                    >
                      <Edit className="w-3 h-3" />
                    </button>
                  </div>
                </td>

                <td className="p-3.5">
                  {merchant.isVerified ? (
                    <span className="inline-flex items-center gap-1 bg-kirana-100 text-kirana-800 font-bold text-[11px] px-2.5 py-0.5 rounded-full">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Verified Partner
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-800 font-bold text-[11px] px-2.5 py-0.5 rounded-full">
                      Pending Verification
                    </span>
                  )}
                </td>

                <td className="p-3.5 text-right">
                  {merchant.isVerified ? (
                    <button
                      onClick={() => updateMerchantVerification(merchant.id, false)}
                      disabled={updatingId === merchant.id}
                      className="text-xs text-red-600 hover:text-red-700 font-semibold px-2 py-1 rounded hover:bg-red-50"
                    >
                      Revoke Approval
                    </button>
                  ) : (
                    <button
                      onClick={() => updateMerchantVerification(merchant.id, true)}
                      disabled={updatingId === merchant.id}
                      className="bg-kirana-600 hover:bg-kirana-700 text-white font-bold text-xs px-3 py-1.5 rounded-xl shadow transition-colors"
                    >
                      Approve Merchant
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
