'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ShoppingBag, Clock, Store, ArrowRight, RefreshCw, CheckCircle2, AlertCircle } from 'lucide-react';
import { Order } from '@/types';
import { useAuth } from '@/context/AuthContext';

export default function OrdersListPage() {
  const { user, token } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/orders', { headers });
      if (res.ok) {
        const data = await res.json();
        setOrders(data.orders || []);
      }
    } catch (err) {
      console.error('Failed to fetch orders', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [user, token]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'placed':
        return <span className="bg-blue-50 text-blue-700 border border-blue-200 text-[11px] font-bold px-2.5 py-0.5 rounded-full">Placed</span>;
      case 'accepted':
        return <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px] font-bold px-2.5 py-0.5 rounded-full">Accepted</span>;
      case 'preparing':
        return <span className="bg-amber-50 text-amber-700 border border-amber-200 text-[11px] font-bold px-2.5 py-0.5 rounded-full animate-pulse">Packing Items</span>;
      case 'ready_for_pickup':
        return <span className="bg-kirana-600 text-white font-bold text-[11px] px-2.5 py-0.5 rounded-full shadow-sm animate-bounce">Ready for Pickup!</span>;
      case 'completed':
        return <span className="bg-slate-100 text-slate-700 text-[11px] font-bold px-2.5 py-0.5 rounded-full">Completed</span>;
      case 'cancelled':
        return <span className="bg-red-50 text-red-700 border border-red-200 text-[11px] font-bold px-2.5 py-0.5 rounded-full">Cancelled</span>;
      default:
        return <span className="bg-slate-100 text-slate-600 text-[11px] px-2.5 py-0.5 rounded-full">{status}</span>;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 pb-24">
      <div className="flex items-center justify-between pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">My Pickup Orders</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Track your live orders and past store pickups
          </p>
        </div>

        <button
          onClick={fetchOrders}
          className="text-xs text-slate-600 hover:text-kirana-600 flex items-center gap-1.5 p-2 rounded-lg hover:bg-slate-100 transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {loading ? (
        <div className="mt-6 space-y-4">
          {[1, 2].map((n) => (
            <div key={n} className="bg-white h-36 rounded-2xl border border-slate-200 animate-pulse" />
          ))}
        </div>
      ) : orders.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center mt-8">
          <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-base">No orders yet</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
            Place your first order with a nearby kirana store to skip queues!
          </p>
          <Link
            href="/"
            className="mt-4 inline-flex items-center gap-1 text-xs font-bold text-kirana-600 hover:underline"
          >
            Explore Kirana Stores
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      ) : (
        <div className="mt-6 space-y-4">
          {orders.map((order) => (
            <div
              key={order.orderNumber}
              className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                    {order.orderNumber}
                  </span>
                  {getStatusBadge(order.status)}
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-900">{order.storeName}</h3>
                  <p className="text-xs text-slate-500">{order.storeAddress}</p>
                </div>

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600 pt-1">
                  <span className="flex items-center gap-1 font-medium">
                    <Clock className="w-3.5 h-3.5 text-kirana-600" />
                    Slot: {order.pickupSlot.slotLabel}
                  </span>
                  <span>
                    {order.items.length} {order.items.length === 1 ? 'item' : 'items'} • <strong>₹{order.totalAmount}</strong> (Pay at store)
                  </span>
                </div>
              </div>

              <div className="sm:text-right flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 pt-3 sm:pt-0 border-slate-100">
                <span className="text-[11px] text-slate-400 font-mono">
                  {new Date(order.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </span>
                <Link
                  href={`/orders/${order.orderNumber}`}
                  className="mt-2 inline-flex items-center gap-1 bg-kirana-50 hover:bg-kirana-600 text-kirana-700 hover:text-white px-3.5 py-1.5 rounded-xl font-bold text-xs transition-colors"
                >
                  Track Pickup
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
