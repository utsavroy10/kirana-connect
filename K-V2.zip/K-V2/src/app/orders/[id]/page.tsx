'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import {
  ArrowLeft,
  Clock,
  MapPin,
  Phone,
  Banknote,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  ShoppingBag,
  Store
} from 'lucide-react';
import { Order } from '@/types';
import { OrderTimeline } from '@/components/OrderTimeline';
import { useAuth } from '@/context/AuthContext';

export default function OrderDetailsPage() {
  const params = useParams();
  const orderId = params.id as string;
  const { user, token } = useAuth();

  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [cancelling, setCancelling] = useState<boolean>(false);
  const [lastPolledAt, setLastPolledAt] = useState<Date>(new Date());

  const fetchOrder = async (isBackground = false) => {
    try {
      if (!isBackground) setLoading(true);
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/orders/${orderId}`, { headers });
      if (res.ok) {
        const data = await res.json();
        setOrder(data.order);
        setLastPolledAt(new Date());
      }
    } catch (err) {
      console.error('Failed to fetch order', err);
    } finally {
      if (!isBackground) setLoading(false);
    }
  };

  // Initial fetch and 4-second polling loop for real-time status updates
  useEffect(() => {
    if (orderId) {
      fetchOrder();
      const interval = setInterval(() => {
        fetchOrder(true);
      }, 4000);
      return () => clearInterval(interval);
    }
  }, [orderId, token]);

  const handleCancelOrder = async () => {
    if (!confirm('Are you sure you want to cancel this pickup order?')) return;
    try {
      setCancelling(true);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({
          status: 'cancelled',
          note: 'Cancelled by customer before merchant acceptance',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setOrder(data.order);
      }
    } catch (err) {
      console.error('Cancel order error', err);
    } finally {
      setCancelling(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-12 animate-pulse space-y-4">
        <div className="h-8 bg-slate-200 rounded w-1/4" />
        <div className="h-32 bg-slate-200 rounded-2xl" />
        <div className="h-64 bg-slate-200 rounded-2xl" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-2xl border border-slate-200 text-center">
        <h2 className="text-lg font-bold text-slate-800">Order not found</h2>
        <p className="text-xs text-slate-500 mt-1">Check order number or return to your orders.</p>
        <Link href="/orders" className="inline-block mt-4 text-xs font-semibold text-kirana-600 hover:underline">
          View All Orders
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 pb-24 space-y-6">
      {/* Back & Title */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200">
        <Link
          href="/orders"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Orders
        </Link>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-400">
            Updated: {lastPolledAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </span>
          <button
            onClick={() => fetchOrder(false)}
            className="p-1.5 text-slate-500 hover:text-kirana-600 rounded-lg hover:bg-slate-100"
            title="Refresh status now"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Prominent Status Banner */}
      <div className="bg-slate-900 text-white p-5 rounded-3xl shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono tracking-wider uppercase text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
            Order #{order.orderNumber}
          </span>
          <h1 className="text-xl sm:text-2xl font-extrabold mt-1">
            {order.status === 'ready_for_pickup'
              ? '🎉 Ready for In-Store Pickup!'
              : order.status === 'preparing'
              ? '🛍️ Shopkeeper is Packing Your Items'
              : order.status === 'accepted'
              ? '✅ Store Accepted Your Order'
              : order.status === 'completed'
              ? '✨ Picked Up & Paid'
              : order.status === 'cancelled'
              ? '❌ Order Cancelled'
              : '⏳ Order Sent to Store'}
          </h1>
          <p className="text-xs text-slate-300 mt-0.5 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-kirana-400" />
            Scheduled Slot: <strong>{order.pickupSlot.slotLabel}</strong>
          </p>
        </div>

        {order.status === 'placed' && (
          <button
            onClick={handleCancelOrder}
            disabled={cancelling}
            className="bg-red-500/20 hover:bg-red-600 text-red-200 hover:text-white border border-red-500/40 text-xs font-bold px-3 py-1.5 rounded-xl transition-colors"
          >
            {cancelling ? 'Cancelling...' : 'Cancel Order'}
          </button>
        )}
      </div>

      {/* Interactive Status Timeline */}
      <OrderTimeline currentStatus={order.status} history={order.statusHistory} />

      {/* Store Location & Pickup Instructions */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
        <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <Store className="w-4 h-4 text-kirana-600" />
          Pickup Store Details
        </h2>

        <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200/60 flex flex-col sm:flex-row justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">{order.storeName}</h3>
            <p className="text-xs text-slate-600 mt-0.5 flex items-start gap-1">
              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
              <span>{order.storeAddress}</span>
            </p>
          </div>

          <a
            href={`tel:${order.storePhone}`}
            className="self-start sm:self-center inline-flex items-center gap-1.5 bg-kirana-600 hover:bg-kirana-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition-colors"
          >
            <Phone className="w-3.5 h-3.5" />
            Call Store: {order.storePhone}
          </a>
        </div>

        {/* Payment notice */}
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 flex items-start gap-2.5">
          <Banknote className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs">
            <span className="font-bold text-amber-900">
              Payment Status: {order.payment.status === 'COLLECTED' ? 'Collected at Store' : 'Pending at Pickup'}
            </span>
            <p className="text-amber-800 mt-0.5">
              Please pay <strong>₹{order.totalAmount}</strong> in cash or scan the store UPI QR code when collecting your packed items.
            </p>
          </div>
        </div>
      </div>

      {/* Items Summary */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
        <h2 className="text-sm font-bold text-slate-800 mb-3">
          Ordered Items ({order.items.length})
        </h2>

        <div className="divide-y divide-slate-100">
          {order.items.map((item) => (
            <div key={item.productId} className="py-2.5 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-slate-900">{item.name}</span>
                {item.hindiName && <span className="text-kirana-700 ml-1">({item.hindiName})</span>}
                <span className="text-slate-400 ml-1">[{item.unit}]</span>
                <span className="text-slate-500 block">Qty: {item.quantity} × ₹{item.price}</span>
              </div>
              <span className="font-extrabold text-slate-800">₹{item.subtotal}</span>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-3 border-t border-slate-200 space-y-1.5 text-xs">
          <div className="flex justify-between text-slate-600">
            <span>Item Total</span>
            <span className="font-semibold text-slate-800">₹{order.itemTotal}</span>
          </div>
          <div className="flex justify-between text-slate-600">
            <span>Delivery & Packaging</span>
            <span className="font-bold text-kirana-600">FREE</span>
          </div>
          <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-2 border-t border-slate-100">
            <span>Total Payable Amount</span>
            <span className="text-base text-kirana-700">₹{order.totalAmount}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
