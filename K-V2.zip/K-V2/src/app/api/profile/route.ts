import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { connectToDatabase } from '@/lib/mongodb';
import { User } from '@/types';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    try {
      const { db } = await connectToDatabase();
      const user = await db.collection<User>('users').findOne({ uid: authUser.uid });
      return NextResponse.json({ user: user || authUser });
    } catch {
      return NextResponse.json({ user: authUser });
    }
  } catch (error: any) {
    console.error('[api/profile GET] Error:', error);
    return NextResponse.json({ error: 'INTERNAL_ERROR', message: 'Failed to fetch profile' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;

    let body: any;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: 'INVALID_JSON', message: 'Invalid JSON body' }, { status: 400 });
    }

    const { name } = body;

    if (name === undefined) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'At least one field to update is required' },
        { status: 400 }
      );
    }

    if (typeof name !== 'string' || !name.trim() || name.trim().length > 100) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Name must be a non-empty string under 100 characters' },
        { status: 400 }
      );
    }

    const now = new Date().toISOString();
    const updatedUser: User = {
      ...authUser,
      name: name.trim(),
      updatedAt: now,
    };

    try {
      const { db } = await connectToDatabase();
      const result = await db.collection<User>('users').findOneAndUpdate(
        { uid: authUser.uid },
        {
          $set: {
            name: name.trim(),
            updatedAt: now,
          },
        },
        { returnDocument: 'after' }
      );

      return NextResponse.json({ user: result || updatedUser });
    } catch {
      return NextResponse.json({ user: updatedUser });
    }
  } catch (error: any) {
    console.error('[api/profile PATCH] Error:', error);
    return NextResponse.json({ error: 'INTERNAL_ERROR', message: 'Failed to update profile' }, { status: 500 });
  }
}
