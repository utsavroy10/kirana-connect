import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetUser, dbUpsertUserName } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody } from '@/lib/validation/parse';
import { profilePatchSchema } from '@/lib/validation/user';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const user = await dbGetUser(authUser.uid);
    return NextResponse.json({ user: user || authUser });
  } catch (error: any) {
    return handleApiError(error, 'api/profile GET', 'Failed to fetch profile');
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;

    // Unknown keys (phone, role, ...) are stripped: only the name is writable here.
    const parsed = await parseBody(req, profilePatchSchema);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }

    // The phone is read-only and is only used to seed a missing user document.
    const user = await dbUpsertUserName(authUser.uid, parsed.data.name, authUser.phone || '');
    return NextResponse.json({ user });
  } catch (error: any) {
    return handleApiError(error, 'api/profile PATCH', 'Failed to update profile');
  }
}
