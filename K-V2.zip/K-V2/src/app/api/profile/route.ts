import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetUser, dbUpsertUserName } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const user = await dbGetUser(authUser.uid);
    return NextResponse.json({ user: user || authUser });
  } catch (error: any) {
    return handleApiError(error, 'api/profile GET', 'Failed to fetch profile');
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;

    let body: any;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: 'INVALID_JSON', message: 'Invalid JSON body' }, { status: 400 });
    }

    const { name } = body || {};

    if (name === undefined) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'At least one field to update is required' },
        { status: 400 }
      );
    }

    if (typeof name !== 'string' || !name.trim() || name.trim().length > 100) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Name must be a non-empty string under 100 characters' },
        { status: 400 }
      );
    }

    // Only the name is writable here; the phone is read-only and is only used
    // to seed a missing user document.
    const user = await dbUpsertUserName(authUser.uid, name.trim(), authUser.phone || '');
    return NextResponse.json({ user });
  } catch (error: any) {
    return handleApiError(error, 'api/profile PATCH', 'Failed to update profile');
  }
}
