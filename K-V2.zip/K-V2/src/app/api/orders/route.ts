import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetOrders, dbSaveOrder, dbGetStoreById } from '@/lib/db-adapter';
import { Order, OrderStatus } from '@/types';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const { searchParams } = new URL(req.url);
    const storeIdParam = searchParams.get('storeId');

    let filter: { userId?: string; storeId?: string } = {};

    if (authUser.role === 'customer') {
      filter.userId = authUser.uid;
    } else if (authUser.role === 'merchant') {
      if (!authUser.storeId) {
        return NextResponse.json({ orders: [] });
      }
      filter.storeId = authUser.storeId;
    } else if (authUser.role === 'admin') {
      if (storeIdParam) filter.storeId = storeIdParam;
    }

    const orders = await dbGetOrders(filter);
    return NextResponse.json({ orders });
  } catch (error: any) {
    console.error('[api/orders GET] Error:', error);
    return NextResponse.json({ error: 'Failed to fetch orders' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const body = await req.json();

    const {
      storeId,
      items,
      itemTotal,
      pickupSlot,
      customerName,
      customerPhone,
      customerNotes,
    } = body;

    if (!storeId || !items || items.length === 0 || !pickupSlot) {
      return NextResponse.json({ error: 'Missing required order fields' }, { status: 400 });
    }

    const store = await dbGetStoreById(storeId);
    if (!store) {
      return NextResponse.json({ error: 'Store not found' }, { status: 404 });
    }

    const orderSeq = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `KC-${new Date().getFullYear().toString().slice(-2)}${(new Date().getMonth() + 1).toString().padStart(2, '0')}-${orderSeq}`;

    const commissionRate = store.commissionRate || 3.5;
    const commissionAmount = Math.round((itemTotal * commissionRate) / 100);

    const now = new Date().toISOString();
    const newOrder: Order = {
      orderNumber,
      userId: authUser.uid,
      customerName: customerName || 'Valued Customer',
      customerPhone: authUser.phone || customerPhone || '',
      storeId: store.id,
      storeName: store.name,
      storePhone: store.phone,
      storeAddress: `${store.location.address}, ${store.location.area}, ${store.location.city}`,
      items: items.map((it: any) => ({
        productId: it.productId,
        name: it.name,
        hindiName: it.hindiName,
        price: it.price,
        unit: it.unit,
        quantity: it.quantity,
        subtotal: it.price * it.quantity,
      })),
      itemTotal,
      platformFee: 0,
      totalAmount: itemTotal,
      commissionAmount,
      pickupSlot: {
        slotId: pickupSlot.id || pickupSlot.slotId,
        slotLabel: pickupSlot.label || pickupSlot.slotLabel,
      },
      payment: {
        method: 'PAY_AT_STORE',
        status: 'PENDING_AT_PICKUP',
      },
      status: 'placed',
      statusHistory: [
        {
          status: 'placed',
          timestamp: now,
          note: 'Order placed by customer. Awaiting merchant confirmation.',
        },
      ],
      customerNotes,
      createdAt: now,
      updatedAt: now,
    };

    const saved = await dbSaveOrder(newOrder);
    return NextResponse.json({ order: saved }, { status: 201 });
  } catch (error: any) {
    console.error('[api/orders POST] Error:', error);
    return NextResponse.json({ error: 'Order creation failed' }, { status: 500 });
  }
}
