import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetOrders, dbCreateOrder, dbGetStoreById, dbGetProductById } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { generatePickupSlots } from '@/lib/mock-data';
import { parseBody } from '@/lib/validation/parse';
import { createOrderSchema } from '@/lib/validation/order';
import { Order, OrderItem } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const { searchParams } = new URL(req.url);
    const storeIdParam = searchParams.get('storeId');

    let filter: { userId?: string; storeId?: string } = {};

    if (authUser.role === 'customer') {
      filter.userId = authUser.uid;
    } else if (authUser.role === 'merchant') {
      if (!authUser.storeId) {
        return NextResponse.json({ orders: [] });
      }
      filter.storeId = authUser.storeId;
    } else if (authUser.role === 'admin') {
      if (storeIdParam) filter.storeId = storeIdParam;
    }

    const orders = await dbGetOrders(filter);
    return NextResponse.json({ orders });
  } catch (error: any) {
    return handleApiError(error, 'api/orders GET', 'Failed to fetch orders');
  }
}

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;

    // Unknown keys (userId, totals, status, ...) are stripped, not trusted.
    const parsed = await parseBody(req, createOrderSchema, { code: 'INVALID_REQUEST' });
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const { storeId, items, pickupSlot, customerName, customerPhone, customerNotes } = parsed.data;

    // Merge duplicate product IDs first
    const mergedItemMap = new Map<string, number>();
    for (const it of items) {
      const pid = it.productId;
      const rawQty = it.quantity;
      const current = mergedItemMap.get(pid) || 0;
      const newQty = current + rawQty;
      if (newQty > 50) {
        return NextResponse.json(
          { error: 'INVALID_REQUEST', message: 'Combined quantity for a product cannot exceed 50' },
          { status: 400 }
        );
      }
      mergedItemMap.set(pid, newQty);
    }

    const mergedItems: Array<{ productId: string; quantity: number }> = [];
    for (const [productId, quantity] of mergedItemMap.entries()) {
      mergedItems.push({ productId, quantity });
    }

    if (mergedItems.length === 0 || mergedItems.length > 100) {
      return NextResponse.json({ error: 'INVALID_REQUEST', message: 'Items count must be between 1 and 100' }, { status: 400 });
    }

    const store = await dbGetStoreById(storeId);
    if (!store) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }

    if (!store.isVerified || !store.isOpen) {
      return NextResponse.json(
        { error: 'STORE_UNAVAILABLE', message: 'Store is currently unavailable or closed' },
        { status: 409 }
      );
    }

    // Validate slot ID against generatePickupSlots()
    const slotId = pickupSlot.id || pickupSlot.slotId;
    if (!slotId || typeof slotId !== 'string') {
      return NextResponse.json(
        { error: 'SLOT_UNAVAILABLE', message: 'Selected pickup slot is unavailable' },
        { status: 400 }
      );
    }

    const validSlots = generatePickupSlots();
    const matchedSlot = validSlots.find(s => s.id === slotId);
    if (!matchedSlot) {
      return NextResponse.json(
        { error: 'SLOT_UNAVAILABLE', message: 'Selected pickup slot is unavailable' },
        { status: 400 }
      );
    }

    if (!matchedSlot.isAvailable || matchedSlot.reason === 'SLOT_EXPIRED') {
      return NextResponse.json(
        { error: 'SLOT_EXPIRED', message: 'Selected pickup slot is no longer available' },
        { status: 409 }
      );
    }

    // Fetch products from DB, verify same storeId, verify inStock, compute total server-side
    const orderItems: OrderItem[] = [];
    let itemTotal = 0;

    for (const it of mergedItems) {
      const product = await dbGetProductById(it.productId);
      if (!product) {
        return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
      }

      if (product.isActive === false) {
        return NextResponse.json(
          { error: 'PRODUCT_UNAVAILABLE', message: `Product "${product.name}" is no longer available` },
          { status: 409 }
        );
      }

      if (product.storeId !== store.id) {
        return NextResponse.json(
          { error: 'INVALID_REQUEST', message: `Product ${product.name} does not belong to the selected store` },
          { status: 400 }
        );
      }

      if (!product.inStock) {
        return NextResponse.json(
          { error: 'OUT_OF_STOCK', message: `Product "${product.name}" is out of stock` },
          { status: 409 }
        );
      }

      const subtotal = Math.round(product.price * it.quantity * 100) / 100;
      itemTotal += subtotal;

      orderItems.push({
        productId: product.id,
        name: product.name,
        hindiName: product.hindiName,
        price: product.price,
        unit: product.unit,
        quantity: it.quantity,
        subtotal,
      });
    }

    itemTotal = Math.round(itemTotal * 100) / 100;

    const commissionRate = typeof store.commissionRate === 'number' ? store.commissionRate : 3.5;
    const commissionAmount = Math.round((itemTotal * commissionRate) / 100);

    const now = new Date().toISOString();
    const newOrder: Order = {
      orderNumber: '',
      userId: authUser.uid,
      customerName: (typeof customerName === 'string' && customerName.trim()) || 'Valued Customer',
      customerPhone: (typeof customerPhone === 'string' && customerPhone.trim()) || authUser.phone || '',
      storeId: store.id,
      storeName: store.name,
      storePhone: store.phone,
      storeAddress: `${store.location.address}, ${store.location.area}, ${store.location.city}`,
      items: orderItems,
      itemTotal,
      platformFee: 0,
      totalAmount: itemTotal,
      commissionAmount,
      pickupSlot: {
        slotId: matchedSlot.id,
        slotLabel: matchedSlot.label,
      },
      payment: {
        method: 'PAY_AT_STORE',
        status: 'PENDING_AT_PICKUP',
      },
      status: 'placed',
      statusHistory: [
        {
          status: 'placed',
          timestamp: now,
          note: 'Order placed by customer. Awaiting merchant confirmation.',
          changedBy: authUser.uid,
          changedByRole: authUser.role,
        },
      ],
      customerNotes: typeof customerNotes === 'string' && customerNotes.trim() ? customerNotes.trim() : undefined,
      createdAt: now,
      updatedAt: now,
    };

    const saved = await dbCreateOrder(newOrder);
    return NextResponse.json({ order: saved }, { status: 201 });
  } catch (error: any) {
    return handleApiError(error, 'api/orders POST', 'Order creation failed');
  }
}
