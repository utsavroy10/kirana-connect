import { NextRequest } from 'next/server';
import { patchOrderHandler } from '@/lib/orderPatchHandler';

export async function PATCH(
  req: NextRequest,
  context: { params: { id: string } }
) {
  return patchOrderHandler(req, context);
}
