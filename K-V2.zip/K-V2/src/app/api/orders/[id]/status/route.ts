import { NextRequest } from 'next/server';
import { PATCH as patchOrder } from '../route';

export async function PATCH(
  req: NextRequest,
  context: { params: { id: string } }
) {
  return patchOrder(req, context);
}
