import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetOrderById } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { patchOrderHandler } from '@/lib/orderPatchHandler';

export const dynamic = 'force-dynamic';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const order = await dbGetOrderById(params.id);
    if (!order) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Order not found' }, { status: 404 });
    }

    // Role-based read check: Customer only their own, Merchant only their store, Admin any
    const isOwner = authUser.role === 'customer' && order.userId === authUser.uid;
    const isStoreMerchant = authUser.role === 'merchant' && Boolean(authUser.storeId && order.storeId === authUser.storeId);
    const isAdmin = authUser.role === 'admin';

    if (!isOwner && !isStoreMerchant && !isAdmin) {
      // Return 404 to avoid revealing existence
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Order not found' }, { status: 404 });
    }

    return NextResponse.json({ order });
  } catch (error: any) {
    return handleApiError(error, 'api/orders/[id] GET', 'Failed to fetch order');
  }
}

export async function PATCH(
  req: NextRequest,
  context: { params: { id: string } }
) {
  return patchOrderHandler(req, context);
}
