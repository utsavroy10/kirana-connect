import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetOrderById, dbSaveOrder } from '@/lib/db-adapter';
import { OrderStatus } from '@/types';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const order = await dbGetOrderById(params.id);
    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }

    // Role-based read check: Customer only their own, Merchant only their store, Admin any
    const isOwner = authUser.role === 'customer' && order.userId === authUser.uid;
    const isStoreMerchant = authUser.role === 'merchant' && authUser.storeId && order.storeId === authUser.storeId;
    const isAdmin = authUser.role === 'admin';

    if (!isOwner && !isStoreMerchant && !isAdmin) {
      // Return 404 to avoid revealing existence
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }

    return NextResponse.json({ order });
  } catch (error: any) {
    console.error('[api/orders/[id] GET] Error:', error);
    return NextResponse.json({ error: 'Failed to fetch order' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const order = await dbGetOrderById(params.id);

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }

    const body = await req.json();
    const { status, note, merchantNotes, paymentStatus } = body;

    // Check authorization: Admin or Merchant assigned to this store, or customer cancelling placed order
    if (authUser.role === 'customer') {
      if (order.userId !== authUser.uid) {
        return NextResponse.json({ error: 'Order not found' }, { status: 404 });
      }
      if (status !== 'cancelled' || order.status !== 'placed') {
        return NextResponse.json({ error: 'Customer can only cancel an order while in placed status' }, { status: 403 });
      }
    } else if (authUser.role === 'merchant') {
      if (!authUser.storeId || authUser.storeId !== order.storeId) {
        return NextResponse.json({ error: 'Unauthorized to modify orders of another store' }, { status: 403 });
      }
    } else if (authUser.role !== 'admin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const now = new Date().toISOString();
    const updatedStatusHistory = [...order.statusHistory];

    if (status && status !== order.status) {
      updatedStatusHistory.push({
        status: status as OrderStatus,
        timestamp: now,
        note: note || `Status updated to ${status.replace('_', ' ')}`,
      });
      order.status = status as OrderStatus;
    }

    if (paymentStatus) {
      order.payment.status = paymentStatus;
      if (paymentStatus === 'COLLECTED') {
        order.payment.collectedAt = now;
      }
    }

    if (merchantNotes !== undefined && (authUser.role === 'merchant' || authUser.role === 'admin')) {
      order.merchantNotes = merchantNotes;
    }

    order.statusHistory = updatedStatusHistory;
    order.updatedAt = now;

    const saved = await dbSaveOrder(order);
    return NextResponse.json({ order: saved });
  } catch (error: any) {
    console.error('[api/orders/[id] PATCH] Error:', error);
    return NextResponse.json({ error: 'Failed to update order status' }, { status: 500 });
  }
}
