import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetOrderById, dbTransitionOrder } from '@/lib/db-adapter';
import { isValidStatus, canTransition, canRoleTransition, isValidPaymentStatus } from '@/lib/orderStatus';
import { OrderStatus, OrderStatusHistoryItem } from '@/types';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const order = await dbGetOrderById(params.id);
    if (!order) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Order not found' }, { status: 404 });
    }

    // Role-based read check: Customer only their own, Merchant only their store, Admin any
    const isOwner = authUser.role === 'customer' && order.userId === authUser.uid;
    const isStoreMerchant = authUser.role === 'merchant' && Boolean(authUser.storeId && order.storeId === authUser.storeId);
    const isAdmin = authUser.role === 'admin';

    if (!isOwner && !isStoreMerchant && !isAdmin) {
      // Return 404 to avoid revealing existence
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Order not found' }, { status: 404 });
    }

    return NextResponse.json({ order });
  } catch (error: any) {
    console.error('[api/orders/[id] GET] Error:', error);
    return NextResponse.json({ error: 'INTERNAL_ERROR', message: 'Failed to fetch order' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const order = await dbGetOrderById(params.id);

    if (!order) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Order not found' }, { status: 404 });
    }

    const isOwner = authUser.role === 'customer' && order.userId === authUser.uid;
    const isStoreMerchant = authUser.role === 'merchant' && Boolean(authUser.storeId && order.storeId === authUser.storeId);
    const isAdmin = authUser.role === 'admin';

    // Scoping check
    if (authUser.role === 'customer') {
      if (!isOwner) {
        return NextResponse.json({ error: 'NOT_FOUND', message: 'Order not found' }, { status: 404 });
      }
    } else if (authUser.role === 'merchant') {
      if (!isStoreMerchant) {
        return NextResponse.json({ error: 'FORBIDDEN', message: 'Unauthorized to modify orders of another store' }, { status: 403 });
      }
    } else if (!isAdmin) {
      return NextResponse.json({ error: 'FORBIDDEN', message: 'Forbidden' }, { status: 403 });
    }

    let body: any;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: 'INVALID_JSON', message: 'Invalid JSON body' }, { status: 400 });
    }

    const { status, note, merchantNotes, paymentStatus } = body;

    // Validate note length
    if (note !== undefined) {
      if (typeof note !== 'string' || note.length > 200) {
        return NextResponse.json(
          { error: 'INVALID_NOTE', message: 'Note must be at most 200 characters' },
          { status: 400 }
        );
      }
    }

    // Validate merchantNotes length and role permissions
    if (merchantNotes !== undefined) {
      if (authUser.role !== 'merchant' && authUser.role !== 'admin') {
        return NextResponse.json(
          { error: 'FORBIDDEN', message: 'Only merchants and admins can update merchant notes' },
          { status: 403 }
        );
      }
      if (typeof merchantNotes !== 'string' || merchantNotes.length > 500) {
        return NextResponse.json(
          { error: 'INVALID_MERCHANT_NOTES', message: 'Merchant notes must be at most 500 characters' },
          { status: 400 }
        );
      }
    }

    // Validate status transition
    if (status !== undefined) {
      if (!isValidStatus(status)) {
        return NextResponse.json(
          { error: 'INVALID_STATUS', message: 'Invalid order status' },
          { status: 400 }
        );
      }

      if (status === order.status) {
        return NextResponse.json(
          { error: 'ALREADY_IN_STATUS', message: 'Order is already in this status' },
          { status: 409 }
        );
      }

      if (!canTransition(order.status, status)) {
        return NextResponse.json(
          { error: 'INVALID_TRANSITION', message: `Cannot transition from ${order.status} to ${status}` },
          { status: 409 }
        );
      }

      if (!canRoleTransition(authUser.role, order.status, status, isStoreMerchant, isOwner)) {
        return NextResponse.json(
          { error: 'FORBIDDEN', message: 'User role not permitted to make this transition' },
          { status: 403 }
        );
      }
    }

    const targetStatus = status || order.status;

    // Customer paymentStatus payload is strictly ignored
    const effectivePaymentStatus = authUser.role === 'customer' ? undefined : paymentStatus;

    if (effectivePaymentStatus !== undefined) {
      if (
        effectivePaymentStatus === 'PENDING_AT_PICKUP' &&
        order.payment?.status === 'COLLECTED'
      ) {
        return NextResponse.json(
          { error: 'INVALID_PAYMENT_STATE', message: 'Payment already collected' },
          { status: 409 }
        );
      }

      if (!isValidPaymentStatus(effectivePaymentStatus)) {
        return NextResponse.json(
          { error: 'INVALID_PAYMENT_STATUS', message: 'Invalid payment status' },
          { status: 400 }
        );
      }

      if (effectivePaymentStatus === 'COLLECTED' && targetStatus !== 'completed') {
        return NextResponse.json(
          { error: 'INVALID_PAYMENT_STATE', message: 'Payment can only be marked COLLECTED when order is completed' },
          { status: 409 }
        );
      }
    }

    const now = new Date().toISOString();
    const $set: Record<string, any> = { updatedAt: now };
    const $push: Record<string, any> = {};

    if (status !== undefined) {
      $set.status = status as OrderStatus;
      const historyEntry: OrderStatusHistoryItem = {
        status: status as OrderStatus,
        timestamp: now,
        note: note?.trim() || `Status updated to ${status.replace(/_/g, ' ')}`,
        changedBy: authUser.uid,
        changedByRole: authUser.role,
      };
      $push.statusHistory = historyEntry;
    }

    if (status === 'completed') {
      $set['payment.status'] = 'COLLECTED';
      $set['payment.collectedAt'] = now;
    } else if (effectivePaymentStatus !== undefined) {
      $set['payment.status'] = effectivePaymentStatus;
      if (effectivePaymentStatus === 'COLLECTED') {
        $set['payment.collectedAt'] = now;
      }
    }

    if (merchantNotes !== undefined && (authUser.role === 'merchant' || authUser.role === 'admin')) {
      $set.merchantNotes = merchantNotes.trim();
    }

    const updateDoc: { $set?: Record<string, any>; $push?: Record<string, any> } = { $set };
    if (Object.keys($push).length > 0) {
      updateDoc.$push = $push;
    }

    const result = await dbTransitionOrder(order.orderNumber, order.status, updateDoc);

    if (!result.success) {
      if (result.error === 'ORDER_CHANGED') {
        return NextResponse.json(
          { error: 'ORDER_CHANGED', message: 'Order was modified by another request' },
          { status: 409 }
        );
      }
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Order not found' }, { status: 404 });
    }

    return NextResponse.json({ order: result.order });
  } catch (error: any) {
    console.error('[api/orders/[id] PATCH] Error:', error);
    return NextResponse.json({ error: 'INTERNAL_ERROR', message: 'Failed to update order status' }, { status: 500 });
  }
}
