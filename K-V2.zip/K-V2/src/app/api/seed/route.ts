import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbSeedInitialData } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';

export async function POST(req: NextRequest) {
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json({ error: 'NOT_FOUND', message: 'Not found' }, { status: 404 });
  }

  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const result = await dbSeedInitialData();
    return NextResponse.json(result);
  } catch (error: any) {
    return handleApiError(error, 'api/seed POST', 'Seed failed');
  }
}
