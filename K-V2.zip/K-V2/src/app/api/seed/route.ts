import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbSeedInitialData } from '@/lib/db-adapter';

export async function POST(req: NextRequest) {
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }

  const authResult = await requireAuth(req, ['admin']);
  if (authResult.errorResponse) {
    return authResult.errorResponse;
  }

  try {
    const result = await dbSeedInitialData();
    return NextResponse.json(result);
  } catch (error: any) {
    console.error('[api/seed] Error:', error);
    return NextResponse.json({ error: 'Seed failed' }, { status: 500 });
  }
}
