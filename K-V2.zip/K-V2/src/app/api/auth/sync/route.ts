import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/mongodb';
import { requireAuth } from '@/lib/authMiddleware';
import { User } from '@/types';

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const body = await req.json().catch(() => ({}));
    const name = typeof body.name === 'string' && body.name.trim() ? body.name.trim() : 'Kirana Customer';

    const now = new Date().toISOString();
    let finalUser: User = {
      uid: authUser.uid,
      phone: authUser.phone || '',
      name,
      role: 'customer',
      createdAt: now,
      updatedAt: now,
    };

    try {
      const { db } = await connectToDatabase();
      const existingUser = await db.collection<User>('users').findOne({ uid: authUser.uid });

      if (existingUser) {
        finalUser = {
          ...existingUser,
          name: name || existingUser.name,
          phone: authUser.phone || existingUser.phone || '',
          updatedAt: now,
        };
        await db.collection('users').updateOne(
          { uid: authUser.uid },
          {
            $set: {
              name: finalUser.name,
              phone: finalUser.phone,
              updatedAt: now,
            },
          }
        );
      } else {
        await db.collection('users').insertOne(finalUser);
      }

      const savedUser = await db.collection<User>('users').findOne({ uid: authUser.uid });
      return NextResponse.json({ user: savedUser || finalUser });
    } catch (dbErr) {
      console.warn('[auth/sync] DB operation fallback:', dbErr);
      return NextResponse.json({ user: finalUser });
    }
  } catch (err: any) {
    console.error('[auth/sync] Error:', err);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
