import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbSyncUser } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const body = await req.json().catch(() => ({}));
    const bodyName =
      body && typeof body.name === 'string' && body.name.trim().length > 0 ? body.name.trim() : undefined;

    // Role/storeId from the client are ignored: new users are always 'customer'.
    const user = await dbSyncUser(authUser.uid, authUser.phone || '', bodyName);
    return NextResponse.json({ user });
  } catch (err: any) {
    return handleApiError(err, 'auth/sync POST', 'Failed to sync user');
  }
}
