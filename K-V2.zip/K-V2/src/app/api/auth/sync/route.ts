import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbSyncUser } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody } from '@/lib/validation/parse';
import { authSyncSchema } from '@/lib/validation/user';

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    // role / storeId / uid in the body are stripped; an empty body is allowed.
    const parsed = await parseBody(req, authSyncSchema, { allowEmpty: true });
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const bodyName = parsed.data.name ? parsed.data.name : undefined;

    // Role/storeId from the client are ignored: new users are always 'customer'.
    const user = await dbSyncUser(authUser.uid, authUser.phone || '', bodyName);
    return NextResponse.json({ user });
  } catch (err: any) {
    return handleApiError(err, 'auth/sync POST', 'Failed to sync user');
  }
}
