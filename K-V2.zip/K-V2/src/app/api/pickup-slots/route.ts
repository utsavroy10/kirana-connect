import { NextRequest, NextResponse } from 'next/server';
import { generatePickupSlots } from '@/lib/mock-data';

export async function GET(req: NextRequest) {
  try {
    const slots = generatePickupSlots();
    return NextResponse.json({ slots });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch slots' }, { status: 500 });
  }
}
