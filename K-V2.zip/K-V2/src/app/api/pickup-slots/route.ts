import { NextRequest, NextResponse } from 'next/server';
import { generatePickupSlots } from '@/lib/mock-data';
import { handleApiError } from '@/lib/apiErrors';

// Time-dependent: must be evaluated per request, never at build time.
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const slots = generatePickupSlots();
    return NextResponse.json({ slots });
  } catch (error: any) {
    return handleApiError(error, 'api/pickup-slots GET', 'Failed to fetch slots');
  }
}
