import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetProductById, dbGetStoreById, dbGetCart, dbSaveCart, dbClearCart } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { Cart, CartItem } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const userId = authResult.user.uid;

    const cart = (await dbGetCart(userId)) || {
      userId,
      storeId: '',
      items: [],
      itemTotal: 0,
      updatedAt: new Date().toISOString(),
    };

    return NextResponse.json({ cart });
  } catch (error: any) {
    return handleApiError(error, 'api/cart GET', 'Cart fetch failed');
  }
}

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const userId = authResult.user.uid;
    let body: any;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: 'INVALID_JSON', message: 'Invalid JSON body' }, { status: 400 });
    }
    const { productId, quantity, clearPrevious } = body || {};

    if (typeof productId !== 'string' || !productId.trim()) {
      return NextResponse.json({ error: 'INVALID_REQUEST', message: 'productId is required' }, { status: 400 });
    }

    if (!Number.isInteger(quantity) || quantity < 0 || quantity > 50) {
      return NextResponse.json(
        { error: 'INVALID_REQUEST', message: 'Quantity must be an integer between 0 and 50' },
        { status: 400 }
      );
    }

    const product = await dbGetProductById(productId);
    if (!product || product.isActive === false) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
    }

    let cart: Cart | null = await dbGetCart(userId);

    // Check single store rule
    if (cart && cart.items.length > 0 && cart.storeId && cart.storeId !== product.storeId) {
      if (!clearPrevious) {
        return NextResponse.json(
          {
            error: 'STORE_MISMATCH',
            currentStoreId: cart.storeId,
            currentStoreName: cart.storeName,
            newStoreId: product.storeId,
            message: `Your cart already contains items from "${cart.storeName || 'another store'}". Discard cart and start fresh with this store?`,
          },
          { status: 409 }
        );
      } else {
        // Discard previous cart items
        cart = {
          userId,
          storeId: product.storeId,
          storeName: '',
          items: [],
          itemTotal: 0,
          updatedAt: new Date().toISOString(),
        };
      }
    }

    const store = await dbGetStoreById(product.storeId);
    if (!cart) {
      cart = {
        userId,
        storeId: product.storeId,
        storeName: store?.name || '',
        items: [],
        itemTotal: 0,
        updatedAt: new Date().toISOString(),
      };
    } else {
      cart.storeId = product.storeId;
      cart.storeName = store?.name || cart.storeName || '';
    }

    const existingIdx = cart.items.findIndex(item => item.productId === productId);

    if (quantity <= 0) {
      if (existingIdx >= 0) {
        cart.items.splice(existingIdx, 1);
      }
    } else {
      const cartItem: CartItem = {
        productId: product.id,
        name: product.name,
        hindiName: product.hindiName,
        price: product.price,
        unit: product.unit,
        quantity: quantity,
        imageUrl: product.imageUrl,
        storeId: product.storeId,
      };

      if (existingIdx >= 0) {
        cart.items[existingIdx].quantity = quantity;
      } else {
        cart.items.push(cartItem);
      }
    }

    // Reset storeId if cart is empty
    if (cart.items.length === 0) {
      cart.storeId = '';
      cart.storeName = '';
    }

    cart.itemTotal = Math.round(cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0) * 100) / 100;
    cart.updatedAt = new Date().toISOString();
    const saved = await dbSaveCart(cart);

    return NextResponse.json({ cart: saved });
  } catch (error: any) {
    return handleApiError(error, 'api/cart POST', 'Failed to update cart');
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const userId = authResult.user.uid;

    await dbClearCart(userId);

    const cart: Cart = {
      userId,
      storeId: '',
      storeName: '',
      items: [],
      itemTotal: 0,
      updatedAt: new Date().toISOString(),
    };

    return NextResponse.json({ cart, message: 'Cart cleared' });
  } catch (error: any) {
    return handleApiError(error, 'api/cart DELETE', 'Failed to clear cart');
  }
}
