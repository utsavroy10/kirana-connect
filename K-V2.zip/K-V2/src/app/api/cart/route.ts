import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetProductById, dbGetStoreById } from '@/lib/db-adapter';
import { Cart, CartItem } from '@/types';

// In-memory or session-based cart store for POC
let userCarts: Record<string, Cart> = {};

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const userId = authResult.user.uid;

    const cart = userCarts[userId] || {
      userId,
      storeId: '',
      items: [],
      itemTotal: 0,
      updatedAt: new Date().toISOString(),
    };

    return NextResponse.json({ cart });
  } catch (error: any) {
    console.error('[api/cart GET] Error:', error);
    return NextResponse.json({ error: 'Cart fetch failed' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const userId = authResult.user.uid;
    const body = await req.json();
    const { productId, quantity, clearPrevious } = body;

    const product = await dbGetProductById(productId);
    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 });
    }

    let cart = userCarts[userId];

    // Check single store rule
    if (cart && cart.items.length > 0 && cart.storeId && cart.storeId !== product.storeId) {
      if (!clearPrevious) {
        return NextResponse.json(
          {
            error: 'STORE_MISMATCH',
            currentStoreId: cart.storeId,
            currentStoreName: cart.storeName,
            newStoreId: product.storeId,
            message: `Your cart already contains items from "${cart.storeName || 'another store'}". Discard cart and start fresh with this store?`,
          },
          { status: 409 }
        );
      } else {
        // Discard previous cart items
        cart = {
          userId,
          storeId: product.storeId,
          storeName: '',
          items: [],
          itemTotal: 0,
          updatedAt: new Date().toISOString(),
        };
      }
    }

    const store = await dbGetStoreById(product.storeId);
    if (!cart) {
      cart = {
        userId,
        storeId: product.storeId,
        storeName: store?.name || '',
        items: [],
        itemTotal: 0,
        updatedAt: new Date().toISOString(),
      };
    } else {
      cart.storeId = product.storeId;
      cart.storeName = store?.name || cart.storeName || '';
    }

    const existingIdx = cart.items.findIndex(item => item.productId === productId);

    if (quantity <= 0) {
      if (existingIdx >= 0) {
        cart.items.splice(existingIdx, 1);
      }
    } else {
      const cartItem: CartItem = {
        productId: product.id,
        name: product.name,
        hindiName: product.hindiName,
        price: product.price,
        unit: product.unit,
        quantity: quantity,
        imageUrl: product.imageUrl,
        storeId: product.storeId,
      };

      if (existingIdx >= 0) {
        cart.items[existingIdx].quantity = quantity;
      } else {
        cart.items.push(cartItem);
      }
    }

    // Reset storeId if cart is empty
    if (cart.items.length === 0) {
      cart.storeId = '';
      cart.storeName = '';
    }

    cart.itemTotal = cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    cart.updatedAt = new Date().toISOString();
    userCarts[userId] = cart;

    return NextResponse.json({ cart });
  } catch (error: any) {
    console.error('[api/cart POST] Error:', error);
    return NextResponse.json({ error: 'Failed to update cart' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const userId = authResult.user.uid;

    userCarts[userId] = {
      userId,
      storeId: '',
      storeName: '',
      items: [],
      itemTotal: 0,
      updatedAt: new Date().toISOString(),
    };

    return NextResponse.json({ cart: userCarts[userId], message: 'Cart cleared' });
  } catch (error: any) {
    console.error('[api/cart DELETE] Error:', error);
    return NextResponse.json({ error: 'Failed to clear cart' }, { status: 500 });
  }
}
