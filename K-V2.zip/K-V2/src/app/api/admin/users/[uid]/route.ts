import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { connectToDatabase } from '@/lib/mongodb';
import { dbGetStoreById } from '@/lib/db-adapter';
import { User, UserRole } from '@/types';

export async function PATCH(
  req: NextRequest,
  { params }: { params: { uid: string } }
) {
  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const { uid } = params;
    if (!uid) {
      return NextResponse.json({ error: 'User UID is required' }, { status: 400 });
    }

    const body = await req.json();
    const { role, storeId } = body;

    const validRoles: UserRole[] = ['customer', 'merchant', 'admin'];
    if (role && !validRoles.includes(role)) {
      return NextResponse.json({ error: 'Invalid role' }, { status: 400 });
    }

    if (role === 'merchant' && !storeId) {
      return NextResponse.json({ error: 'storeId is required for merchant role' }, { status: 400 });
    }

    if (storeId) {
      const store = await dbGetStoreById(storeId);
      if (!store) {
        return NextResponse.json({ error: 'Store not found' }, { status: 404 });
      }
    }

    const updateFields: Partial<User> = {
      updatedAt: new Date().toISOString(),
    };
    if (role) updateFields.role = role;
    if (storeId !== undefined) updateFields.storeId = storeId || undefined;

    const { db } = await connectToDatabase();
    const result = await db.collection<User>('users').findOneAndUpdate(
      { uid },
      { $set: updateFields },
      { returnDocument: 'after' }
    );

    if (!result) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    return NextResponse.json({ user: result });
  } catch (error: any) {
    console.error('[admin/users/[uid]] Error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
