import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetStoreById, dbUpdateUserRole } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody } from '@/lib/validation/parse';
import { adminUserPatchSchema } from '@/lib/validation/user';

export async function PATCH(
  req: NextRequest,
  { params }: { params: { uid: string } }
) {
  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const { uid } = params;
    if (!uid) {
      return NextResponse.json({ error: 'VALIDATION_ERROR', message: 'User UID is required' }, { status: 400 });
    }

    const parsed = await parseBody(req, adminUserPatchSchema);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const { role, storeId } = parsed.data;

    if (role === undefined && storeId === undefined) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'At least one field (role or storeId) is required' },
        { status: 400 }
      );
    }

    // Prevent admin self-demotion lockout
    if (authResult.user.uid === uid && role && role !== 'admin') {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Cannot demote your own admin account' },
        { status: 400 }
      );
    }

    if (storeId !== undefined && role !== 'merchant') {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'storeId is only allowed when role is merchant' },
        { status: 400 }
      );
    }

    if (role === 'merchant' && !storeId) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'storeId is required for merchant role' },
        { status: 400 }
      );
    }

    if (storeId) {
      const store = await dbGetStoreById(storeId);
      if (!store) {
        return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
      }
    }

    const updateDoc: any = {
      $set: {
        updatedAt: new Date().toISOString(),
      },
    };

    if (role) {
      updateDoc.$set.role = role;
    }

    if (role === 'merchant') {
      updateDoc.$set.storeId = storeId;
    } else if (role) {
      // Clear storeId when demoting from merchant
      updateDoc.$unset = { storeId: '' };
    }

    const result = await dbUpdateUserRole(uid, updateDoc);
    if (!result) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'User not found' }, { status: 404 });
    }

    return NextResponse.json({ user: result });
  } catch (error: any) {
    return handleApiError(error, 'admin/users/[uid] PATCH', 'Failed to update user');
  }
}
