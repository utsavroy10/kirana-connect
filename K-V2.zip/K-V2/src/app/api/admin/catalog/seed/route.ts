import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetStoreById, dbGetProductsByStore, dbSaveProduct } from '@/lib/db-adapter';
import { StoreProduct } from '@/types';

const TEMPLATE_CATALOG: Omit<StoreProduct, 'id' | 'storeId' | 'createdAt' | 'updatedAt'>[] = [
  {
    name: 'Aashirvaad Shudh Chakki Atta',
    hindiName: 'आशीर्वाद चक्की आटा',
    category: 'Atta & Flour',
    price: 24500, // ₹245.00 in paise
    mrp: 27500, // ₹275.00 in paise
    unit: '5 kg',
    inStock: true,
    isActive: true,
    description: '100% whole wheat flour with dietary fiber for soft rotis.',
  },
  {
    name: 'Fortune Sunlite Refined Sunflower Oil',
    hindiName: 'फॉर्च्यून सूरजमुखी तेल',
    category: 'Cooking Oils & Ghee',
    price: 13500, // ₹135.00 in paise
    mrp: 16000, // ₹160.00 in paise
    unit: '1 litre pouch',
    inStock: true,
    isActive: true,
    description: 'Light and healthy refined sunflower oil enriched with vitamins A & D.',
  },
  {
    name: 'Tata Sampann Unpolished Toor Dal',
    hindiName: 'टाटा संपन्न अरहर दाल',
    category: 'Rice & Pulses',
    price: 17500, // ₹175.00 in paise
    mrp: 19500, // ₹195.00 in paise
    unit: '1 kg',
    inStock: true,
    isActive: true,
    description: 'Unpolished toor dal rich in natural protein and wholesome taste.',
  },
  {
    name: 'India Gate Basmati Rice Feast Rozzana',
    hindiName: 'इंडिया गेट बासमती चावल',
    category: 'Rice & Pulses',
    price: 9500, // ₹95.00 in paise
    mrp: 12000, // ₹120.00 in paise
    unit: '1 kg',
    inStock: true,
    isActive: true,
    description: 'Fluffy, aromatic long grain basmati rice for daily meals.',
  },
  {
    name: 'Amul Pure Ghee Pouch',
    hindiName: 'अमुल शुद्ध घी',
    category: 'Cooking Oils & Ghee',
    price: 29000, // ₹290.00 in paise
    mrp: 31000, // ₹310.00 in paise
    unit: '500 ml',
    inStock: true,
    isActive: true,
    description: 'Pure rich aroma granular cow & buffalo ghee.',
  },
  {
    name: 'Tata Salt Vacuum Evaporated Iodized',
    hindiName: 'टाटा नमक',
    category: 'Spices & Masalas',
    price: 2800, // ₹28.00 in paise
    mrp: 3000, // ₹30.00 in paise
    unit: '1 kg',
    inStock: true,
    isActive: true,
    description: 'Desh Ka Namak with essential iodine for health.',
  },
  {
    name: 'Everest Turmeric Powder (Haldi)',
    hindiName: 'एवरेस्ट हल्दी पाउडर',
    category: 'Spices & Masalas',
    price: 6200, // ₹62.00 in paise
    mrp: 7000, // ₹70.00 in paise
    unit: '200 g',
    inStock: true,
    isActive: true,
    description: 'High curcumin rich golden yellow turmeric powder.',
  },
  {
    name: 'Amul Taaza Homogenised Toned Milk',
    hindiName: 'अमुल ताजा दूध',
    category: 'Dairy & Eggs',
    price: 7400, // ₹74.00 in paise
    mrp: 7600, // ₹76.00 in paise
    unit: '1 litre tetra',
    inStock: true,
    isActive: true,
    description: 'Fresh UHT treated toned milk, long shelf life.',
  },
  {
    name: 'Red Label Strong Blend Tea',
    hindiName: 'रेड लेबल चाय',
    category: 'Beverages',
    price: 31000, // ₹310.00 in paise
    mrp: 35000, // ₹350.00 in paise
    unit: '500 g',
    inStock: true,
    isActive: true,
    description: 'Rich taste with irresistible long leaf aroma.',
  },
  {
    name: 'Madhur Pure & Hygienic Sugar',
    hindiName: 'मधुर चीनी',
    category: 'General Grocery',
    price: 4800, // ₹48.00 in paise
    mrp: 5500, // ₹55.00 in paise
    unit: '1 kg',
    inStock: true,
    isActive: true,
    description: 'Refined sulphurless sparkling white sugar crystals.',
  },
];

export async function POST(req: NextRequest) {
  // Disabled in production
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json({ error: 'NOT_FOUND', message: 'Not found' }, { status: 404 });
  }

  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    let body: any;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: 'INVALID_JSON', message: 'Invalid JSON body' }, { status: 400 });
    }

    const { storeId } = body;
    if (!storeId || typeof storeId !== 'string') {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'storeId is required' },
        { status: 400 }
      );
    }

    const store = await dbGetStoreById(storeId);
    if (!store) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }

    const existingProducts = await dbGetProductsByStore(storeId);
    const existingNameSet = new Set(existingProducts.map((p) => p.name.trim().toLowerCase()));

    const seededProducts: StoreProduct[] = [];
    const now = new Date().toISOString();

    for (let i = 0; i < TEMPLATE_CATALOG.length; i++) {
      const template = TEMPLATE_CATALOG[i];
      if (!existingNameSet.has(template.name.trim().toLowerCase())) {
        const newProduct: StoreProduct = {
          id: `prod_${storeId}_${Date.now()}_${i + 1}`,
          storeId,
          ...template,
          createdAt: now,
          updatedAt: now,
        };
        const saved = await dbSaveProduct(newProduct);
        seededProducts.push(saved);
        existingNameSet.add(template.name.trim().toLowerCase());
      }
    }

    return NextResponse.json({
      success: true,
      message: `Successfully seeded ${seededProducts.length} template products into ${store.name}`,
      seededCount: seededProducts.length,
      products: seededProducts,
    });
  } catch (error: any) {
    console.error('[api/admin/catalog/seed POST] Error:', error);
    return NextResponse.json(
      { error: 'INTERNAL_ERROR', message: 'Failed to seed catalog' },
      { status: 500 }
    );
  }
}
