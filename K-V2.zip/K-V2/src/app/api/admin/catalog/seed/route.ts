import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetStoreById, dbGetProductsByStore, dbSaveProduct } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody } from '@/lib/validation/parse';
import { catalogSeedSchema } from '@/lib/validation/user';
import { StoreProduct } from '@/types';

const TEMPLATE_CATALOG: Omit<StoreProduct, 'id' | 'storeId' | 'createdAt' | 'updatedAt'>[] = [
  {
    name: 'Aashirvaad Shudh Chakki Atta',
    hindiName: 'आशीर्वाद चक्की आटा',
    category: 'Atta & Flour',
    price: 245, // ₹245
    mrp: 275, // ₹275
    unit: '5 kg',
    inStock: true,
    isActive: true,
    description: '100% whole wheat flour with dietary fiber for soft rotis.',
  },
  {
    name: 'Fortune Sunlite Refined Sunflower Oil',
    hindiName: 'फॉर्च्यून सूरजमुखी तेल',
    category: 'Cooking Oils & Ghee',
    price: 135, // ₹135
    mrp: 160, // ₹160
    unit: '1 litre pouch',
    inStock: true,
    isActive: true,
    description: 'Light and healthy refined sunflower oil enriched with vitamins A & D.',
  },
  {
    name: 'Tata Sampann Unpolished Toor Dal',
    hindiName: 'टाटा संपन्न अरहर दाल',
    category: 'Rice & Pulses',
    price: 175, // ₹175
    mrp: 195, // ₹195
    unit: '1 kg',
    inStock: true,
    isActive: true,
    description: 'Unpolished toor dal rich in natural protein and wholesome taste.',
  },
  {
    name: 'India Gate Basmati Rice Feast Rozzana',
    hindiName: 'इंडिया गेट बासमती चावल',
    category: 'Rice & Pulses',
    price: 95, // ₹95
    mrp: 120, // ₹120
    unit: '1 kg',
    inStock: true,
    isActive: true,
    description: 'Fluffy, aromatic long grain basmati rice for daily meals.',
  },
  {
    name: 'Amul Pure Ghee Pouch',
    hindiName: 'अमुल शुद्ध घी',
    category: 'Cooking Oils & Ghee',
    price: 290, // ₹290
    mrp: 310, // ₹310
    unit: '500 ml',
    inStock: true,
    isActive: true,
    description: 'Pure rich aroma granular cow & buffalo ghee.',
  },
  {
    name: 'Tata Salt Vacuum Evaporated Iodized',
    hindiName: 'टाटा नमक',
    category: 'Spices & Masalas',
    price: 28, // ₹28
    mrp: 30, // ₹30
    unit: '1 kg',
    inStock: true,
    isActive: true,
    description: 'Desh Ka Namak with essential iodine for health.',
  },
  {
    name: 'Everest Turmeric Powder (Haldi)',
    hindiName: 'एवरेस्ट हल्दी पाउडर',
    category: 'Spices & Masalas',
    price: 62, // ₹62
    mrp: 70, // ₹70
    unit: '200 g',
    inStock: true,
    isActive: true,
    description: 'High curcumin rich golden yellow turmeric powder.',
  },
  {
    name: 'Amul Taaza Homogenised Toned Milk',
    hindiName: 'अमुल ताजा दूध',
    category: 'Dairy & Eggs',
    price: 74, // ₹74
    mrp: 76, // ₹76
    unit: '1 litre tetra',
    inStock: true,
    isActive: true,
    description: 'Fresh UHT treated toned milk, long shelf life.',
  },
  {
    name: 'Red Label Strong Blend Tea',
    hindiName: 'रेड लेबल चाय',
    category: 'Beverages',
    price: 310, // ₹310
    mrp: 350, // ₹350
    unit: '500 g',
    inStock: true,
    isActive: true,
    description: 'Rich taste with irresistible long leaf aroma.',
  },
  {
    name: 'Madhur Pure & Hygienic Sugar',
    hindiName: 'मधुर चीनी',
    category: 'General Grocery',
    price: 48, // ₹48
    mrp: 55, // ₹55
    unit: '1 kg',
    inStock: true,
    isActive: true,
    description: 'Refined sulphurless sparkling white sugar crystals.',
  },
];

export async function POST(req: NextRequest) {
  // Disabled in production
  if (process.env.NODE_ENV === 'production') {
    return NextResponse.json({ error: 'NOT_FOUND', message: 'Not found' }, { status: 404 });
  }

  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const parsed = await parseBody(req, catalogSeedSchema);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const { storeId } = parsed.data;

    const store = await dbGetStoreById(storeId);
    if (!store) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }

    const existingProducts = await dbGetProductsByStore(storeId);
    const existingNameSet = new Set(existingProducts.map((p) => p.name.trim().toLowerCase()));

    const seededProducts: StoreProduct[] = [];
    const now = new Date().toISOString();

    for (let i = 0; i < TEMPLATE_CATALOG.length; i++) {
      const template = TEMPLATE_CATALOG[i];
      if (!existingNameSet.has(template.name.trim().toLowerCase())) {
        const newProduct: StoreProduct = {
          id: `prod_${storeId}_${Date.now()}_${i + 1}`,
          storeId,
          ...template,
          createdAt: now,
          updatedAt: now,
        };
        const saved = await dbSaveProduct(newProduct);
        seededProducts.push(saved);
        existingNameSet.add(template.name.trim().toLowerCase());
      }
    }

    return NextResponse.json({
      success: true,
      message: `Successfully seeded ${seededProducts.length} template products into ${store.name}`,
      seededCount: seededProducts.length,
      products: seededProducts,
    });
  } catch (error: any) {
    return handleApiError(error, 'api/admin/catalog/seed POST', 'Failed to seed catalog');
  }
}
