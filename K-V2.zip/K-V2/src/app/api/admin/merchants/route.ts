import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetStores, dbSaveStore } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const stores = await dbGetStores();
    return NextResponse.json({ merchants: stores });
  } catch (error: any) {
    return handleApiError(error, 'admin/merchants GET', 'Failed to fetch merchants');
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const body = await req.json();
    const { storeId, isVerified, isOpen, commissionRate } = body;

    const stores = await dbGetStores();
    const targetStore = stores.find(s => s.id === storeId);
    if (!targetStore) {
      return NextResponse.json({ error: 'Store not found' }, { status: 404 });
    }

    if (isVerified !== undefined) targetStore.isVerified = isVerified;
    if (isOpen !== undefined) targetStore.isOpen = isOpen;
    if (commissionRate !== undefined) targetStore.commissionRate = commissionRate;
    targetStore.updatedAt = new Date().toISOString();

    const saved = await dbSaveStore(targetStore);
    return NextResponse.json({ merchant: saved });
  } catch (error: any) {
    return handleApiError(error, 'admin/merchants PATCH', 'Failed to update merchant');
  }
}
