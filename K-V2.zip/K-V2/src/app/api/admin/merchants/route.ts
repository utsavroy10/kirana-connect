import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetStores, dbGetStoreById, dbUpdateStoreFields } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody } from '@/lib/validation/parse';
import { omitUndefined } from '@/lib/validation/common';
import { adminMerchantPatchSchema } from '@/lib/validation/store';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const stores = await dbGetStores();
    return NextResponse.json({ merchants: stores });
  } catch (error: any) {
    return handleApiError(error, 'admin/merchants GET', 'Failed to fetch merchants');
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    // Strict: unknown keys -> 400, at least one of isVerified / isOpen / commissionRate.
    const parsed = await parseBody(req, adminMerchantPatchSchema);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const { storeId, ...changes } = parsed.data;

    const existing = await dbGetStoreById(storeId);
    if (!existing) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }

    // $set only the supplied fields (no read-modify-write of the whole document).
    const fields: Record<string, any> = { ...omitUndefined(changes), updatedAt: new Date().toISOString() };
    const saved = await dbUpdateStoreFields(storeId, fields);
    if (!saved) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }
    return NextResponse.json({ merchant: saved });
  } catch (error: any) {
    return handleApiError(error, 'admin/merchants PATCH', 'Failed to update merchant');
  }
}
