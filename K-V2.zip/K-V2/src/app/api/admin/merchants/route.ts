import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetStores, dbSaveStore } from '@/lib/db-adapter';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const stores = await dbGetStores();
    return NextResponse.json({ merchants: stores });
  } catch (error: any) {
    console.error('[admin/merchants GET] Error:', error);
    return NextResponse.json({ error: 'Failed to fetch merchants' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const body = await req.json();
    const { storeId, isVerified, isOpen, commissionRate } = body;

    const stores = await dbGetStores();
    const targetStore = stores.find(s => s.id === storeId);
    if (!targetStore) {
      return NextResponse.json({ error: 'Store not found' }, { status: 404 });
    }

    if (isVerified !== undefined) targetStore.isVerified = isVerified;
    if (isOpen !== undefined) targetStore.isOpen = isOpen;
    if (commissionRate !== undefined) targetStore.commissionRate = commissionRate;
    targetStore.updatedAt = new Date().toISOString();

    const saved = await dbSaveStore(targetStore);
    return NextResponse.json({ merchant: saved });
  } catch (error: any) {
    console.error('[admin/merchants PATCH] Error:', error);
    return NextResponse.json({ error: 'Failed to update merchant' }, { status: 500 });
  }
}
