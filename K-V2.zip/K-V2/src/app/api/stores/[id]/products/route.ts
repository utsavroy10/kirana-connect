import { NextRequest, NextResponse } from 'next/server';
import { dbGetProductsByStore, dbGetProductById, dbSaveProduct } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';
import { handleApiError } from '@/lib/apiErrors';
import { parseJson, validate, findPresentKeys } from '@/lib/validation/parse';
import { omitUndefined } from '@/lib/validation/common';
import { legacyProductCreateSchema, PRODUCT_IMMUTABLE_FIELDS } from '@/lib/validation/product';
import { StoreProduct } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const allProducts = await dbGetProductsByStore(params.id);
    // Soft-deleted products are hidden from customers
    const products = allProducts.filter((p) => p.isActive !== false);
    return NextResponse.json({ products });
  } catch (error: any) {
    return handleApiError(error, 'api/stores/[id]/products GET', 'Failed to fetch products');
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const isAdmin = authUser.role === 'admin';
    if (!isAdmin && !(authUser.role === 'merchant' && authUser.storeId === params.id)) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'Unauthorized to add products to this store' },
        { status: 403 }
      );
    }

    const json = await parseJson(req);
    if (json.errorResponse) {
      return json.errorResponse as NextResponse;
    }

    const immutable = findPresentKeys(json.value, PRODUCT_IMMUTABLE_FIELDS);
    if (immutable.length > 0) {
      return NextResponse.json(
        { error: 'IMMUTABLE_FIELD', message: `These fields cannot be set: ${immutable.join(', ')}`, fields: immutable },
        { status: 400 }
      );
    }

    // Merchants never choose a product id (the server generates it).
    if (!isAdmin && findPresentKeys(json.value, ['id']).length > 0) {
      return NextResponse.json(
        { error: 'FORBIDDEN_FIELD', message: 'Only an admin can set a product id', fields: ['id'] },
        { status: 403 }
      );
    }

    // Strict whitelist: unknown keys -> 400.
    const parsed = validate(legacyProductCreateSchema, json.value);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const input = parsed.data;

    const price = input.price;
    const mrp = input.mrp !== undefined ? input.mrp : price;
    if (mrp < price) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'mrp (in rupees) must be greater than or equal to the selling price' },
        { status: 400 }
      );
    }

    // Product ids are global: never overwrite (hijack) a product of another store.
    // Generated ids use the prod_l_ prefix (distinct from the migration script's id patterns).
    let productId = `prod_l_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;
    let createdAt = new Date().toISOString();
    if (input.id !== undefined) {
      const existing = await dbGetProductById(input.id);
      if (existing && existing.storeId !== params.id) {
        return NextResponse.json(
          { error: 'ID_CONFLICT', message: 'A product with this id already exists in another store' },
          { status: 409 }
        );
      }
      if (existing) createdAt = existing.createdAt;
      productId = input.id;
    }

    const now = new Date().toISOString();
    const { id: _ignoredId, ...fields } = input;
    const newProduct: StoreProduct = {
      ...omitUndefined(fields),
      id: productId,
      storeId: params.id,
      mrp,
      inStock: input.inStock !== undefined ? input.inStock : true,
      createdAt,
      updatedAt: now,
    };

    const saved = await dbSaveProduct(newProduct);
    return NextResponse.json({ product: saved }, { status: 201 });
  } catch (error: any) {
    return handleApiError(error, 'api/stores/[id]/products POST', 'Failed to create product');
  }
}
