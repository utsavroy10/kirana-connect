import { NextRequest, NextResponse } from 'next/server';
import { dbGetProductsByStore, dbSaveProduct } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';
import { StoreProduct } from '@/types';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const products = await dbGetProductsByStore(params.id);
    return NextResponse.json({ products });
  } catch (error: any) {
    console.error('[api/stores/[id]/products GET] Error:', error);
    return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    if (authUser.role !== 'admin' && authUser.storeId !== params.id) {
      return NextResponse.json({ error: 'Unauthorized to add product to this store' }, { status: 403 });
    }

    const body = await req.json();
    const newProduct: StoreProduct = {
      ...body,
      id: body.id || `prod_${Date.now()}`,
      storeId: params.id,
      inStock: body.inStock !== undefined ? body.inStock : true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveProduct(newProduct);
    return NextResponse.json({ product: saved }, { status: 201 });
  } catch (error: any) {
    console.error('[api/stores/[id]/products POST] Error:', error);
    return NextResponse.json({ error: 'Failed to create product' }, { status: 500 });
  }
}
