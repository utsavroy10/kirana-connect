import { NextRequest, NextResponse } from 'next/server';
import { dbGetProductsByStore, dbSaveProduct } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';
import { handleApiError } from '@/lib/apiErrors';
import { StoreProduct } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const allProducts = await dbGetProductsByStore(params.id);
    // Soft-deleted products are hidden from customers
    const products = allProducts.filter((p) => p.isActive !== false);
    return NextResponse.json({ products });
  } catch (error: any) {
    return handleApiError(error, 'api/stores/[id]/products GET', 'Failed to fetch products');
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    if (authUser.role !== 'admin' && authUser.storeId !== params.id) {
      return NextResponse.json({ error: 'Unauthorized to add product to this store' }, { status: 403 });
    }

    const body = await req.json();
    const newProduct: StoreProduct = {
      ...body,
      id: body.id || `prod_${Date.now()}`,
      storeId: params.id,
      inStock: body.inStock !== undefined ? body.inStock : true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveProduct(newProduct);
    return NextResponse.json({ product: saved }, { status: 201 });
  } catch (error: any) {
    return handleApiError(error, 'api/stores/[id]/products POST', 'Failed to create product');
  }
}
