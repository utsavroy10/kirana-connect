import { NextRequest, NextResponse } from 'next/server';
import { dbGetStoreById, dbSaveStore } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';
import { handleApiError } from '@/lib/apiErrors';

export const dynamic = 'force-dynamic';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const store = await dbGetStoreById(params.id);
    if (!store) {
      return NextResponse.json({ error: 'Store not found' }, { status: 404 });
    }
    return NextResponse.json({ store });
  } catch (error: any) {
    return handleApiError(error, 'api/stores/[id] GET', 'Failed to fetch store');
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    if (authUser.role !== 'admin' && authUser.storeId !== params.id) {
      return NextResponse.json({ error: 'Unauthorized to update this store' }, { status: 403 });
    }

    const store = await dbGetStoreById(params.id);
    if (!store) {
      return NextResponse.json({ error: 'Store not found' }, { status: 404 });
    }

    const body = await req.json();
    const updatedStore = {
      ...store,
      ...body,
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveStore(updatedStore);
    return NextResponse.json({ store: saved });
  } catch (error: any) {
    return handleApiError(error, 'api/stores/[id] PUT', 'Failed to update store');
  }
}
