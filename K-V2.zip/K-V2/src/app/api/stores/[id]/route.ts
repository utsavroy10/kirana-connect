import { NextRequest, NextResponse } from 'next/server';
import { dbGetStoreById, dbUpdateStoreFields } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';
import { handleApiError } from '@/lib/apiErrors';
import { parseJson, validate, findPresentKeys } from '@/lib/validation/parse';
import { omitUndefined } from '@/lib/validation/common';
import { storeUpdateKeysSchema, storeUpdateSchema, STORE_ADMIN_ONLY_FIELDS } from '@/lib/validation/store';

export const dynamic = 'force-dynamic';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const store = await dbGetStoreById(params.id);
    if (!store) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }
    return NextResponse.json({ store });
  } catch (error: any) {
    return handleApiError(error, 'api/stores/[id] GET', 'Failed to fetch store');
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    if (authUser.role !== 'admin' && !(authUser.role === 'merchant' && authUser.storeId === params.id)) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'Unauthorized to update this store' },
        { status: 403 }
      );
    }

    const json = await parseJson(req);
    if (json.errorResponse) {
      return json.errorResponse as NextResponse;
    }

    // 1) Unknown / immutable keys (id, _id, location, rating, createdAt, ...) -> 400 for everyone.
    const keys = validate(storeUpdateKeysSchema, json.value);
    if (keys.errorResponse) {
      return keys.errorResponse as NextResponse;
    }

    // 2) A merchant may not touch admin-only fields: 403 and nothing is saved.
    if (authUser.role !== 'admin') {
      const forbidden = findPresentKeys(json.value, STORE_ADMIN_ONLY_FIELDS);
      if (forbidden.length > 0) {
        return NextResponse.json(
          {
            error: 'FORBIDDEN_FIELD',
            message: `Only an admin can change: ${forbidden.join(', ')}`,
            fields: forbidden,
          },
          { status: 403 }
        );
      }
    }

    // 3) Value validation (strict booleans, commissionRate 0-20 with at most 2 decimals, ...).
    const parsed = validate(storeUpdateSchema, json.value);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }

    const existing = await dbGetStoreById(params.id);
    if (!existing) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }

    // $set only the validated fields; never a whole-document save.
    const fields: Record<string, any> = { ...omitUndefined(parsed.data), updatedAt: new Date().toISOString() };
    const saved = await dbUpdateStoreFields(params.id, fields);
    if (!saved) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }
    return NextResponse.json({ store: saved });
  } catch (error: any) {
    return handleApiError(error, 'api/stores/[id] PUT', 'Failed to update store');
  }
}
