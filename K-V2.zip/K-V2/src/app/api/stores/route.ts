import { NextRequest, NextResponse } from 'next/server';
import { dbGetStores, dbSaveStore } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';
import { handleApiError } from '@/lib/apiErrors';
import { Store } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const city = searchParams.get('city') || undefined;
    const area = searchParams.get('area') || undefined;

    const stores = await dbGetStores({ city, area });
    return NextResponse.json({ stores });
  } catch (error: any) {
    return handleApiError(error, 'api/stores GET', 'Failed to fetch stores');
  }
}

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['admin', 'merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const body = await req.json();
    const newStore: Store = {
      ...body,
      id: body.id || `store_${Date.now()}`,
      merchantUid: authUser.uid,
      isVerified: authUser.role === 'admin' ? true : false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveStore(newStore);
    return NextResponse.json({ store: saved }, { status: 201 });
  } catch (error: any) {
    return handleApiError(error, 'api/stores POST', 'Failed to create store');
  }
}
