import { NextRequest, NextResponse } from 'next/server';
import { dbGetStores, dbSaveStore } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody, validate } from '@/lib/validation/parse';
import { storeCreateSchema, storeQuerySchema } from '@/lib/validation/store';
import { Store } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const query = validate(storeQuerySchema, {
      city: searchParams.get('city') ?? undefined,
      area: searchParams.get('area') ?? undefined,
    });
    if (query.errorResponse) {
      return query.errorResponse as NextResponse;
    }
    const city = query.data.city || undefined;
    const area = query.data.area || undefined;

    const stores = await dbGetStores({ city, area });
    return NextResponse.json({ stores });
  } catch (error: any) {
    return handleApiError(error, 'api/stores GET', 'Failed to fetch stores');
  }
}

export async function POST(req: NextRequest) {
  try {
    // Only admins create stores (a merchant could otherwise pick their own commission).
    const authResult = await requireAuth(req, ['admin']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const parsed = await parseBody(req, storeCreateSchema);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const input = parsed.data;

    // Explicit field list: the server decides id, verification, commission and timestamps.
    const now = new Date().toISOString();
    const newStore: Store = {
      id: `store_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`,
      name: input.name,
      ownerName: input.ownerName,
      phone: input.phone,
      tagline: input.tagline,
      ...(input.description !== undefined ? { description: input.description } : {}),
      location: input.location,
      categories: input.categories ?? [],
      ...(input.bannerImage !== undefined ? { bannerImage: input.bannerImage } : {}),
      merchantUid: input.merchantUid ?? authUser.uid,
      isOpen: true,
      openingTime: input.openingTime,
      closingTime: input.closingTime,
      isVerified: true,
      commissionRate: 3.5,
      createdAt: now,
      updatedAt: now,
    };

    const saved = await dbSaveStore(newStore);
    return NextResponse.json({ store: saved }, { status: 201 });
  } catch (error: any) {
    return handleApiError(error, 'api/stores POST', 'Failed to create store');
  }
}
