import { NextRequest, NextResponse } from 'next/server';
import { dbGetStores, dbSaveStore } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';
import { Store } from '@/types';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const city = searchParams.get('city') || undefined;
    const area = searchParams.get('area') || undefined;

    const stores = await dbGetStores({ city, area });
    return NextResponse.json({ stores });
  } catch (error: any) {
    console.error('[api/stores GET] Error:', error);
    return NextResponse.json({ error: 'Failed to fetch stores' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['admin', 'merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const body = await req.json();
    const newStore: Store = {
      ...body,
      id: body.id || `store_${Date.now()}`,
      merchantUid: authUser.uid,
      isVerified: authUser.role === 'admin' ? true : false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveStore(newStore);
    return NextResponse.json({ store: saved }, { status: 201 });
  } catch (error: any) {
    console.error('[api/stores POST] Error:', error);
    return NextResponse.json({ error: 'Failed to create store' }, { status: 500 });
  }
}
