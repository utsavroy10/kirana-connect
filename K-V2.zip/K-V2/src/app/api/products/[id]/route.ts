import { NextRequest, NextResponse } from 'next/server';
import { dbGetProductById, dbSaveProduct } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';
import { handleApiError } from '@/lib/apiErrors';
import { parseJson, validate, findPresentKeys } from '@/lib/validation/parse';
import { omitUndefined } from '@/lib/validation/common';
import { legacyProductUpdateSchema, PRODUCT_IMMUTABLE_FIELDS } from '@/lib/validation/product';
import { StoreProduct } from '@/types';

export const dynamic = 'force-dynamic';

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
    }

    if (authUser.role !== 'admin' && !(authUser.role === 'merchant' && authUser.storeId === product.storeId)) {
      return NextResponse.json({ error: 'FORBIDDEN', message: 'Unauthorized to update this product' }, { status: 403 });
    }

    const json = await parseJson(req);
    if (json.errorResponse) {
      return json.errorResponse as NextResponse;
    }

    const immutable = findPresentKeys(json.value, [...PRODUCT_IMMUTABLE_FIELDS, 'id']);
    if (immutable.length > 0) {
      return NextResponse.json(
        { error: 'IMMUTABLE_FIELD', message: `These fields cannot be changed: ${immutable.join(', ')}`, fields: immutable },
        { status: 400 }
      );
    }

    // Strict whitelist: unknown keys -> 400.
    const parsed = validate(legacyProductUpdateSchema, json.value);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const changes = omitUndefined(parsed.data);

    // mrp >= price is checked against the merged values.
    const mergedPrice = changes.price !== undefined ? changes.price : product.price;
    const mergedMrp = changes.mrp !== undefined ? changes.mrp : product.mrp ?? mergedPrice;
    if (mergedMrp < mergedPrice) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'mrp (in rupees) must be greater than or equal to the selling price' },
        { status: 400 }
      );
    }

    const updated: StoreProduct = {
      ...product,
      ...changes,
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveProduct(updated);
    return NextResponse.json({ product: saved });
  } catch (error: any) {
    return handleApiError(error, 'api/products/[id] PUT', 'Failed to update product');
  }
}
