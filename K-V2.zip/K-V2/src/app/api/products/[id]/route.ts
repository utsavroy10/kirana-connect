import { NextRequest, NextResponse } from 'next/server';
import { dbGetProductById, dbSaveProduct } from '@/lib/db-adapter';
import { requireAuth } from '@/lib/authMiddleware';

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 });
    }

    if (authUser.role !== 'admin' && authUser.storeId !== product.storeId) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json();
    const updated = {
      ...product,
      ...body,
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveProduct(updated);
    return NextResponse.json({ product: saved });
  } catch (error: any) {
    console.error('[api/products/[id] PUT] Error:', error);
    return NextResponse.json({ error: 'Failed to update product' }, { status: 500 });
  }
}
