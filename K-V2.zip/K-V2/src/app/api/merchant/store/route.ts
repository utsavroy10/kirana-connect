import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetStoreById, dbSaveStore } from '@/lib/db-adapter';
import { Store } from '@/types';

function parseTimeToMinutes(timeStr: string): number | null {
  if (!timeStr || typeof timeStr !== 'string') return null;
  const t = timeStr.trim().toUpperCase();

  // 12-hour format: "08:00 AM", "9:30 PM"
  const match12 = t.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/);
  if (match12) {
    let hours = parseInt(match12[1], 10);
    const minutes = parseInt(match12[2], 10);
    const meridian = match12[3];
    if (hours < 1 || hours > 12 || minutes < 0 || minutes > 59) return null;
    if (meridian === 'AM' && hours === 12) hours = 0;
    if (meridian === 'PM' && hours !== 12) hours += 12;
    return hours * 60 + minutes;
  }

  // 24-hour format: "08:00", "21:30"
  const match24 = t.match(/^(\d{1,2}):(\d{2})$/);
  if (match24) {
    const hours = parseInt(match24[1], 10);
    const minutes = parseInt(match24[2], 10);
    if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) return null;
    return hours * 60 + minutes;
  }

  return null;
}

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    const store = await dbGetStoreById(storeId);
    if (!store) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }

    return NextResponse.json({ store });
  } catch (error: any) {
    console.error('[api/merchant/store GET] Error:', error);
    return NextResponse.json({ error: 'INTERNAL_ERROR', message: 'Failed to fetch store' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    const store = await dbGetStoreById(storeId);
    if (!store) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }

    let body: any;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: 'INVALID_JSON', message: 'Invalid JSON body' }, { status: 400 });
    }

    const { name, description, address, phone, openingTime, closingTime, isOpen } = body;

    if (name !== undefined) {
      if (typeof name !== 'string' || !name.trim() || name.trim().length > 100) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Store name must be a non-empty string under 100 characters' },
          { status: 400 }
        );
      }
    }

    if (description !== undefined) {
      if (typeof description !== 'string' || description.length > 500) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Description must be at most 500 characters' },
          { status: 400 }
        );
      }
    }

    if (address !== undefined) {
      if (typeof address !== 'string' || !address.trim() || address.length > 200) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Address must be a non-empty string under 200 characters' },
          { status: 400 }
        );
      }
    }

    let formattedPhone = store.phone;
    if (phone !== undefined) {
      if (typeof phone !== 'string') {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Phone number must be a valid 10-digit Indian mobile number' },
          { status: 400 }
        );
      }
      const cleanPhone = phone.replace(/^\+91/, '').trim();
      if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Phone number must be a valid 10-digit Indian mobile number starting with 6-9' },
          { status: 400 }
        );
      }
      formattedPhone = `+91${cleanPhone}`;
    }

    const effectiveOpen = openingTime !== undefined ? openingTime : store.openingTime;
    const effectiveClose = closingTime !== undefined ? closingTime : store.closingTime;

    if (openingTime !== undefined || closingTime !== undefined) {
      const openMinutes = parseTimeToMinutes(effectiveOpen);
      const closeMinutes = parseTimeToMinutes(effectiveClose);

      if (openMinutes === null) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Opening time must be a valid time format (HH:MM or HH:MM AM/PM)' },
          { status: 400 }
        );
      }

      if (closeMinutes === null) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Closing time must be a valid time format (HH:MM or HH:MM AM/PM)' },
          { status: 400 }
        );
      }

      if (closeMinutes <= openMinutes) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Closing time must be after opening time' },
          { status: 400 }
        );
      }
    }

    if (isOpen !== undefined && typeof isOpen !== 'boolean') {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'isOpen must be a boolean' },
        { status: 400 }
      );
    }

    const updatedStore: Store = {
      ...store,
      name: name !== undefined ? name.trim() : store.name,
      tagline: description !== undefined ? description.trim() : store.tagline,
      description: description !== undefined ? description.trim() : store.description,
      location: {
        ...store.location,
        address: address !== undefined ? address.trim() : store.location.address,
      },
      phone: formattedPhone,
      openingTime: effectiveOpen.trim(),
      closingTime: effectiveClose.trim(),
      isOpen: isOpen !== undefined ? isOpen : store.isOpen,
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveStore(updatedStore);
    return NextResponse.json({ store: saved });
  } catch (error: any) {
    console.error('[api/merchant/store PATCH] Error:', error);
    return NextResponse.json({ error: 'INTERNAL_ERROR', message: 'Failed to update store' }, { status: 500 });
  }
}
