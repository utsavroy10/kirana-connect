import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetStoreById, dbUpdateStoreFields } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody } from '@/lib/validation/parse';
import { merchantStorePatchSchema } from '@/lib/validation/store';

export const dynamic = 'force-dynamic';

function parseTimeToMinutes(timeStr: string): number | null {
  if (!timeStr || typeof timeStr !== 'string') return null;
  const t = timeStr.trim().toUpperCase();

  // 12-hour format: "08:00 AM", "9:30 PM"
  const match12 = t.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/);
  if (match12) {
    let hours = parseInt(match12[1], 10);
    const minutes = parseInt(match12[2], 10);
    const meridian = match12[3];
    if (hours < 1 || hours > 12 || minutes < 0 || minutes > 59) return null;
    if (meridian === 'AM' && hours === 12) hours = 0;
    if (meridian === 'PM' && hours !== 12) hours += 12;
    return hours * 60 + minutes;
  }

  // 24-hour format: "08:00", "21:30"
  const match24 = t.match(/^(\d{1,2}):(\d{2})$/);
  if (match24) {
    const hours = parseInt(match24[1], 10);
    const minutes = parseInt(match24[2], 10);
    if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) return null;
    return hours * 60 + minutes;
  }

  return null;
}

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    const store = await dbGetStoreById(storeId);
    if (!store) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }

    return NextResponse.json({ store });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/store GET', 'Failed to fetch store');
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    const store = await dbGetStoreById(storeId);
    if (!store) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }

    // Unknown keys are stripped. Phone/time rules below are route-specific (24h times and +91 normalisation stay accepted).
    const parsed = await parseBody(req, merchantStorePatchSchema);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const { name, tagline, description, address, phone, openingTime, closingTime, isOpen } = parsed.data;

    let formattedPhone = store.phone;
    if (phone !== undefined) {
      const cleanPhone = phone.replace(/^\+91/, '').trim();
      if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Phone number must be a valid 10-digit Indian mobile number starting with 6-9' },
          { status: 400 }
        );
      }
      formattedPhone = `+91${cleanPhone}`;
    }

    const effectiveOpen = openingTime !== undefined ? openingTime : store.openingTime;
    const effectiveClose = closingTime !== undefined ? closingTime : store.closingTime;

    if (openingTime !== undefined || closingTime !== undefined) {
      const openMinutes = parseTimeToMinutes(effectiveOpen);
      const closeMinutes = parseTimeToMinutes(effectiveClose);

      if (openMinutes === null) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Opening time must be a valid time format (HH:MM or HH:MM AM/PM)' },
          { status: 400 }
        );
      }

      if (closeMinutes === null) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Closing time must be a valid time format (HH:MM or HH:MM AM/PM)' },
          { status: 400 }
        );
      }

      if (closeMinutes <= openMinutes) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Closing time must be after opening time' },
          { status: 400 }
        );
      }
    }

    // $set only the validated fields so concurrent admin changes
    // (isVerified, commissionRate, ...) are never overwritten with a stale copy.
    const fields: Record<string, any> = { updatedAt: new Date().toISOString() };
    if (name !== undefined) fields.name = name.trim();
    if (tagline !== undefined) fields.tagline = tagline.trim();
    if (description !== undefined) fields.description = description.trim();
    if (address !== undefined) fields['location.address'] = address.trim();
    if (phone !== undefined) fields.phone = formattedPhone;
    if (openingTime !== undefined) fields.openingTime = String(effectiveOpen).trim();
    if (closingTime !== undefined) fields.closingTime = String(effectiveClose).trim();
    if (isOpen !== undefined) fields.isOpen = isOpen;

    const saved = await dbUpdateStoreFields(storeId, fields);
    if (!saved) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Store not found' }, { status: 404 });
    }
    return NextResponse.json({ store: saved });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/store PATCH', 'Failed to update store');
  }
}
