import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetProductsByStore, dbSaveProduct } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody } from '@/lib/validation/parse';
import { merchantProductCreateSchema } from '@/lib/validation/product';
import { StoreProduct } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    const allProducts = await dbGetProductsByStore(storeId);
    // Filter active products by default (isActive !== false)
    const products = allProducts.filter((p) => p.isActive !== false);

    return NextResponse.json({ products });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/products GET', 'Failed to fetch products');
  }
}

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    // Unknown keys (storeId, isActive, id, ...) are stripped; storeId always comes from the session.
    const parsed = await parseBody(req, merchantProductCreateSchema);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const { name, hindiName, description, category, price, mrp, unit, inStock } = parsed.data;

    // Money is stored in rupees. MRP defaults to the price and may not be below it.
    const validMrp = mrp !== undefined ? mrp : price;
    if (validMrp < price) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'MRP (in rupees) must be greater than or equal to the selling price' },
        { status: 400 }
      );
    }

    const now = new Date().toISOString();
    const productId = `prod_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;

    const newProduct: StoreProduct = {
      id: productId,
      storeId,
      name,
      hindiName: hindiName && hindiName.trim() ? hindiName.trim() : undefined,
      description: description && description.trim() ? description.trim() : undefined,
      category,
      price,
      mrp: validMrp,
      unit,
      inStock: inStock !== undefined ? inStock : true,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    };

    const saved = await dbSaveProduct(newProduct);
    return NextResponse.json({ product: saved }, { status: 201 });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/products POST', 'Failed to create product');
  }
}
