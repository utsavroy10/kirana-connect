import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetProductsByStore, dbSaveProduct } from '@/lib/db-adapter';
import { StoreProduct } from '@/types';

export const ALLOWED_PRODUCT_CATEGORIES = [
  'Atta & Flour',
  'Rice & Pulses',
  'Cooking Oils & Ghee',
  'Spices & Masalas',
  'Dairy & Eggs',
  'Snacks & Packaged Food',
  'Beverages',
  'Personal Care',
  'Cleaning & Household',
  'General Grocery',
] as const;

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    const allProducts = await dbGetProductsByStore(storeId);
    // Filter active products by default (isActive !== false)
    const products = allProducts.filter((p) => p.isActive !== false);

    return NextResponse.json({ products });
  } catch (error: any) {
    console.error('[api/merchant/products GET] Error:', error);
    return NextResponse.json(
      { error: 'INTERNAL_ERROR', message: 'Failed to fetch products' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    let body: any;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        { error: 'INVALID_JSON', message: 'Invalid JSON body' },
        { status: 400 }
      );
    }

    const { name, hindiName, description, category, price, mrp, unit, inStock } = body;

    if (!name || typeof name !== 'string' || !name.trim() || name.trim().length > 150) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Product name is required (max 150 characters)' },
        { status: 400 }
      );
    }

    if (description !== undefined && (typeof description !== 'string' || description.length > 500)) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Description must be at most 500 characters' },
        { status: 400 }
      );
    }

    if (!category || typeof category !== 'string' || !ALLOWED_PRODUCT_CATEGORIES.includes(category as any)) {
      return NextResponse.json(
        {
          error: 'VALIDATION_ERROR',
          message: `Category must be one of: ${ALLOWED_PRODUCT_CATEGORIES.join(', ')}`,
        },
        { status: 400 }
      );
    }

    // Price must be an integer in paise between 100 (₹1) and 10000000 (₹1L)
    if (
      price === undefined ||
      typeof price !== 'number' ||
      !Number.isInteger(price) ||
      price < 100 ||
      price > 10000000
    ) {
      return NextResponse.json(
        {
          error: 'VALIDATION_ERROR',
          message: 'Price must be an integer in paise between 100 (₹1) and 10,000,000 (₹100,000)',
        },
        { status: 400 }
      );
    }

    let validMrp = price;
    if (mrp !== undefined) {
      if (typeof mrp !== 'number' || !Number.isInteger(mrp) || mrp < price) {
        return NextResponse.json(
          {
            error: 'VALIDATION_ERROR',
            message: 'MRP must be an integer in paise greater than or equal to the selling price',
          },
          { status: 400 }
        );
      }
      validMrp = mrp;
    }

    if (!unit || typeof unit !== 'string' || !unit.trim() || unit.trim().length > 50) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Unit is required (e.g. 500g, 1 kg, 1L, piece)' },
        { status: 400 }
      );
    }

    const now = new Date().toISOString();
    const productId = `prod_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;

    const newProduct: StoreProduct = {
      id: productId,
      storeId,
      name: name.trim(),
      hindiName: typeof hindiName === 'string' && hindiName.trim() ? hindiName.trim() : undefined,
      description: typeof description === 'string' && description.trim() ? description.trim() : undefined,
      category: category.trim(),
      price,
      mrp: validMrp,
      unit: unit.trim(),
      inStock: inStock !== undefined ? Boolean(inStock) : true,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    };

    const saved = await dbSaveProduct(newProduct);
    return NextResponse.json({ product: saved }, { status: 201 });
  } catch (error: any) {
    console.error('[api/merchant/products POST] Error:', error);
    return NextResponse.json(
      { error: 'INTERNAL_ERROR', message: 'Failed to create product' },
      { status: 500 }
    );
  }
}
