import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetProductsByStore, dbSaveProduct } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { ALLOWED_PRODUCT_CATEGORIES } from '@/lib/productCategories';
import { isValidRupeeAmount, RUPEE_AMOUNT_RULE } from '@/lib/money';
import { StoreProduct } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    const allProducts = await dbGetProductsByStore(storeId);
    // Filter active products by default (isActive !== false)
    const products = allProducts.filter((p) => p.isActive !== false);

    return NextResponse.json({ products });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/products GET', 'Failed to fetch products');
  }
}

export async function POST(req: NextRequest) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const storeId = authUser.storeId;
    if (!storeId) {
      return NextResponse.json(
        { error: 'FORBIDDEN', message: 'No store associated with this merchant account' },
        { status: 403 }
      );
    }

    let body: any;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        { error: 'INVALID_JSON', message: 'Invalid JSON body' },
        { status: 400 }
      );
    }

    const { name, hindiName, description, category, price, mrp, unit, inStock } = body;

    if (hindiName !== undefined && (typeof hindiName !== 'string' || hindiName.length > 150)) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Hindi name must be a string of at most 150 characters' },
        { status: 400 }
      );
    }

    if (inStock !== undefined && typeof inStock !== 'boolean') {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'inStock must be a boolean value' },
        { status: 400 }
      );
    }

    if (!name || typeof name !== 'string' || !name.trim() || name.trim().length > 150) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Product name is required (max 150 characters)' },
        { status: 400 }
      );
    }

    if (description !== undefined && (typeof description !== 'string' || description.length > 500)) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Description must be at most 500 characters' },
        { status: 400 }
      );
    }

    if (!category || typeof category !== 'string' || !ALLOWED_PRODUCT_CATEGORIES.includes(category as any)) {
      return NextResponse.json(
        {
          error: 'VALIDATION_ERROR',
          message: `Category must be one of: ${ALLOWED_PRODUCT_CATEGORIES.join(', ')}`,
        },
        { status: 400 }
      );
    }

    // Money is stored in rupees: > 0, <= 100000, at most 2 decimals
    if (!isValidRupeeAmount(price)) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: `Price (in rupees) must be ${RUPEE_AMOUNT_RULE}` },
        { status: 400 }
      );
    }

    let validMrp = price;
    if (mrp !== undefined) {
      if (!isValidRupeeAmount(mrp) || mrp < price) {
        return NextResponse.json(
          {
            error: 'VALIDATION_ERROR',
            message: `MRP (in rupees) must be ${RUPEE_AMOUNT_RULE} and greater than or equal to the selling price`,
          },
          { status: 400 }
        );
      }
      validMrp = mrp;
    }

    if (!unit || typeof unit !== 'string' || !unit.trim() || unit.trim().length > 50) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Unit is required (e.g. 500g, 1 kg, 1L, piece)' },
        { status: 400 }
      );
    }

    const now = new Date().toISOString();
    const productId = `prod_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;

    const newProduct: StoreProduct = {
      id: productId,
      storeId,
      name: name.trim(),
      hindiName: typeof hindiName === 'string' && hindiName.trim() ? hindiName.trim() : undefined,
      description: typeof description === 'string' && description.trim() ? description.trim() : undefined,
      category: category.trim(),
      price,
      mrp: validMrp,
      unit: unit.trim(),
      inStock: inStock !== undefined ? inStock : true,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    };

    const saved = await dbSaveProduct(newProduct);
    return NextResponse.json({ product: saved }, { status: 201 });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/products POST', 'Failed to create product');
  }
}
