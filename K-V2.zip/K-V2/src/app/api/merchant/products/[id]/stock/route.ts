import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetProductById, dbSaveProduct } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody } from '@/lib/validation/parse';
import { merchantStockSchema } from '@/lib/validation/product';
import { StoreProduct } from '@/types';

export const dynamic = 'force-dynamic';

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
    }

    if (product.storeId !== authUser.storeId) {
      return NextResponse.json({ error: 'FORBIDDEN', message: 'Unauthorized access to product' }, { status: 403 });
    }

    const parsed = await parseBody(req, merchantStockSchema);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const { inStock } = parsed.data;

    const updatedProduct: StoreProduct = {
      ...product,
      inStock,
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveProduct(updatedProduct);
    return NextResponse.json({ product: saved });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/products/[id]/stock PATCH', 'Failed to update product stock');
  }
}
