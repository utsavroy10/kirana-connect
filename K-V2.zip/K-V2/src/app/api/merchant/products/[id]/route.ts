import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetProductById, dbSaveProduct } from '@/lib/db-adapter';
import { handleApiError } from '@/lib/apiErrors';
import { parseBody } from '@/lib/validation/parse';
import { merchantProductPatchSchema } from '@/lib/validation/product';
import { StoreProduct } from '@/types';

export const dynamic = 'force-dynamic';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
    }

    if (product.storeId !== authUser.storeId) {
      return NextResponse.json({ error: 'FORBIDDEN', message: 'Unauthorized access to product' }, { status: 403 });
    }

    return NextResponse.json({ product });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/products/[id] GET', 'Failed to fetch product');
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
    }

    if (product.storeId !== authUser.storeId) {
      return NextResponse.json({ error: 'FORBIDDEN', message: 'Unauthorized access to product' }, { status: 403 });
    }

    // Unknown keys (storeId, isActive, ...) are stripped.
    const parsed = await parseBody(req, merchantProductPatchSchema);
    if (parsed.errorResponse) {
      return parsed.errorResponse as NextResponse;
    }
    const { name, hindiName, description, category, price, mrp, unit, inStock } = parsed.data;

    // mrp >= price is checked against the merged values
    const updatedPrice = price !== undefined ? price : product.price;
    const updatedMrp = mrp !== undefined ? mrp : product.mrp || updatedPrice;
    if (updatedMrp < updatedPrice) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'MRP (in rupees) must be greater than or equal to the selling price' },
        { status: 400 }
      );
    }

    const updatedProduct: StoreProduct = {
      ...product,
      name: name !== undefined ? name : product.name,
      hindiName: hindiName !== undefined ? (hindiName.trim() || undefined) : product.hindiName,
      description: description !== undefined ? (description.trim() || undefined) : product.description,
      category: category !== undefined ? category : product.category,
      price: updatedPrice,
      mrp: updatedMrp,
      unit: unit !== undefined ? unit : product.unit,
      inStock: inStock !== undefined ? inStock : product.inStock,
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveProduct(updatedProduct);
    return NextResponse.json({ product: saved });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/products/[id] PATCH', 'Failed to update product');
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
    }

    if (product.storeId !== authUser.storeId) {
      return NextResponse.json({ error: 'FORBIDDEN', message: 'Unauthorized access to product' }, { status: 403 });
    }

    // Soft delete product (isActive = false)
    const updatedProduct: StoreProduct = {
      ...product,
      isActive: false,
      updatedAt: new Date().toISOString(),
    };

    await dbSaveProduct(updatedProduct);
    return NextResponse.json({ success: true, message: 'Product deactivated successfully' });
  } catch (error: any) {
    return handleApiError(error, 'api/merchant/products/[id] DELETE', 'Failed to delete product');
  }
}
