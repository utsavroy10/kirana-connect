import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/authMiddleware';
import { dbGetProductById, dbSaveProduct } from '@/lib/db-adapter';
import { ALLOWED_PRODUCT_CATEGORIES } from '../route';
import { StoreProduct } from '@/types';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
    }

    if (product.storeId !== authUser.storeId) {
      return NextResponse.json({ error: 'FORBIDDEN', message: 'Unauthorized access to product' }, { status: 403 });
    }

    return NextResponse.json({ product });
  } catch (error: any) {
    console.error('[api/merchant/products/[id] GET] Error:', error);
    return NextResponse.json({ error: 'INTERNAL_ERROR', message: 'Failed to fetch product' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
    }

    if (product.storeId !== authUser.storeId) {
      return NextResponse.json({ error: 'FORBIDDEN', message: 'Unauthorized access to product' }, { status: 403 });
    }

    let body: any;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: 'INVALID_JSON', message: 'Invalid JSON body' }, { status: 400 });
    }

    const { name, hindiName, description, category, price, mrp, unit, inStock } = body;

    if (name !== undefined) {
      if (typeof name !== 'string' || !name.trim() || name.trim().length > 150) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Product name must be a non-empty string under 150 characters' },
          { status: 400 }
        );
      }
    }

    if (description !== undefined && (typeof description !== 'string' || description.length > 500)) {
      return NextResponse.json(
        { error: 'VALIDATION_ERROR', message: 'Description must be at most 500 characters' },
        { status: 400 }
      );
    }

    if (category !== undefined) {
      if (typeof category !== 'string' || !ALLOWED_PRODUCT_CATEGORIES.includes(category as any)) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: `Category must be one of: ${ALLOWED_PRODUCT_CATEGORIES.join(', ')}` },
          { status: 400 }
        );
      }
    }

    let updatedPrice = product.price;
    if (price !== undefined) {
      if (typeof price !== 'number' || !Number.isInteger(price) || price < 100 || price > 10000000) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Price must be an integer in paise between 100 (₹1) and 10,000,000 (₹100,000)' },
          { status: 400 }
        );
      }
      updatedPrice = price;
    }

    let updatedMrp = product.mrp || updatedPrice;
    if (mrp !== undefined) {
      if (typeof mrp !== 'number' || !Number.isInteger(mrp) || mrp < updatedPrice) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'MRP must be an integer in paise greater than or equal to the selling price' },
          { status: 400 }
        );
      }
      updatedMrp = mrp;
    }

    if (unit !== undefined) {
      if (typeof unit !== 'string' || !unit.trim() || unit.trim().length > 50) {
        return NextResponse.json(
          { error: 'VALIDATION_ERROR', message: 'Unit must be a valid non-empty string' },
          { status: 400 }
        );
      }
    }

    const updatedProduct: StoreProduct = {
      ...product,
      name: name !== undefined ? name.trim() : product.name,
      hindiName: hindiName !== undefined ? (hindiName.trim() || undefined) : product.hindiName,
      description: description !== undefined ? (description.trim() || undefined) : product.description,
      category: category !== undefined ? category.trim() : product.category,
      price: updatedPrice,
      mrp: updatedMrp,
      unit: unit !== undefined ? unit.trim() : product.unit,
      inStock: inStock !== undefined ? Boolean(inStock) : product.inStock,
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveProduct(updatedProduct);
    return NextResponse.json({ product: saved });
  } catch (error: any) {
    console.error('[api/merchant/products/[id] PATCH] Error:', error);
    return NextResponse.json({ error: 'INTERNAL_ERROR', message: 'Failed to update product' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authResult = await requireAuth(req, ['merchant']);
    if (authResult.errorResponse) {
      return authResult.errorResponse;
    }

    const authUser = authResult.user;
    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
    }

    if (product.storeId !== authUser.storeId) {
      return NextResponse.json({ error: 'FORBIDDEN', message: 'Unauthorized access to product' }, { status: 403 });
    }

    // Soft delete product (isActive = false)
    const updatedProduct: StoreProduct = {
      ...product,
      isActive: false,
      updatedAt: new Date().toISOString(),
    };

    await dbSaveProduct(updatedProduct);
    return NextResponse.json({ success: true, message: 'Product deactivated successfully' });
  } catch (error: any) {
    console.error('[api/merchant/products/[id] DELETE] Error:', error);
    return NextResponse.json({ error: 'INTERNAL_ERROR', message: 'Failed to delete product' }, { status: 500 });
  }
}
