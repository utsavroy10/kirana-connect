'use client';

import React, { useState, useEffect } from 'react';
import { Search, MapPin, Store as StoreIcon, Sparkles, Filter, RefreshCw } from 'lucide-react';
import { Store } from '@/types';
import { StoreCard } from '@/components/StoreCard';

export default function HomePage() {
  const [stores, setStores] = useState<Store[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCity, setSelectedCity] = useState<string>('All');

  const fetchStores = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/stores');
      const data = await res.json();
      if (data.stores) {
        setStores(data.stores);
      }
    } catch (err) {
      console.error('Failed to load stores', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStores();
  }, []);

  const cities = ['All', 'Indore', 'Varanasi', 'Jaipur'];

  const filteredStores = stores.filter(store => {
    const matchesCity = selectedCity === 'All' || store.location.city.toLowerCase() === selectedCity.toLowerCase();
    const matchesSearch =
      store.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      store.location.area.toLowerCase().includes(searchQuery.toLowerCase()) ||
      store.categories.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCity && matchesSearch;
  });

  return (
    <div className="pb-16">
      {/* Hero Banner */}
      <section className="bg-gradient-to-b from-kirana-50/80 to-white border-b border-kirana-100/60 py-8 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-1.5 bg-white border border-kirana-200 text-kirana-800 text-xs font-bold px-3 py-1 rounded-full shadow-sm mb-3">
              <Sparkles className="w-3.5 h-3.5 text-kirana-600" />
              Pickup First • Zero Delivery Charges • 100% Trust
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Order Groceries Online, <br />
              <span className="text-kirana-600">Pick Up Packed & Ready</span> From Your Kirana.
            </h1>
            <p className="mt-2 text-sm text-slate-600 leading-relaxed">
              Skip queues and save time. Browse your trusted neighborhood store’s daily essentials, order in advance, and collect at your chosen time slot. Pay via Cash or UPI at pickup.
            </p>
          </div>

          {/* Search & Location Bar */}
          <div className="mt-6 bg-white p-2.5 sm:p-3 rounded-2xl shadow-md border border-slate-200/80 flex flex-col sm:flex-row gap-2.5 max-w-3xl">
            {/* City Selector */}
            <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-xl sm:w-1/3 border border-slate-200/60">
              <MapPin className="w-4 h-4 text-kirana-600 shrink-0" />
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                className="w-full bg-transparent text-xs font-semibold text-slate-800 focus:outline-none cursor-pointer"
              >
                {cities.map((city) => (
                  <option key={city} value={city}>
                    {city === 'All' ? 'All Cities' : `📍 ${city}`}
                  </option>
                ))}
              </select>
            </div>

            {/* Keyword Search */}
            <div className="flex-1 flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-xl border border-slate-200/60">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                placeholder="Search store name, area, or product (e.g. Atta, Oil)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent text-xs text-slate-800 placeholder-slate-400 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stores List */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              Partner Kirana Stores Near You
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Showing {filteredStores.length} trusted neighborhood grocery stores
            </p>
          </div>

          <button
            onClick={fetchStores}
            className="p-2 text-slate-500 hover:text-kirana-600 hover:bg-slate-100 rounded-lg transition-colors text-xs flex items-center gap-1"
            title="Refresh stores"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Refresh</span>
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div key={n} className="bg-white rounded-2xl h-80 border border-slate-200 animate-pulse" />
            ))}
          </div>
        ) : filteredStores.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-md mx-auto">
            <StoreIcon className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="font-bold text-slate-800 text-base">No stores found</h3>
            <p className="text-xs text-slate-500 mt-1">
              Try changing your city filter or search query.
            </p>
            <button
              onClick={() => { setSelectedCity('All'); setSearchQuery(''); }}
              className="mt-4 text-xs font-semibold text-kirana-600 hover:underline"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredStores.map((store) => (
              <StoreCard key={store.id} store={store} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
