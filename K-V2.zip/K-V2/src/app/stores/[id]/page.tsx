'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import {
  MapPin,
  Clock,
  Phone,
  CheckCircle2,
  Star,
  ShoppingBag,
  ArrowLeft,
  Search,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { Store, StoreProduct } from '@/types';
import { ProductCard } from '@/components/ProductCard';
import { useCart } from '@/context/CartContext';

export default function StoreDetailPage() {
  const params = useParams();
  const storeId = params.id as string;
  const { cart, itemCount, itemTotal } = useCart();

  const [store, setStore] = useState<Store | null>(null);
  const [products, setProducts] = useState<StoreProduct[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    const fetchStoreAndProducts = async () => {
      try {
        setLoading(true);
        const [storeRes, prodRes] = await Promise.all([
          fetch(`/api/stores/${storeId}`),
          fetch(`/api/stores/${storeId}/products`),
        ]);

        if (storeRes.ok) {
          const storeData = await storeRes.json();
          setStore(storeData.store);
        }

        if (prodRes.ok) {
          const prodData = await prodRes.json();
          setProducts(prodData.products || []);
        }
      } catch (err) {
        console.error('Failed to fetch store details', err);
      } finally {
        setLoading(false);
      }
    };

    if (storeId) {
      fetchStoreAndProducts();
    }
  }, [storeId]);

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8 animate-pulse space-y-6">
        <div className="h-64 bg-slate-200 rounded-3xl" />
        <div className="h-10 bg-slate-200 rounded-xl w-1/3" />
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(n => (
            <div key={n} className="h-60 bg-slate-200 rounded-2xl" />
          ))}
        </div>
      </div>
    );
  }

  if (!store) {
    return (
      <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-2xl border border-slate-200 text-center">
        <h2 className="text-lg font-bold text-slate-800">Store not found</h2>
        <p className="text-xs text-slate-500 mt-1">This kirana store may have moved or is inactive.</p>
        <Link href="/" className="inline-block mt-4 text-xs font-semibold text-kirana-600 hover:underline">
          Return to All Stores
        </Link>
      </div>
    );
  }

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))];

  const filteredProducts = products.filter(p => {
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.hindiName && p.hindiName.includes(searchQuery)) ||
      (p.brand && p.brand.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const isCurrentStoreInCart = cart && cart.storeId === store.id && itemCount > 0;

  return (
    <div className="pb-28">
      {/* Top back navigation */}
      <div className="bg-white border-b border-slate-200 py-3 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Stores
          </Link>

          <span className="text-xs text-kirana-700 font-bold bg-kirana-50 px-2.5 py-1 rounded-full border border-kirana-200">
            Pickup-Only Service
          </span>
        </div>
      </div>

      {/* Store Header Info */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 mt-6">
        <div className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-6 shadow-sm flex flex-col md:flex-row gap-6 items-start md:items-center justify-between">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                {store.name}
              </h1>
              {store.isVerified && (
                <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-700 text-xs font-bold px-2 py-0.5 rounded-full border border-blue-200">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Verified Merchant
                </span>
              )}
            </div>

            <p className="text-xs sm:text-sm text-slate-600">
              {store.tagline || 'Direct store pricing • Genuine products • Quick packing'}
            </p>

            <div className="flex flex-wrap items-center gap-y-2 gap-x-4 pt-1 text-xs text-slate-500">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {store.location.address}, {store.location.area}, {store.location.city}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                Pickup Timings: {store.openingTime} - {store.closingTime}
              </span>
              <span className="flex items-center gap-1">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                {store.phone}
              </span>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-4 text-center min-w-[140px] shrink-0 self-stretch sm:self-auto flex sm:flex-col items-center justify-between sm:justify-center gap-2">
            <div className="flex items-center gap-1.5 justify-center">
              <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
              <span className="text-xl font-extrabold text-slate-900">{store.rating || 4.8}</span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium">
              {store.totalOrdersCompleted || 100}+ pickups completed
            </span>
          </div>
        </div>

        {/* Search & Categories Bar */}
        <div className="mt-8 space-y-4">
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
            {/* Search within store */}
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search within this store..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-kirana-500"
              />
            </div>

            <p className="text-xs text-slate-500 self-end sm:self-auto">
              Showing {filteredProducts.length} items
            </p>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-kirana-600 text-white shadow-md shadow-kirana-600/20'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div className="mt-6">
          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
              <p className="text-sm font-semibold text-slate-700">No items match your query</p>
              <button
                onClick={() => { setSelectedCategory('All'); setSearchQuery(''); }}
                className="mt-2 text-xs text-kirana-600 font-bold hover:underline"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Floating Sticky Cart Bar (Shown when items exist for this store) */}
      {isCurrentStoreInCart && (
        <div className="fixed bottom-16 sm:bottom-6 left-4 right-4 sm:left-auto sm:right-6 sm:w-96 z-40 animate-slide-up">
          <div className="bg-slate-900 text-white p-4 rounded-2xl shadow-2xl flex items-center justify-between border border-slate-700">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-300">
                  {itemCount} {itemCount === 1 ? 'item' : 'items'}
                </span>
                <span className="text-slate-500">•</span>
                <span className="text-base font-extrabold text-kirana-400">
                  ₹{itemTotal}
                </span>
              </div>
              <p className="text-[10px] text-slate-400">Pay via Cash / UPI at pickup</p>
            </div>

            <Link
              href="/cart"
              className="bg-kirana-600 hover:bg-kirana-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md flex items-center gap-1.5 transition-colors"
            >
              View Cart & Slot
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
