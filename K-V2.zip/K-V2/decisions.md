# Architecture & Product Decision Records (ADRs) - Kirana Connect

This document logs all key architectural, technical, product, and data-layer decisions made across the lifecycle of the **Kirana Connect** platform.

---

## Index of Decisions

- [ADR-001: Pickup-First Hyperlocal Monolith on Next.js 14 & Vercel](#adr-001-pickup-first-hyperlocal-monolith-on-nextjs-14--vercel)
- [ADR-002: Dual-Layer Database Adapter (MongoDB Atlas + In-Memory Fallback)](#adr-002-dual-layer-database-adapter-mongodb-atlas--in-memory-fallback)
- [ADR-003: Hybrid Auth Model (Firebase Phone Auth + Gated Demo Mode)](#adr-003-hybrid-auth-model-firebase-phone-auth--gated-demo-mode)
- [ADR-004: Strict Single-Store Cart Rule with Explicit Confirmation](#adr-004-strict-single-store-cart-rule-with-explicit-confirmation)
- [ADR-005: Server-Authoritative Pricing, Stock & Slot Validation](#adr-005-server-authoritative-pricing-stock--slot-validation)
- [ADR-006: Finite State Machine for Order Lifecycle with Atomic Transitions](#adr-006-finite-state-machine-for-order-lifecycle-with-atomic-transitions)
- [ADR-007: Zero-Infrastructure Polling Strategy for Real-Time Updates](#adr-007-zero-infrastructure-polling-strategy-for-real-time-updates)
- [ADR-008: Role-Based Multi-Tenant Scoping and Security Invariants](#adr-008-role-based-multi-tenant-scoping-and-security-invariants)
- [ADR-009: Standardized API Error Envelope](#adr-009-standardized-api-error-envelope)
- [ADR-010: Rupee Storage for All Financials](#adr-010-rupee-storage-for-all-financials)
- [ADR-011: Time-Aware Pickup Slot Expiration & Scheduling Guard](#adr-011-time-aware-pickup-slot-expiration--scheduling-guard)

---

### ADR-001: Pickup-First Hyperlocal Monolith on Next.js 14 & Vercel
- **Status:** Accepted & Implemented
- **Context:** Building an advance ordering grocery platform for Tier-2/3 Indian cities where delivery fleets, warehousing, and microservice infrastructure (Kubernetes, Kafka, Redis) introduce unsustainable unit economics and operational overhead.
- **Decision:** Build a single-codebase modular monolith using Next.js 14 App Router (React Server Components, API Route Handlers, TypeScript, Tailwind CSS) deployable directly to serverless Vercel runtime.
- **Consequences:** Zero server maintenance, zero delivery fee overhead, rapid development cycles, and native TypeScript type sharing across frontend and backend.

---

### ADR-002: Dual-Layer Database Adapter (MongoDB Atlas + In-Memory Fallback)
- **Status:** Accepted & Implemented
- **Context:** Development environments need zero-friction startup without mandatory cloud database connectivity, while production requires MongoDB Atlas persistence.
- **Decision:** [`src/lib/db-adapter.ts`](src/lib/db-adapter.ts) is the only module that talks to MongoDB (it and `mongodb.ts`, `indexes.ts`, `firebaseAdmin.ts`, `authMiddleware.ts` import `server-only`). It exposes async repository functions for stores, products, users, carts (`carts` collection keyed by `uid`) and orders.
  - **Development:** if the MongoDB *connection* fails, the adapter logs a `console.warn` and serves that call from in-memory arrays.
  - **Production (`NODE_ENV === 'production'`):** a failed connection throws `DatabaseUnavailableError`.
  - **Any environment:** if a MongoDB operation fails after a connection exists, the adapter throws `DatabaseUnavailableError`; it never repeats the operation in memory, and a call never writes to both MongoDB and memory.
  - Routes convert `DatabaseUnavailableError` into HTTP 503 `{ error: 'SERVICE_UNAVAILABLE', message }` through `handleApiError` in [`src/lib/apiErrors.ts`](src/lib/apiErrors.ts). `requireAuth` does the same when the role lookup hits a database failure.
- **Consequences:** No silent data divergence in production. Not covered: in-memory state is per server instance and lost on restart. Legacy `PUT /api/stores/[id]` and `PUT /api/products/[id]` mass assignment and input validation are now guarded via Zod schemas (Phase 4).

---

### ADR-003: Hybrid Auth Model (Firebase Phone Auth + Gated Demo Mode)
- **Status:** Accepted & Implemented
- **Context:** Indian grocery customers and kirana merchants authenticate exclusively via mobile phone OTP. However, automated testing, stakeholder reviews, and sandbox trials require deterministic persona switching.
- **Decision:**
  - Client auth uses Firebase Phone OTP with Firebase Admin SDK token verification on backend API handlers.
  - Persona switching (`RoleSwitcher`) generates `DEMO_TOKEN_*` which is strictly gated server-side by `ALLOW_DEMO_AUTH === 'true'` AND `NODE_ENV !== 'production'`.
  - Removed all spoofable identity headers (`x-user-id`, `body.userId`).
- **Consequences:** Robust security against identity spoofing in production while preserving frictionless 1-click persona switching during testing.

---

### ADR-004: Strict Single-Store Cart Rule with Explicit Confirmation
- **Status:** Accepted & Implemented
- **Context:** Kirana Connect is a counter-collection platform. Customers physically visit a specific store to collect packed items. Mixing items from multiple stores in a single checkout is physically impossible.
- **Decision:** Enforce single-store carts at both UI and API levels ([`POST /api/cart`](src/app/api/cart/route.ts)). Adding an item from a different store returns HTTP 409 `STORE_MISMATCH` with a modal prompt asking the user to confirm clearing the previous store's cart.
- **Consequences:** Prevents counter-collection confusion, maintains clean store-merchant billing, and avoids split-order complications.

---

### ADR-005: Server-Authoritative Pricing, Stock & Slot Validation
- **Status:** Accepted & Implemented
- **Context:** Client applications can submit modified prices, out-of-stock items, or invalid pickup times.
- **Decision:** On [`POST /api/orders`](src/app/api/orders/route.ts):
  - Completely ignore client-supplied prices, totals, and commission amounts.
  - Merge duplicate item IDs and validate quantity bounds ($1 \le \text{qty} \le 50$).
  - Fetch official product documents from database, verify store ownership, and check active stock (`inStock === true`).
  - Validate store status (`isVerified && isOpen`) and slot validity against [`generatePickupSlots()`](src/lib/mock-data.ts:222).
- **Consequences:** Prevents client-side price manipulation, guarantees inventory accuracy, and enforces operational scheduling.

---

### ADR-006: Finite State Machine for Order Lifecycle with Atomic Transitions
- **Status:** Accepted & Implemented
- **Context:** Race conditions between merchant actions (accepting/packing) and customer actions (cancelling) can lead to invalid states or double transitions.
- **Decision:** Implement a deterministic state transition map in [`src/lib/orderStatus.ts`](src/lib/orderStatus.ts) and atomic updates via `dbTransitionOrder` using MongoDB `findOneAndUpdate({ orderNumber, status: expectedStatus })`:
  - `placed` $\rightarrow$ `accepted` | `cancelled`
  - `accepted` $\rightarrow$ `preparing` | `cancelled`
  - `preparing` $\rightarrow$ `ready_for_pickup` | `cancelled`
  - `ready_for_pickup` $\rightarrow$ `completed` | `cancelled`
  - `completed` / `cancelled` are terminal states.
  - Status updates returning concurrency mismatch yield HTTP 409 `ORDER_CHANGED`.
- **Consequences:** Eliminates stale status overwrites and guarantees audit history integrity.

---

### ADR-007: Zero-Infrastructure Polling Strategy for Real-Time Updates
- **Status:** Accepted & Implemented (Smart Polling in Phase 5)
- **Context:** WebSockets / Server-Sent Events (SSE) require persistent connection state incompatible with serverless Next.js on Vercel without third-party subscriptions.
- **Decision:** Implement a 4-second client polling interval in [`src/app/orders/[id]/page.tsx`](src/app/orders/[id]/page.tsx) and [`src/app/merchant/page.tsx`](src/app/merchant/page.tsx). Polling fetches lightweight order JSON documents.
- **Consequences:** 100% serverless compatibility, zero external WebSocket service costs, resilient against connection drops in flaky mobile network environments.

---

### ADR-008: Role-Based Multi-Tenant Scoping and Security Invariants
- **Status:** Accepted & Implemented
- **Context:** Data isolation between different customers, stores, and platform administrators.
- **Decision:**
  - Customers only read and cancel their own orders; unauthorized reads return HTTP 404 (hiding resource existence).
  - Merchants only read and update orders assigned to their `storeId`; attempting to access another store's orders returns HTTP 403.
  - Admins retain marketplace-wide governance access.
  - Admin demotion safeguards prevent admins from accidentally demoting themselves.
- **Consequences:** Strong multi-tenant security with defense-in-depth authorization guards.

---

### ADR-009: Standardized API Error Envelope
- **Status:** Accepted & Implemented
- **Context:** Heterogeneous error structures (`{ error: string }`, `{ message: string }`, raw strings) complicate client UI error handling.
- **Decision:** Standardize all API error responses to `{ error: 'SCREAMING_SNAKE_CASE', message: 'human readable message' }` across all business endpoints (`/api/orders`, `/api/orders/[id]`, `/api/cart`, `/api/merchant/*`, `/api/profile`).
- **Consequences:** Simplifies client-side error parsing and guarantees predictable programmatic error codes.

---

### ADR-010: Rupee Storage for All Financials
- **Status:** Accepted & Implemented (supersedes the earlier paise decision)
- **Context:** Customers, cart, orders, `ProductCard`, seed data and `/merchant/inventory` already used rupees; only the first catalog code used paise, so editing a seeded item saved 100x the price.
- **Decision:** All money (`price`, `mrp`, `subtotal`, `itemTotal`, `totalAmount`) is stored and displayed in rupees. Merchant catalog endpoints accept a number `> 0`, `<= 100000`, with at most 2 decimals (`mrp >= price`). Order line subtotals and the item total are rounded to 2 decimals (`Math.round(x * 100) / 100`). Commission logic is unchanged.
- **Migration:** [`scripts/migrate-paise-to-rupees.mjs`](scripts/migrate-paise-to-rupees.mjs) (dry run by default, `--yes` applies) divides price/mrp by 100 only for paise-era generated product ids. Seeded slug-id products edited through the catalog page are restored by re-running `POST /api/seed`.
- **Consequences:** One unit everywhere. Not covered: amounts are JS floats rounded to 2 decimals, not integer minor units.

---

### ADR-011: Time-Aware Pickup Slot Expiration & Scheduling Guard
- **Status:** Accepted & Implemented
- **Context:** Customers viewing a stale checkout page could place pickup orders for time slots that have already started or are within 30 minutes of closing.
- **Decision:**
  - Dynamically mark slots `isAvailable: false` with `reason: 'SLOT_EXPIRED'` if the slot start time is in the past or within 30 minutes of server time.
  - Server-side order creation rejects expired slots with HTTP 409 `SLOT_EXPIRED`, prompting the client to automatically refresh slots.
- **Consequences:** Prevents unfulfillable pickup orders and gives merchants adequate advance notice to pack items.
