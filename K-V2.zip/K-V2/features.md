# Feature Matrix & Roadmap - Kirana Connect

## 1. Feature Matrix by User Persona

### 1.1 Customer Features
- **Store Discovery & City Filtering:** Browse verified local kirana stores filtered by city (`Indore`, `Varanasi`, `Jaipur`) and neighborhood area.
- **Store Catalog & Search:** Explore store-specific catalogs categorized by daily staples (Atta, Dal, Oils, Dairy, Spices) with English and Hindi nomenclature.
- **Single-Store Cart Enforcement:** Visual conflict modal prompting confirmation before replacing cart contents when browsing a different store.
- **Scheduled Pickup Windows:** Choose advance pickup slots (e.g., *Today, 05:00 PM - 06:00 PM* or *Tomorrow Morning*).
- **Pay at Store Transparency:** Clear zero-delivery fee breakdown and "Pay at Store" (Cash/UPI) instructions.
- **Live Order Status Tracker:** 4-second real-time polling with an interactive status progression timeline.
- **Order Cancellation:** 1-click order cancellation while order is in `placed` status before merchant acceptance.
- **Order History:** Review active and historical grocery pickup receipts.

---

### 1.2 Merchant Features
- **Store Operations Dashboard:** High-level metrics for incoming orders, packing in progress, counter-ready items, and daily revenue.
- **Order Packing Workflow:** Step-by-step status progression (`Accept Order` $\rightarrow$ `Start Packing` $\rightarrow$ `Mark Ready for Pickup` $\rightarrow$ `Mark Picked Up & Paid`).
- **Counter Payment Settlement:** Mark payment collected upon physical cash/UPI receipt.
- **Live Inventory Toggle:** 1-click in-stock / out-of-stock toggle for immediate shelf-sync.
- **Daily Rates Editor:** Quick inline price and MRP adjustments with margin calculation.
- **Store Profile & Schedule (`/merchant/dashboard`):** Update store operational status (`isOpen`), opening and closing hours, address, contact phone, and description.
- **Dedicated Product Catalog Management (`/merchant/catalog`):** Full CRUD for store grocery products in rupees (up to 2 decimals) with category classification, MRP discount tracking, and soft-delete support (soft-deleted products are hidden from customers and rejected by cart and checkout).
- **Customer Note Visibility:** Direct view of special customer packaging instructions.

---

### 1.3 Admin Features
- **Marketplace Governance Dashboard:** Platform-wide GMV, total completed orders, active partner kirana count, and commission revenue (~3.5%).
- **Merchant Onboarding & Verification:** Review merchant applications, toggle verification status, and set custom commission rates.
- **User Role Management:** Promote/demote users across `customer`, `merchant`, and `admin` with self-lockout prevention.
- **Catalog Sandbox Seeder:** Admin-only seed utility for local development and demonstration datasets.
- **Full Order Observability:** Global real-time order monitoring across all partner stores.

---

## 2. Release & Hardening Phases

### Phase 1: Baseline POC & Security Hardening (Completed)
- [x] Initial UI views for Customer, Merchant, and Admin.
- [x] Lazy Firebase Admin initialization and reusable `requireAuth` guard.
- [x] Spoofable identity removal and strict demo auth gating.
- [x] Scoped order reads and secure user synchronization.

### Phase 2: Order State Machine & Server-Authoritative Pricing (Completed)
- [x] Pure finite state machine module (`src/lib/orderStatus.ts`).
- [x] Atomic transition helper (`dbTransitionOrder`) with 409 conflict detection.
- [x] Duplicate key collision retry order creation (`dbCreateOrder`).
- [x] Server-side pricing, inventory validation, and pickup slot verification in `POST /api/orders`.
- [x] UI synchronization and error recovery on state mismatch.

### Phase 3: Catalog & Inventory Management & Data Layer Resilience (Implemented; `check:imports`, `tsc --noEmit`, `npm run build` and the dev page sweep pass via `verify.mjs`)
- [x] Product Catalog API (`POST /api/merchant/products`, `GET /api/merchant/products`, `PATCH /api/merchant/products/[id]`, `DELETE /api/merchant/products/[id]`).
- [x] Rupee financial model everywhere (paise removed); migration script `scripts/migrate-paise-to-rupees.mjs`.
- [x] Fast Inventory Stock Toggle API (`PATCH /api/merchant/products/[id]/stock`).
- [x] Admin Catalog Seeder (`POST /api/admin/catalog/seed`) with duplicate prevention.
- [x] Merchant Catalog UI (`/merchant/catalog`) and Store Settings UI (`/merchant/dashboard`).
- [x] Customer Profile UI (`/customer/profile`) and Profile API (`GET / PATCH /api/profile`).
- [x] Time-aware slot expiration and standardized error envelope (`{ error, message }`).
- [x] Gated in-memory fallback: development only; MongoDB failures return HTTP 503 `SERVICE_UNAVAILABLE` (`src/lib/apiErrors.ts`). Routes that bypass `handleApiError` are not covered.
- [x] Persistent database carts stored in MongoDB `carts` collection keyed by `uid` (unique index); quantity validated as integer 0-50.
- [x] `export const dynamic = 'force-dynamic'` on the GET route files that read the database or the clock.
- [x] Import boundary guard: `server-only` on server libs and `npm run check:imports`.

### Phase 4: Zod Validation, Mass Assignment & Error Sanitization (Completed)
- [x] Zod request schema validation across all API route handlers (`src/lib/validation/`).
- [x] Store mass assignment guard on `PUT /api/stores/[id]` (whitelisting timings, open/close, phone, strict role-based field isolation).
- [x] Product mass assignment guard on `PUT /api/products/[id]` and `POST /api/stores/[id]/products` (immutable field blocking, admin-only IDs).
- [x] Admin merchant commission bounds validation (0-20%, max 2 decimals) and regex/envelope sanitization.

### Phase 5: Client Auth Lifecycle, Error Toasts & Smart Polling (Upcoming)
- [ ] Fresh token retrieval via `onIdTokenChanged` / `getIdToken()`.
- [ ] Visible toast and banner error feedback.
- [ ] Smart polling (pause on background tabs, stop on terminal states).

### Phase 6: Configuration, Testing & Production Build (Upcoming)
- [ ] Vitest unit testing suite (state machine, server pricing, cart logic).
- [ ] Production Firebase Admin validation and environment checklist.
- [ ] Zero TypeScript errors, lint checks, and successful production build.
