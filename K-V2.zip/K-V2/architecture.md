# System Architecture & Technical Specifications - Kirana Connect

## 1. System Overview & Technology Stack

Kirana Connect is a pickup-first hyperlocal grocery platform designed for Indian Tier-2/3 cities. It operates as a serverless modular monolith deployable on Vercel.

```mermaid
graph TD
    subgraph Client ["Client Devices (Mobile-First Web)"]
        Customer[Customer Web App]
        Merchant[Merchant Packing Dashboard]
        Admin[Admin Governance Console]
    end

    subgraph Edge ["Vercel Edge / Serverless Layer"]
        NextRouter[Next.js 14 App Router]
        AuthGuard[requireAuth & Role Scoping]
        OrderSM[orderStatus State Machine]
        DBAdapter[Database Adapter Layer]
    end

    subgraph Auth ["Authentication"]
        FirebaseAuth[Firebase Phone Auth]
        FirebaseAdmin[Firebase Admin SDK]
        DemoPersona[Demo Persona Mode (Dev Only)]
    end

    subgraph Storage ["Data Persistence"]
        MongoAtlas[(MongoDB Atlas Database)]
        MemoryCache[(In-Memory Fallback Cache)]
    end

    Customer --> NextRouter
    Merchant --> NextRouter
    Admin --> NextRouter

    NextRouter --> AuthGuard
    AuthGuard --> FirebaseAuth
    AuthGuard --> FirebaseAdmin
    AuthGuard --> DemoPersona

    NextRouter --> OrderSM
    NextRouter --> DBAdapter
    DBAdapter --> MongoAtlas
    DBAdapter -.->|Local Dev Offline| MemoryCache
```

---

## 2. Core Architectural Components

### 2.1 Next.js 14 App Router
- **Directory Structure:**
  - `src/app`: Page components and API route handlers.
  - `src/components`: Reusable UI components ([`StoreCard`](src/components/StoreCard.tsx:1), [`ProductCard`](src/components/ProductCard.tsx:1), [`OrderTimeline`](src/components/OrderTimeline.tsx:1), [`SingleStoreConflictModal`](src/components/SingleStoreConflictModal.tsx:1), [`RoleSwitcher`](src/components/RoleSwitcher.tsx:1)).
  - `src/context`: Client-side state contexts ([`AuthContext`](src/context/AuthContext.tsx:1), [`CartContext`](src/context/CartContext.tsx:1)).
  - `src/lib`: Database connections, auth middleware, order state machine, and mock data.
  - `src/types`: Strict TypeScript domain definitions.

### 2.2 Security & Authentication Pipeline
- **Authentication Guard:** [`requireAuth(req, allowedRoles?)`](src/lib/authMiddleware.ts:1) validates the incoming Bearer token via Firebase Admin SDK or validated demo persona tokens.
- **Identity Invariant:** No client-supplied user IDs (`body.userId`, `x-user-id`) are trusted. All customer, merchant, and admin identities are extracted directly from the verified token.

---

## 3. Data Architecture & MongoDB Schema Specifications

### 3.1 Collections & Index Strategy

| Collection | Key Fields | Indexes | Unique Constraints |
|---|---|---|---|
| `users` | `uid`, `phone`, `name`, `role`, `storeId` | `{ uid: 1 }` | `uid` (unique) |
| `stores` | `id`, `name`, `merchantUid`, `isOpen`, `isVerified`, `commissionRate`, `location` | `{ id: 1 }` | `id` (unique) |
| `store_products` | `id`, `storeId`, `name`, `price`, `mrp`, `unit`, `inStock`, `category` | `{ id: 1 }`, `{ storeId: 1 }` | `id` (unique) |
| `orders` | `orderNumber`, `userId`, `storeId`, `status`, `totalAmount`, `payment`, `createdAt` | `{ orderNumber: 1 }`, `{ userId: 1, createdAt: -1 }`, `{ storeId: 1, createdAt: -1 }`, `{ createdAt: -1 }` | `orderNumber` (unique) |
| `carts` | `userId`, `storeId`, `items`, `itemTotal`, `updatedAt` | `{ userId: 1 }` | `userId` (unique) |

---

## 4. Order State Machine Architecture

```mermaid
stateDiagram-v2
    [*] --> placed: Customer Places Order
    placed --> accepted: Merchant Accepts
    placed --> cancelled: Customer Cancels / Merchant Declines
    accepted --> preparing: Merchant Starts Packing
    accepted --> cancelled: Merchant Cancels
    preparing --> ready_for_pickup: Packed & On Counter
    preparing --> cancelled: Merchant Cancels
    ready_for_pickup --> completed: Customer Collects & Pays (Cash/UPI)
    ready_for_pickup --> cancelled: Merchant Cancels
    completed --> [*]
    cancelled --> [*]
```

### 4.1 Transition Rules & Role Authorities
- **`placed` $\rightarrow$ `accepted`**: Role `merchant` (assigned store) or `admin`.
- **`placed` $\rightarrow$ `cancelled`**: Role `customer` (order owner), `merchant` (assigned store), or `admin`.
- **`accepted` $\rightarrow$ `preparing`**: Role `merchant` (assigned store) or `admin`.
- **`preparing` $\rightarrow$ `ready_for_pickup`**: Role `merchant` (assigned store) or `admin`.
- **`ready_for_pickup` $\rightarrow$ `completed`**: Role `merchant` (assigned store) or `admin`. Automatically sets `payment.status: "COLLECTED"`.
- **`completed` & `cancelled`**: Terminal immutable states.

---

## 5. API Endpoint Specifications

| Method | Endpoint | Access Role | Description |
|---|---|---|---|
| `GET` | `/api/stores` | Public / All | List verified kirana stores with city/area filters |
| `GET` | `/api/stores/[id]` | Public / All | Fetch single store details |
| `PUT` | `/api/stores/[id]` | Merchant / Admin | Update store timings, open/close status, phone, banner |
| `GET` | `/api/merchant/store` | Merchant | Fetch authenticated merchant's store details |
| `PATCH` | `/api/merchant/store` | Merchant | Update store schedule, name, address, phone, and open/closed status |
| `GET` | `/api/profile` | Authenticated | Fetch authenticated user's profile |
| `PATCH` | `/api/profile` | Authenticated | Update user's full name |
| `GET` | `/api/merchant/products` | Merchant | List active store products (token-scoped) |
| `POST` | `/api/merchant/products` | Merchant | Create new product in integer paise with category enum check |
| `PATCH` | `/api/merchant/products/[id]` | Merchant | Edit product name, category, price, MRP, unit |
| `DELETE` | `/api/merchant/products/[id]` | Merchant | Soft delete product (`isActive: false`) |
| `PATCH` | `/api/merchant/products/[id]/stock` | Merchant | Fast toggle in-stock / out-of-stock status |
| `POST` | `/api/admin/catalog/seed` | Admin (Non-Prod) | Seed template grocery catalog for a given store |
| `GET` | `/api/cart` | Authenticated | Retrieve persistent user cart |
| `POST` | `/api/cart` | Authenticated | Add/update item quantity with single-store conflict check |
| `DELETE` | `/api/cart` | Authenticated | Clear user cart |
| `GET` | `/api/pickup-slots` | Public / All | Generate real-time available collection time slots with expiry checks |
| `GET` | `/api/orders` | Authenticated | Scoped order list (Customer: own, Merchant: store, Admin: all) |
| `POST` | `/api/orders` | Customer / All | Place advance order with server pricing, stock & slot expiry checks |
| `GET` | `/api/orders/[id]` | Scoped | Fetch order details with role-based access check |
| `PATCH` | `/api/orders/[id]` | Scoped | Transition order status and record audit history |
| `POST` | `/api/auth/sync` | Authenticated | Synchronize Firebase token user with database record |
| `PATCH` | `/api/admin/users/[uid]` | Admin | Update user role and store assignment |
| `PATCH` | `/api/admin/merchants` | Admin | Approve merchant and configure commission rate |
