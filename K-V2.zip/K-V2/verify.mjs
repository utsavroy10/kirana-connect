#!/usr/bin/env node
/**
 * verify.mjs - one-shot verification for the Phase 1-3 fixes. No dependencies of its own.
 *
 *   npm install                 (required first: adds "server-only", installs typescript/next)
 *   node verify.mjs             static checks + unit checks + check:imports + tsc --noEmit
 *   node verify.mjs --build     ... plus `npm run build`
 *   node verify.mjs --pages     ... plus start `next dev` and request every page + 2 API GETs
 *   node verify.mjs --build --pages
 *
 * Prints PASS/FAIL per check and writes everything to verify-report.txt. Paste that file back.
 */
import { spawnSync, spawn } from 'node:child_process';
import { readFileSync, readdirSync, statSync, existsSync, writeFileSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { createRequire } from 'node:module';
import vm from 'node:vm';

const ROOT = process.cwd();
const args = new Set(process.argv.slice(2));
const require = createRequire(join(ROOT, 'package.json'));
const lines = [];
const results = [];

const out = (s = '') => { lines.push(s); console.log(s); };
const rel = (f) => relative(ROOT, f).split(sep).join('/');
const record = (name, ok, detail = '') => {
  results.push({ name, ok });
  out(`${ok ? 'PASS' : 'FAIL'}  ${name}`);
  if (detail) for (const l of String(detail).split('\n')) out('      ' + l);
};

function walk(dir, acc = []) {
  for (const n of readdirSync(dir)) {
    const f = join(dir, n);
    if (statSync(f).isDirectory()) walk(f, acc);
    else if (/\.(ts|tsx|js|jsx|mjs)$/.test(n)) acc.push(f);
  }
  return acc;
}
const read = (p) => readFileSync(join(ROOT, p), 'utf8');
const lineOf = (text, idx) => text.slice(0, idx).split('\n').length;

out(`verify.mjs  node ${process.version}  ${new Date().toISOString()}`);
out(`cwd: ${ROOT}`);
out('');

// ---------------------------------------------------------------- environment
out('== Environment ==');
record('node_modules present (run `npm install` first)', existsSync(join(ROOT, 'node_modules')));
record('server-only installed', existsSync(join(ROOT, 'node_modules', 'server-only')), 'If FAIL: run `npm install`.');
record('typescript installed', existsSync(join(ROOT, 'node_modules', 'typescript')));
out('');

// ---------------------------------------------------------------- static checks
out('== Static checks ==');
const srcFiles = walk(join(ROOT, 'src'));

{
  const hits = [];
  for (const f of srcFiles) {
    const t = readFileSync(f, 'utf8');
    const re = /catch\s*(\([^)]*\))?\s*\{\s*(\/\/[^\n]*\s*)?\}/g;
    let m;
    while ((m = re.exec(t))) hits.push(`${rel(f)}:${lineOf(t, m.index)}`);
  }
  record('no empty catch blocks in src', hits.length === 0, hits.join('\n'));
}
{
  const hits = [];
  for (const f of srcFiles) {
    const t = readFileSync(f, 'utf8');
    for (const word of ['userCarts', 'Boolean(inStock)', 'paise', 'Paise']) {
      const i = t.indexOf(word);
      if (i >= 0) hits.push(`${rel(f)}:${lineOf(t, i)}  contains "${word}"`);
    }
  }
  record('no userCarts / Boolean(inStock) / paise leftovers', hits.length === 0, hits.join('\n'));
}
{
  const allowed = new Set(['src/lib/db-adapter.ts', 'src/lib/indexes.ts', 'src/lib/mongodb.ts']);
  const hits = [];
  for (const f of srcFiles) {
    if (allowed.has(rel(f))) continue;
    const t = readFileSync(f, 'utf8');
    if (/from\s+['"](@\/lib\/mongodb|\.\/mongodb|\.\.\/lib\/mongodb)['"]/.test(t)) hits.push(rel(f));
  }
  record('only db-adapter/indexes import lib/mongodb', hits.length === 0, hits.join('\n'));
}
{
  const missing = ['db-adapter', 'mongodb', 'firebaseAdmin', 'authMiddleware', 'indexes', 'orderPatchHandler']
    .map((n) => `src/lib/${n}.ts`)
    .filter((p) => !existsSync(join(ROOT, p)) || !/^\s*import\s+['"]server-only['"]/m.test(read(p)));
  record("import 'server-only' in the server lib files", missing.length === 0, missing.join('\n'));
}
{
  const routes = [
    'admin/merchants', 'cart', 'merchant/products', 'merchant/products/[id]', 'merchant/store',
    'orders', 'orders/[id]', 'pickup-slots', 'profile', 'stores', 'stores/[id]', 'stores/[id]/products',
  ].map((r) => `src/app/api/${r}/route.ts`);
  const missing = routes.filter((p) => !existsSync(join(ROOT, p)) || !/export const dynamic = ['"]force-dynamic['"]/.test(read(p)));
  record("force-dynamic on the 12 GET routes", missing.length === 0, missing.join('\n'));
}
{
  const hits = [];
  for (const f of srcFiles.filter((x) => /[\\/]app[\\/]api[\\/].*route\.ts$/.test(x))) {
    const t = readFileSync(f, 'utf8');
    if (/status:\s*500/.test(t)) hits.push(rel(f));
  }
  record('no hard-coded 500s in routes (use handleApiError)', hits.length === 0, hits.join('\n'));
}
{
  const t = read('src/app/merchant/catalog/page.tsx');
  const hits = [];
  for (const re of [/\*\s*100\b/g, /\/\s*100\b/g, /@\/app\/api/g]) {
    let m;
    while ((m = re.exec(t))) hits.push(`catalog/page.tsx:${lineOf(t, m.index)}  matches ${re}`);
  }
  record('catalog page has no x100 or /100 and no route imports', hits.length === 0, hits.join('\n'));
}
{
  const t = read('tsconfig.json');
  record('tsconfig target is es2017', /"target"\s*:\s*"es2017"/i.test(t));
  const n = read('next.config.js');
  record('next.config.js does not enable asyncWebAssembly or wasm fallbacks', !/asyncWebAssembly|fallback/.test(n));
}
out('');

// ---------------------------------------------------------------- unit checks
out('== Unit checks (TypeScript transpiled in memory) ==');
function loadTs(path) {
  const ts = require('typescript');
  const src = read(path);
  const js = ts.transpileModule(src, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2019 },
  }).outputText;
  const mod = { exports: {} };
  const fn = vm.runInThisContext(`(function(exports, module, require){${js}\n})`);
  fn(mod.exports, mod, () => ({}));
  return mod.exports;
}

try {
  const money = loadTs('src/lib/money.ts');
  const cases = [[245, true], [0.01, true], [100000, true], [0, false], [-1, false], [100000.01, false], [1.005, false], [NaN, false], ['5', false], [Infinity, false]];
  const bad = cases.filter(([v, e]) => money.isValidRupeeAmount(v) !== e).map(([v, e]) => `isValidRupeeAmount(${String(v)}) expected ${e}`);
  record('money.isValidRupeeAmount', bad.length === 0, bad.join('\n'));
} catch (e) { record('money.isValidRupeeAmount', false, String(e && e.stack || e)); }

try {
  const os = loadTs('src/lib/orderStatus.ts');
  const bad = [];
  const t = (name, got, exp) => { if (got !== exp) bad.push(`${name}: got ${got}, expected ${exp}`); };
  t('placed->accepted', os.canTransition('placed', 'accepted'), true);
  t('placed->completed', os.canTransition('placed', 'completed'), false);
  t('completed->cancelled', os.canTransition('completed', 'cancelled'), false);
  t('customer cancels own placed', os.canRoleTransition('customer', 'placed', 'cancelled', false, true), true);
  t('customer cancels accepted', os.canRoleTransition('customer', 'accepted', 'cancelled', false, true), false);
  t('customer cancels others', os.canRoleTransition('customer', 'placed', 'cancelled', false, false), false);
  t('other-store merchant', os.canRoleTransition('merchant', 'placed', 'accepted', false, false), false);
  t('own-store merchant', os.canRoleTransition('merchant', 'placed', 'accepted', true, false), true);
  t('isValidStatus("bogus")', os.isValidStatus('bogus'), false);
  t('isValidPaymentStatus COLLECTED', os.isValidPaymentStatus('COLLECTED'), true);
  record('orderStatus transitions and role rules', bad.length === 0, bad.join('\n'));
} catch (e) { record('orderStatus transitions and role rules', false, String(e && e.stack || e)); }

try {
  const md = loadTs('src/lib/mock-data.ts');
  const bad = [];
  const avail = (slots) => slots.filter((s) => s.isAvailable).map((s) => s.id).join(',');
  const expect = (name, got, exp) => { if (got !== exp) bad.push(`${name}: got [${got}], expected [${exp}]`); };

  // 10:00 UTC = 15:30 IST: slot_1 (16:00 IST) is 30 min away -> cutoff is "<=", so expired
  expect('10:00Z (15:30 IST)', avail(md.generatePickupSlots(new Date('2025-01-15T10:00:00Z'))), 'slot_2,slot_3,slot_4,slot_5,slot_tomorrow_morn');
  // 09:29 UTC = 14:59 IST: all today slots available
  expect('09:29Z (14:59 IST)', avail(md.generatePickupSlots(new Date('2025-01-15T09:29:00Z'))), 'slot_1,slot_2,slot_3,slot_4,slot_5,slot_tomorrow_morn');
  // 15:00 UTC = 20:30 IST: only tomorrow morning
  expect('15:00Z (20:30 IST)', avail(md.generatePickupSlots(new Date('2025-01-15T15:00:00Z'))), 'slot_tomorrow_morn');
  // 20:00 UTC = 01:30 IST next day: "today" is the IST date, so all of today's evening slots are available and tomorrow morning too
  expect('20:00Z (01:30 IST next day)', avail(md.generatePickupSlots(new Date('2025-01-15T20:00:00Z'))), 'slot_1,slot_2,slot_3,slot_4,slot_5,slot_tomorrow_morn');
  // 02:30 UTC = 08:00 IST: tomorrow morning slot is ~24h away -> available
  const slots = md.generatePickupSlots(new Date('2025-01-15T02:30:00Z'));
  expect('ids/labels kept', slots.map((s) => s.id).join(','), 'slot_1,slot_2,slot_3,slot_4,slot_5,slot_tomorrow_morn');
  expect('tomorrow date label', slots[5].date, 'Tomorrow');
  expect('unavailable reason', md.generatePickupSlots(new Date('2025-01-15T15:00:00Z'))[0].reason, 'SLOT_EXPIRED');
  record('generatePickupSlots uses Asia/Kolkata', bad.length === 0, bad.join('\n'));
} catch (e) { record('generatePickupSlots uses Asia/Kolkata', false, String(e && e.stack || e)); }
out('');

// ---------------------------------------------------------------- commands
function run(label, cmd, cmdArgs, timeoutMs) {
  out(`== ${label}: ${cmd} ${cmdArgs.join(' ')} ==`);
  const r = spawnSync(cmd, cmdArgs, { cwd: ROOT, shell: true, encoding: 'utf8', timeout: timeoutMs, maxBuffer: 64 * 1024 * 1024 });
  const text = `${r.stdout || ''}${r.stderr || ''}`.trim();
  const tail = text.split('\n').slice(-120).join('\n');
  record(label, r.status === 0, `exit code ${r.status}${r.error ? ' (' + r.error.message + ')' : ''}\n${tail}`);
  out('');
  return r.status === 0;
}

run('npm run check:imports', 'npm', ['run', 'check:imports'], 120000);
run('npx tsc --noEmit', 'npx', ['tsc', '--noEmit'], 600000);
if (args.has('--build')) run('npm run build', 'npm', ['run', 'build'], 1200000);

// ---------------------------------------------------------------- dev pages
async function pages() {
  out('== next dev: visit every page ==');
  const port = 3999;
  const base = `http://localhost:${port}`;
  const child = spawn('npx', ['next', 'dev', '-p', String(port)], { cwd: ROOT, shell: true, stdio: ['ignore', 'pipe', 'pipe'] });
  let log = '';
  child.stdout.on('data', (d) => (log += d));
  child.stderr.on('data', (d) => (log += d));

  const kill = () => {
    if (process.platform === 'win32') spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F']);
    else child.kill('SIGTERM');
  };

  try {
    const start = Date.now();
    while (!/Ready in|ready - started|Local:/.test(log) && Date.now() - start < 120000) {
      await new Promise((r) => setTimeout(r, 500));
    }
    const targets = [
      '/', '/login', '/cart', '/orders', '/orders/KC-0000-0000', '/stores/store_1', '/merchant',
      '/merchant/inventory', '/merchant/catalog', '/merchant/dashboard', '/customer/profile', '/admin', '/admin/merchants',
      '/api/pickup-slots', '/api/stores',
    ];
    for (const path of targets) {
      try {
        const res = await fetch(base + path, { signal: AbortSignal.timeout(180000) });
        const body = await res.text();
        const broken = /Module parse failed|Application error|Unhandled Runtime Error|Internal Server Error|Failed to compile/i.test(body);
        record(`GET ${path}`, res.status < 500 && !broken, `HTTP ${res.status}${broken ? ' (error text in response)' : ''}`);
      } catch (e) {
        record(`GET ${path}`, false, String(e));
      }
    }
    const errs = log.split('\n').filter((l) => /(error|failed|Module parse)/i.test(l)).slice(-40);
    out('dev server log lines mentioning errors (may include expected Mongo-not-configured warnings):');
    for (const l of errs) out('   ' + l.trim());
  } finally {
    kill();
  }
  out('');
}
if (args.has('--pages')) await pages();

// ---------------------------------------------------------------- summary
const failed = results.filter((r) => !r.ok);
out('== Summary ==');
out(`${results.length - failed.length}/${results.length} checks passed`);
for (const f of failed) out(`  FAILED: ${f.name}`);
if (!args.has('--build')) out('Note: `npm run build` not run; use `node verify.mjs --build`.');
if (!args.has('--pages')) out('Note: dev pages not visited; use `node verify.mjs --pages`.');
writeFileSync(join(ROOT, 'verify-report.txt'), lines.join('\n') + '\n');
out('\nReport written to verify-report.txt');
process.exit(failed.length ? 1 : 0);
