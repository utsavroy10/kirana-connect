# Kirana Connect: UI & Business Architecture Mapping

This document details the mapping between high-level business requirements, user roles, user interfaces, backend API routes, and MongoDB Atlas collections for the **Kirana Connect** POC.

---

## 1. Store Discovery & Local Kirana Browsing

- **Page URL:** [`/`](src/app/page.tsx:1)
- **Business Need / Process:**
  - Modernize local kirana ordering by allowing customers in Tier-2/3 cities to discover trusted neighborhood grocery stores without queues or delivery fees.
  - Enable digital visibility for traditional kirana owners.
- **Primary User Role:** `Customer`
- **Important UI Components:**
  - Hero banner with pickup-first value proposition.
  - City dropdown filter (`Indore`, `Varanasi`, `Jaipur`, `All`).
  - Search bar (Store name, locality/area, product category).
  - [`StoreCard`](src/components/StoreCard.tsx:1) displaying verified badge, pickup hours, rating, and locality.
  - Quick persona switcher [`RoleSwitcher`](src/components/RoleSwitcher.tsx:1).
- **API Routes Used:**
  - `GET /api/stores`
- **MongoDB Collections Used:**
  - `stores`

---

## 2. Store Product Catalog & Single-Store Cart

- **Page URL:** [`/stores/[id]`](src/app/stores/[id]/page.tsx:1)
- **Business Need / Process:**
  - Provide customers with real-time visibility into grocery stock, MRP discounts, and direct store prices.
  - Enforce the single-store cart rule so pickups are grouped at a single physical merchant location.
- **Primary User Role:** `Customer`
- **Important UI Components:**
  - Store header info with address, phone contact, and pickup hours.
  - Category filter tabs (`Atta & Flour`, `Cooking Oils`, `Rice & Pulses`, etc.).
  - Search input within store catalog.
  - [`ProductCard`](src/components/ProductCard.tsx:1) with unit details, Hindi name tags, discount badges, and +/- quantity stepper.
  - [`SingleStoreConflictModal`](src/components/SingleStoreConflictModal.tsx:1) for resolving store-switch conflicts.
  - Floating sticky cart preview bar.
- **API Routes Used:**
  - `GET /api/stores/[id]`
  - `GET /api/stores/[id]/products`
  - `POST /api/cart`
- **MongoDB Collections Used:**
  - `stores`
  - `store_products`
  - `carts`

---

## 3. Cart Review, Pickup Slot Scheduling & Checkout

- **Page URL:** [`/cart`](src/app/cart/page.tsx:1)
- **Business Need / Process:**
  - Frictionless advance ordering with chosen collection timing.
  - Clarify zero delivery fees and "Pay at Store" (Cash / UPI) model to maintain trust with traditional customers.
- **Primary User Role:** `Customer`
- **Important UI Components:**
  - Itemized grocery list with live quantity adjustment and clear cart action.
  - Pickup slot selector cards (Today / Tomorrow time windows).
  - Customer name & phone contact form.
  - Special packing note input (e.g. polybag/box instructions).
  - "Pay at Store" summary badge.
- **API Routes Used:**
  - `GET /api/cart`
  - `POST /api/cart`
  - `DELETE /api/cart`
  - `GET /api/pickup-slots`
  - `POST /api/orders`
- **MongoDB Collections Used:**
  - `carts`
  - `orders`
  - `stores`

---

## 4. Live Order Tracking & Status Polling

- **Page URL:** [`/orders/[id]`](src/app/orders/[id]/page.tsx:1)
- **Business Need / Process:**
  - Keep customers informed in real time when their grocery order is accepted, being packed, and ready at the store counter.
  - Avoid customer wait times in physical queues.
- **Primary User Role:** `Customer`
- **Important UI Components:**
  - Prominent status banner with status-specific icons.
  - [`OrderTimeline`](src/components/OrderTimeline.tsx:1) tracking order lifecycle (`placed` &rarr; `accepted` &rarr; `preparing` &rarr; `ready_for_pickup` &rarr; `completed`).
  - Active background polling ticker (every 4 seconds).
  - Store location, map landmark, and direct "Call Store" button.
  - Order cancellation option before merchant acceptance.
- **API Routes Used:**
  - `GET /api/orders/[id]`
  - `PATCH /api/orders/[id]/status`
- **MongoDB Collections Used:**
  - `orders`

---

## 5. Customer Pickup History

- **Page URL:** [`/orders`](src/app/orders/page.tsx:1)
- **Business Need / Process:**
  - Enable customers to review ongoing pickups and past order receipts.
- **Primary User Role:** `Customer`
- **Important UI Components:**
  - Order card cards with status badges.
  - Direct link to track order.
- **API Routes Used:**
  - `GET /api/orders`
- **MongoDB Collections Used:**
  - `orders`

---

## 6. Merchant Order Processing & Packing Dashboard

- **Page URL:** [`/merchant`](src/app/merchant/page.tsx:1)
- **Business Need / Process:**
  - Provide a simple, mobile-friendly operational interface for kirana shopkeepers.
  - Shopkeeper receives incoming orders, accepts or declines based on current stock, progresses preparation, marks orders ready, and confirms cash/UPI collection.
- **Primary User Role:** `Merchant`
- **Important UI Components:**
  - Today's summary metrics (New orders, packing in progress, ready at counter, total sales).
  - Tab filters (`New Orders`, `Packing`, `Ready for Pickup`, `Completed`).
  - 1-click status progression buttons (`Accept`, `Start Packing`, `Mark Ready`, `Mark Picked Up & Paid`).
  - Direct customer contact phone link and customer notes badge.
- **API Routes Used:**
  - `GET /api/orders?storeId=[storeId]`
  - `PATCH /api/orders/[id]/status`
- **MongoDB Collections Used:**
  - `orders`
  - `stores`

---

## 7. Merchant Inventory & Daily Rates Management

- **Page URL:** [`/merchant/inventory`](src/app/merchant/inventory/page.tsx:1)
- **Business Need / Process:**
  - Give kirana operators complete control over item availability (in-stock vs out-of-stock) and daily price fluctuations without technical overhead.
- **Primary User Role:** `Merchant`
- **Important UI Components:**
  - Add new item form (Name, Hindi name, category, unit, price, MRP).
  - Fast inline price editor with instant save.
  - 1-click in-stock / out-of-stock toggle badge.
  - Search filter by item name or category.
- **API Routes Used:**
  - `GET /api/stores/[id]/products`
  - `POST /api/stores/[id]/products`
  - `PUT /api/products/[id]`
- **MongoDB Collections Used:**
  - `store_products`

---

## 8. Platform Governance & Admin Pilot Management

- **Page URL:** [`/admin`](src/app/admin/page.tsx:1) & [`/admin/merchants`](src/app/admin/merchants/page.tsx:1)
- **Business Need / Process:**
  - Monitor total platform GMV, completed orders, and pilot commission earnings.
  - Onboard and approve new partner kiranas.
  - Verify merchant credentials and adjust custom commission rates.
  - Seed initial realistic Indian grocery catalog.
- **Primary User Role:** `Admin`
- **Important UI Components:**
  - Metric summary cards (Total Orders, Active Stores, Platform GMV, Commission Earned).
  - Seed database button for zero-friction sandbox reset.
  - Real-time marketplace orders live feed across all partner kirana stores.
  - Merchant approval table with verification status toggles and commission rate editor.
- **API Routes Used:**
  - `GET /api/orders`
  - `GET /api/admin/merchants`
  - `PATCH /api/admin/merchants`
  - `POST /api/seed`
- **MongoDB Collections Used:**
  - `users`
  - `stores`
  - `store_products`
  - `orders`

---

## 9. Mobile Phone OTP Authentication

- **Page URL:** [`/login`](src/app/login/page.tsx:1)
- **Business Need / Process:**
  - Low-friction mobile phone authentication tailored for Indian users with Firebase Phone Auth and 1-Click persona switching for rapid stakeholder demos.
- **Primary User Role:** `Customer`, `Merchant`, `Admin`
- **Important UI Components:**
  - Role selector tabs.
  - Phone number input (+91 format).
  - OTP verification input.
  - 1-Click Instant Demo profiles (Aman Sharma / Ram Prasad Gupta / Platform Admin).
- **API Routes Used:**
  - `POST /api/auth/sync`
- **MongoDB Collections Used:**
  - `users`
