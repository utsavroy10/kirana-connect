#!/usr/bin/env node
/**
 * check-server-imports.mjs  (npm run check:imports)
 *
 * Fails (exit 1, file:line output) when:
 *  (a) a 'use client' file, or anything it imports through relative or @/ paths, imports
 *      @/app/api/*, @/lib/{db-adapter,mongodb,firebaseAdmin,authMiddleware,indexes},
 *      firebase-admin, mongodb, fs or path;
 *  (b) a route.ts exports anything other than GET/POST/PUT/PATCH/DELETE/HEAD/OPTIONS or Next config names;
 *  (c) one route file imports another route file.
 *
 * No dependencies. Run from the project root.
 */
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, resolve, dirname, relative, sep } from 'node:path';

const ROOT = process.cwd();
const SRC = join(ROOT, 'src');
const EXTS = ['.ts', '.tsx', '.js', '.jsx'];

const HTTP_METHODS = new Set(['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']);
const NEXT_CONFIG_EXPORTS = new Set([
  'dynamic', 'dynamicParams', 'revalidate', 'fetchCache', 'runtime', 'preferredRegion', 'maxDuration', 'generateStaticParams',
]);

const FORBIDDEN_MODULES = new Set(['firebase-admin', 'mongodb', 'fs', 'path', 'node:fs', 'node:path']);
const FORBIDDEN_ALIASES = ['db-adapter', 'mongodb', 'firebaseAdmin', 'authMiddleware', 'indexes'].map((n) => `@/lib/${n}`);

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) walk(full, out);
    else if (EXTS.some((e) => name.endsWith(e))) out.push(full);
  }
  return out;
}

const rel = (f) => relative(ROOT, f).split(sep).join('/');

/** Strip comments but keep line structure so reported line numbers stay accurate. */
function stripComments(text) {
  return text
    .replace(/\/\*[\s\S]*?\*\//g, (m) => m.replace(/[^\n]/g, ' '))
    .replace(/(^|[^:])\/\/.*$/gm, (m, p1) => p1);
}

const IMPORT_RE = /(?:^|\n)\s*(?:import|export)\s+(?:type\s+)?(?:[^'"`;]*?\sfrom\s+)?['"]([^'"]+)['"]|(?:^|[^\w.])(?:require|import)\(\s*['"]([^'"]+)['"]\s*\)/g;

function parseImports(file) {
  const text = stripComments(readFileSync(file, 'utf8'));
  const found = [];
  let m;
  IMPORT_RE.lastIndex = 0;
  while ((m = IMPORT_RE.exec(text))) {
    const spec = m[1] || m[2];
    const idx = m.index + m[0].indexOf(spec);
    const line = text.slice(0, idx).split('\n').length;
    // `import type` is erased at compile time, so it cannot leak server code to the browser
    const stmt = m[0];
    if (/^\s*(?:import|export)\s+type\s/.test(stmt)) continue;
    found.push({ spec, line });
  }
  return found;
}

function resolveSpec(spec, fromFile) {
  let base;
  if (spec.startsWith('@/')) base = join(SRC, spec.slice(2));
  else if (spec.startsWith('.')) base = resolve(dirname(fromFile), spec);
  else return null;
  const candidates = [base, ...EXTS.map((e) => base + e), ...EXTS.map((e) => join(base, 'index' + e))];
  return candidates.find((c) => existsSync(c) && statSync(c).isFile()) || null;
}

function isForbidden(spec, resolved) {
  if (FORBIDDEN_MODULES.has(spec) || spec.startsWith('firebase-admin/') || spec.startsWith('mongodb/')) return `server-only package "${spec}"`;
  if (spec.startsWith('@/app/api/')) return `API route module "${spec}"`;
  if (FORBIDDEN_ALIASES.some((a) => spec === a)) return `server-only module "${spec}"`;
  if (resolved) {
    const r = rel(resolved);
    if (r.startsWith('src/app/api/')) return `API route module "${spec}"`;
    if (/^src\/lib\/(db-adapter|mongodb|firebaseAdmin|authMiddleware|indexes)\.[tj]sx?$/.test(r)) return `server-only module "${spec}"`;
  }
  return null;
}

const files = walk(SRC);
const isClient = (f) => /^\s*(?:\/\*[\s\S]*?\*\/\s*|\/\/.*\n\s*)*['"]use client['"]/.test(readFileSync(f, 'utf8'));
const isRoute = (f) => /\/route\.[tj]s$/.test(rel(f));

const violations = [];

// (a) client files and their transitive relative/@ imports
const importCache = new Map();
const importsOf = (f) => {
  if (!importCache.has(f)) importCache.set(f, parseImports(f));
  return importCache.get(f);
};

for (const entry of files.filter(isClient)) {
  const seen = new Set();
  const stack = [{ file: entry, chain: [entry] }];
  while (stack.length) {
    const { file, chain } = stack.pop();
    if (seen.has(file)) continue;
    seen.add(file);
    for (const { spec, line } of importsOf(file)) {
      const resolved = resolveSpec(spec, file);
      const bad = isForbidden(spec, resolved);
      if (bad) {
        const via = chain.length > 1 ? ` (reached from client entry ${rel(entry)} via ${chain.slice(1).map(rel).join(' -> ')})` : '';
        violations.push(`${rel(file)}:${line}  client bundle imports ${bad}${via}`);
        continue;
      }
      if (resolved && !seen.has(resolved)) stack.push({ file: resolved, chain: [...chain, resolved] });
    }
  }
}

// (b) route exports and (c) route -> route imports
const EXPORT_RE = /(?:^|\n)\s*export\s+(?:async\s+)?(?:(?:const|let|var|function\*?|class|enum|interface|type)\s+([A-Za-z_$][\w$]*)|default\b|\{([^}]*)\})/g;
for (const file of files.filter(isRoute)) {
  const raw = readFileSync(file, 'utf8');
  const text = stripComments(raw);
  let m;
  EXPORT_RE.lastIndex = 0;
  while ((m = EXPORT_RE.exec(text))) {
    const line = text.slice(0, m.index + m[0].length).split('\n').length;
    const names = [];
    if (m[1]) names.push(m[1]);
    else if (m[2] !== undefined) {
      for (const part of m[2].split(',')) {
        const n = part.trim().split(/\s+as\s+/).pop().trim();
        if (n) names.push(n);
      }
    } else names.push('default');
    // type/interface exports are erased and cannot be route exports at runtime
    if (/export\s+(?:type|interface)\s/.test(m[0])) continue;
    for (const n of names) {
      if (!HTTP_METHODS.has(n) && !NEXT_CONFIG_EXPORTS.has(n)) {
        violations.push(`${rel(file)}:${line}  route exports "${n}" (only HTTP handlers and Next config are allowed)`);
      }
    }
  }

  for (const { spec, line } of importsOf(file)) {
    const resolved = resolveSpec(spec, file);
    if (resolved && isRoute(resolved)) {
      violations.push(`${rel(file)}:${line}  route imports another route file "${spec}" (${rel(resolved)})`);
    }
  }
}

if (violations.length) {
  console.error(`check:imports found ${violations.length} problem(s):\n`);
  for (const v of violations) console.error('  ' + v);
  console.error('\nFix at the boundary: move shared constants/types to a pure src/lib/* module with no server imports.');
  process.exit(1);
}

console.log(`check:imports OK (${files.length} files scanned)`);
