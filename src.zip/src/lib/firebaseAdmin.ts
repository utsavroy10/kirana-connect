import admin from 'firebase-admin';

if (!admin.apps.length) {
  const projectId = process.env.FIREBASE_PROJECT_ID || process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  let privateKey = process.env.FIREBASE_PRIVATE_KEY;

  if (privateKey) {
    privateKey = privateKey.replace(/\\n/g, '\n');
  }

  if (projectId && clientEmail && privateKey) {
    try {
      admin.initializeApp({
        credential: admin.credential.cert({
          projectId,
          clientEmail,
          privateKey,
        }),
      });
    } catch (e) {
      console.error('Firebase admin cert initialization error', e);
    }
  } else {
    // Fallback initialize for local POC/demo environment
    try {
      admin.initializeApp({
        projectId: projectId || 'kirana-connect-poc',
      });
    } catch (e) {
      console.warn('Firebase admin fallback initialized');
    }
  }
}

export const adminAuth = admin.auth();
export default admin;
