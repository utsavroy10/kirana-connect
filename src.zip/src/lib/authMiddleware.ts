import { NextRequest } from 'next/server';
import { adminAuth } from '@/lib/firebaseAdmin';
import { connectToDatabase } from '@/lib/mongodb';
import { User, UserRole } from '@/types';

export interface AuthenticatedUser {
  uid: string;
  phone?: string;
  role: UserRole;
  storeId?: string;
}

export async function verifyAuthToken(req: NextRequest): Promise<AuthenticatedUser | null> {
  const authHeader = req.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  const token = authHeader.split('Bearer ')[1].trim();
  if (!token) {
    return null;
  }

  // Support POC simulated demo tokens for instant evaluation & testing
  if (token.startsWith('DEMO_TOKEN_')) {
    const rolePart = token.replace('DEMO_TOKEN_', '').toLowerCase();
    const demoRole: UserRole = rolePart === 'merchant' ? 'merchant' : rolePart === 'admin' ? 'admin' : 'customer';
    const demoPhone = demoRole === 'merchant' ? '+919876543210' : demoRole === 'admin' ? '+919999999999' : '+919811122233';
    const demoUid = `demo_${demoRole}_uid`;
    const demoStoreId = demoRole === 'merchant' ? 'store_shree_ram' : undefined;

    return {
      uid: demoUid,
      phone: demoPhone,
      role: demoRole,
      storeId: demoStoreId,
    };
  }

  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    const { db } = await connectToDatabase();
    const dbUser = await db.collection<User>('users').findOne({ uid: decodedToken.uid });

    return {
      uid: decodedToken.uid,
      phone: decodedToken.phone_number || dbUser?.phone || '',
      role: (dbUser?.role as UserRole) || 'customer',
      storeId: dbUser?.storeId,
    };
  } catch (err) {
    console.error('Token verification failed:', err);
    return null;
  }
}
