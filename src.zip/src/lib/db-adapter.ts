import { connectToDatabase } from './mongodb';
import { INITIAL_STORES, INITIAL_PRODUCTS } from './mock-data';
import { Store, StoreProduct, Order, User, Cart } from '@/types';

// In-memory fallback caches for zero-configuration instant local POC running
let memoryStores: Store[] = [...INITIAL_STORES];
let memoryProducts: StoreProduct[] = [...INITIAL_PRODUCTS];
let memoryOrders: Order[] = [];
let memoryUsers: User[] = [];
let memoryCarts: Record<string, Cart> = {};

export async function getDatabase() {
  try {
    const { db } = await connectToDatabase();
    return db;
  } catch (err) {
    // Return null if MongoDB Atlas is not yet connected or in offline sandbox
    return null;
  }
}

// Stores helper
export async function dbGetStores(filter?: { city?: string; area?: string }) {
  const db = await getDatabase();
  if (db) {
    try {
      const query: any = {};
      if (filter?.city) query['location.city'] = { $regex: filter.city, $options: 'i' };
      if (filter?.area) query['location.area'] = { $regex: filter.area, $options: 'i' };
      return await db.collection<Store>('stores').find(query).toArray();
    } catch (e) {
      console.warn('MongoDB query error, using memory stores fallback');
    }
  }
  return memoryStores.filter(s => {
    if (filter?.city && !s.location.city.toLowerCase().includes(filter.city.toLowerCase())) return false;
    if (filter?.area && !s.location.area.toLowerCase().includes(filter.area.toLowerCase())) return false;
    return true;
  });
}

export async function dbGetStoreById(id: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<Store>('stores').findOne({ id });
    } catch (e) {
      console.warn('MongoDB query error, fallback');
    }
  }
  return memoryStores.find(s => s.id === id) || null;
}

export async function dbSaveStore(store: Store) {
  const db = await getDatabase();
  if (db) {
    try {
      await db.collection<Store>('stores').updateOne({ id: store.id }, { $set: store }, { upsert: true });
    } catch (e) {
      console.warn('MongoDB save store error');
    }
  }
  const idx = memoryStores.findIndex(s => s.id === store.id);
  if (idx >= 0) memoryStores[idx] = store;
  else memoryStores.push(store);
  return store;
}

// Products helper
export async function dbGetProductsByStore(storeId: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<StoreProduct>('store_products').find({ storeId }).toArray();
    } catch (e) {
      console.warn('MongoDB query products error');
    }
  }
  return memoryProducts.filter(p => p.storeId === storeId);
}

export async function dbGetProductById(id: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<StoreProduct>('store_products').findOne({ id });
    } catch (e) {
      console.warn('MongoDB query product error');
    }
  }
  return memoryProducts.find(p => p.id === id) || null;
}

export async function dbSaveProduct(product: StoreProduct) {
  const db = await getDatabase();
  if (db) {
    try {
      await db.collection<StoreProduct>('store_products').updateOne({ id: product.id }, { $set: product }, { upsert: true });
    } catch (e) {}
  }
  const idx = memoryProducts.findIndex(p => p.id === product.id);
  if (idx >= 0) memoryProducts[idx] = product;
  else memoryProducts.push(product);
  return product;
}

// Orders helper
export async function dbGetOrders(filter: { userId?: string; storeId?: string }) {
  const db = await getDatabase();
  if (db) {
    try {
      const q: any = {};
      if (filter.userId) q.userId = filter.userId;
      if (filter.storeId) q.storeId = filter.storeId;
      return await db.collection<Order>('orders').find(q).sort({ createdAt: -1 }).toArray();
    } catch (e) {}
  }
  return memoryOrders
    .filter(o => {
      if (filter.userId && o.userId !== filter.userId) return false;
      if (filter.storeId && o.storeId !== filter.storeId) return false;
      return true;
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function dbGetOrderById(id: string) {
  const db = await getDatabase();
  if (db) {
    try {
      return await db.collection<Order>('orders').findOne({ orderNumber: id }) || await db.collection<Order>('orders').findOne({ _id: id as any });
    } catch (e) {}
  }
  return memoryOrders.find(o => o.orderNumber === id || o._id === id) || null;
}

export async function dbSaveOrder(order: Order) {
  const db = await getDatabase();
  if (db) {
    try {
      await db.collection<Order>('orders').updateOne({ orderNumber: order.orderNumber }, { $set: order }, { upsert: true });
    } catch (e) {}
  }
  const idx = memoryOrders.findIndex(o => o.orderNumber === order.orderNumber);
  if (idx >= 0) memoryOrders[idx] = order;
  else memoryOrders.push(order);
  return order;
}

// Seed helper
export async function dbSeedInitialData() {
  const db = await getDatabase();
  if (db) {
    try {
      const storesCol = db.collection('stores');
      const productsCol = db.collection('store_products');
      
      for (const store of INITIAL_STORES) {
        await storesCol.updateOne({ id: store.id }, { $set: store }, { upsert: true });
      }
      for (const product of INITIAL_PRODUCTS) {
        await productsCol.updateOne({ id: product.id }, { $set: product }, { upsert: true });
      }
      return { success: true, message: 'Database seeded in MongoDB Atlas' };
    } catch (e) {
      console.warn('MongoDB Atlas seed failed, using in-memory initialization', e);
    }
  }
  memoryStores = [...INITIAL_STORES];
  memoryProducts = [...INITIAL_PRODUCTS];
  return { success: true, message: 'Seeded in-memory state' };
}
