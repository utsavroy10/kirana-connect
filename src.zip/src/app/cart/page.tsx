'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ShoppingBag,
  Clock,
  Trash2,
  Plus,
  Minus,
  Store,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  AlertCircle,
  Banknote
} from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { PickupSlot } from '@/types';

export default function CartPage() {
  const router = useRouter();
  const { cart, itemCount, itemTotal, updateQuantity, clearCart } = useCart();
  const { user, token } = useAuth();

  const [slots, setSlots] = useState<PickupSlot[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<PickupSlot | null>(null);
  const [customerName, setCustomerName] = useState<string>(user?.name || 'Aman Sharma');
  const [customerPhone, setCustomerPhone] = useState<string>(user?.phone || '+919811122233');
  const [customerNotes, setCustomerNotes] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  useEffect(() => {
    const fetchSlots = async () => {
      try {
        const res = await fetch('/api/pickup-slots');
        const data = await res.json();
        if (data.slots && data.slots.length > 0) {
          setSlots(data.slots);
          setSelectedSlot(data.slots[0]); // default to first available slot
        }
      } catch (e) {
        console.error('Failed to load slots', e);
      }
    };
    fetchSlots();
  }, []);

  useEffect(() => {
    if (user) {
      if (user.name) setCustomerName(user.name);
      if (user.phone) setCustomerPhone(user.phone);
    }
  }, [user]);

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cart || cart.items.length === 0) return;
    if (!selectedSlot) {
      setErrorMsg('Please select a pickup time slot');
      return;
    }
    if (!customerPhone.trim()) {
      setErrorMsg('Please provide a mobile contact number');
      return;
    }

    try {
      setSubmitting(true);
      setErrorMsg('');

      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      if (user?.uid) headers['x-user-id'] = user.uid;

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          storeId: cart.storeId,
          items: cart.items,
          itemTotal: cart.itemTotal,
          pickupSlot: selectedSlot,
          customerName,
          customerPhone,
          customerNotes,
          userId: user?.uid,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to place order');
      }

      // Clear cart upon successful order
      await clearCart();

      // Navigate to order tracking page
      router.push(`/orders/${data.order.orderNumber}`);
    } catch (err: any) {
      setErrorMsg(err.message || 'Something went wrong');
    } finally {
      setSubmitting(false);
    }
  };

  if (!cart || cart.items.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-slate-900">Your Cart is Empty</h2>
        <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
          Explore neighborhood kirana stores and add daily grocery essentials for quick pickup.
        </p>
        <Link
          href="/"
          className="mt-6 inline-flex items-center gap-2 bg-kirana-600 hover:bg-kirana-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-md transition-colors"
        >
          Browse Stores
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 pb-20">
      <div className="flex items-center justify-between pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">Order & Pickup Checkout</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Store: <strong className="text-slate-800">{cart.storeName || 'Selected Kirana'}</strong>
          </p>
        </div>

        <button
          onClick={clearCart}
          className="text-xs text-red-600 hover:text-red-700 font-semibold flex items-center gap-1"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Clear Cart
        </button>
      </div>

      {errorMsg && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {errorMsg}
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Items & Pickup Slot */}
        <div className="lg:col-span-7 space-y-6">
          {/* Cart Items list */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-sm">
            <h2 className="text-sm font-bold text-slate-800 mb-3 flex items-center justify-between">
              <span>Items to be packed ({itemCount})</span>
              <span className="text-xs font-normal text-slate-400">Single store order</span>
            </h2>

            <div className="divide-y divide-slate-100">
              {cart.items.map((item) => (
                <div key={item.productId} className="py-3 flex items-center justify-between gap-3">
                  <div className="flex-1">
                    <h3 className="text-xs font-bold text-slate-900 leading-snug">
                      {item.name}
                    </h3>
                    {item.hindiName && (
                      <p className="text-[11px] text-kirana-700">{item.hindiName}</p>
                    )}
                    <span className="text-[10px] text-slate-400">{item.unit}</span>
                    <div className="mt-1 text-xs font-bold text-slate-800">
                      ₹{item.price} <span className="font-normal text-slate-400">× {item.quantity} =</span> ₹{item.price * item.quantity}
                    </div>
                  </div>

                  {/* Quantity Stepper */}
                  <div className="flex items-center bg-slate-100 rounded-lg p-0.5">
                    <button
                      onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                      className="p-1 hover:bg-white rounded text-slate-600 transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="px-2 text-xs font-bold text-slate-800">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                      className="p-1 hover:bg-white rounded text-slate-600 transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pickup Slot Selection */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm">
            <h2 className="text-sm font-bold text-slate-800 mb-1 flex items-center gap-2">
              <Clock className="w-4 h-4 text-kirana-600" />
              Choose Pickup Time Slot
            </h2>
            <p className="text-xs text-slate-500 mb-3">
              The merchant will have your groceries packed ready before this time.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {slots.map((slot) => {
                const isSelected = selectedSlot?.id === slot.id;
                return (
                  <button
                    key={slot.id}
                    type="button"
                    onClick={() => setSelectedSlot(slot)}
                    className={`p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-kirana-50/80 border-kirana-600 ring-2 ring-kirana-500/20 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div>
                      <p className={`text-xs font-bold ${isSelected ? 'text-kirana-900' : 'text-slate-800'}`}>
                        {slot.label}
                      </p>
                      <span className="text-[10px] text-slate-500">Scheduled pickup</span>
                    </div>
                    {isSelected && (
                      <CheckCircle2 className="w-4 h-4 text-kirana-600 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Customer Details & Order Summary */}
        <div className="lg:col-span-5 space-y-6">
          <form onSubmit={handlePlaceOrder} className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-4">
            <h2 className="text-sm font-bold text-slate-800 pb-2 border-b border-slate-100">
              Pickup Contact Information
            </h2>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Your Name
              </label>
              <input
                type="text"
                required
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-kirana-500"
                placeholder="Enter full name"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Mobile Number (for pickup SMS & call)
              </label>
              <input
                type="tel"
                required
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-kirana-500 font-mono"
                placeholder="+919876543210"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Special packing note (Optional)
              </label>
              <input
                type="text"
                value={customerNotes}
                onChange={(e) => setCustomerNotes(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-kirana-500"
                placeholder="e.g. Please pack oil in separate polybag"
              />
            </div>

            {/* Payment Method Badge */}
            <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl">
              <div className="flex items-center gap-2">
                <Banknote className="w-4 h-4 text-amber-700 shrink-0" />
                <span className="text-xs font-bold text-amber-900">
                  Payment at Store on Pickup
                </span>
              </div>
              <p className="text-[11px] text-amber-700 mt-1">
                Pay ₹{itemTotal} directly at the counter via Cash or UPI (GPay/PhonePe/Paytm) after verifying your packed items.
              </p>
            </div>

            {/* Bill Summary */}
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <div className="flex justify-between text-xs text-slate-600">
                <span>Items Total</span>
                <span className="font-semibold text-slate-800">₹{itemTotal}</span>
              </div>
              <div className="flex justify-between text-xs text-slate-600">
                <span>Delivery & Convenience Fee</span>
                <span className="font-bold text-kirana-600">FREE (₹0)</span>
              </div>
              <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-2 border-t border-slate-100">
                <span>To Pay at Store</span>
                <span className="text-base text-kirana-700">₹{itemTotal}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full mt-4 bg-kirana-600 hover:bg-kirana-700 text-white font-extrabold text-sm py-3 rounded-xl shadow-lg shadow-kirana-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50"
            >
              {submitting ? 'Confirming Order...' : 'Confirm Pickup Order'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
