import { NextRequest, NextResponse } from 'next/server';
import { verifyAuthToken } from '@/lib/authMiddleware';
import { dbGetOrderById, dbSaveOrder } from '@/lib/db-adapter';
import { OrderStatus } from '@/types';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const order = await dbGetOrderById(params.id);
    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }
    return NextResponse.json({ order });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch order' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authUser = await verifyAuthToken(req);
    const order = await dbGetOrderById(params.id);

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }

    const body = await req.json();
    const { status, note, merchantNotes, paymentStatus } = body;

    // Check authorization: Admin or Merchant assigned to this store, or customer cancelling placed order
    if (authUser) {
      if (
        authUser.role === 'customer' &&
        authUser.uid === order.userId &&
        status === 'cancelled' &&
        order.status === 'placed'
      ) {
        // Customer can cancel only while placed
      } else if (
        authUser.role === 'merchant' &&
        authUser.storeId &&
        authUser.storeId !== order.storeId
      ) {
        return NextResponse.json({ error: 'Unauthorized to modify orders of another store' }, { status: 403 });
      }
    }

    const now = new Date().toISOString();
    const updatedStatusHistory = [...order.statusHistory];

    if (status && status !== order.status) {
      updatedStatusHistory.push({
        status: status as OrderStatus,
        timestamp: now,
        note: note || `Status updated to ${status.replace('_', ' ')}`,
      });
      order.status = status as OrderStatus;
    }

    if (paymentStatus) {
      order.payment.status = paymentStatus;
      if (paymentStatus === 'COLLECTED') {
        order.payment.collectedAt = now;
      }
    }

    if (merchantNotes !== undefined) {
      order.merchantNotes = merchantNotes;
    }

    order.statusHistory = updatedStatusHistory;
    order.updatedAt = now;

    const saved = await dbSaveOrder(order);
    return NextResponse.json({ order: saved });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update order status' }, { status: 500 });
  }
}
