import { NextRequest, NextResponse } from 'next/server';
import { dbSeedInitialData } from '@/lib/db-adapter';

export async function POST(req: NextRequest) {
  try {
    const result = await dbSeedInitialData();
    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Seed failed' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const result = await dbSeedInitialData();
    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Seed failed' }, { status: 500 });
  }
}
