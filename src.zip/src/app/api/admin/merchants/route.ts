import { NextRequest, NextResponse } from 'next/server';
import { verifyAuthToken } from '@/lib/authMiddleware';
import { dbGetStores, dbSaveStore } from '@/lib/db-adapter';

export async function GET(req: NextRequest) {
  try {
    const authUser = await verifyAuthToken(req);
    if (!authUser || authUser.role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized. Admin access required' }, { status: 403 });
    }

    const stores = await dbGetStores();
    return NextResponse.json({ merchants: stores });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch merchants' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const authUser = await verifyAuthToken(req);
    if (!authUser || authUser.role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized. Admin access required' }, { status: 403 });
    }

    const body = await req.json();
    const { storeId, isVerified, isOpen, commissionRate } = body;

    const stores = await dbGetStores();
    const targetStore = stores.find(s => s.id === storeId);
    if (!targetStore) {
      return NextResponse.json({ error: 'Store not found' }, { status: 404 });
    }

    if (isVerified !== undefined) targetStore.isVerified = isVerified;
    if (isOpen !== undefined) targetStore.isOpen = isOpen;
    if (commissionRate !== undefined) targetStore.commissionRate = commissionRate;
    targetStore.updatedAt = new Date().toISOString();

    const saved = await dbSaveStore(targetStore);
    return NextResponse.json({ merchant: saved });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update merchant' }, { status: 500 });
  }
}
