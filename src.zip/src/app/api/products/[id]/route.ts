import { NextRequest, NextResponse } from 'next/server';
import { dbGetProductById, dbSaveProduct } from '@/lib/db-adapter';
import { verifyAuthToken } from '@/lib/authMiddleware';

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authUser = await verifyAuthToken(req);
    if (!authUser) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const product = await dbGetProductById(params.id);
    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 });
    }

    if (authUser.role !== 'admin' && authUser.storeId !== product.storeId) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json();
    const updated = {
      ...product,
      ...body,
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveProduct(updated);
    return NextResponse.json({ product: saved });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update product' }, { status: 500 });
  }
}
