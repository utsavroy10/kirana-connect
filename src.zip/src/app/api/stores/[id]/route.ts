import { NextRequest, NextResponse } from 'next/server';
import { dbGetStoreById, dbSaveStore } from '@/lib/db-adapter';
import { verifyAuthToken } from '@/lib/authMiddleware';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const store = await dbGetStoreById(params.id);
    if (!store) {
      return NextResponse.json({ error: 'Store not found' }, { status: 404 });
    }
    return NextResponse.json({ store });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch store' }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authUser = await verifyAuthToken(req);
    if (!authUser || (authUser.role !== 'admin' && authUser.storeId !== params.id)) {
      return NextResponse.json({ error: 'Unauthorized to update this store' }, { status: 403 });
    }

    const store = await dbGetStoreById(params.id);
    if (!store) {
      return NextResponse.json({ error: 'Store not found' }, { status: 404 });
    }

    const body = await req.json();
    const updatedStore = {
      ...store,
      ...body,
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveStore(updatedStore);
    return NextResponse.json({ store: saved });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update store' }, { status: 500 });
  }
}
