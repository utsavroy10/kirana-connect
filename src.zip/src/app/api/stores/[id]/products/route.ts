import { NextRequest, NextResponse } from 'next/server';
import { dbGetProductsByStore, dbSaveProduct } from '@/lib/db-adapter';
import { verifyAuthToken } from '@/lib/authMiddleware';
import { StoreProduct } from '@/types';

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const products = await dbGetProductsByStore(params.id);
    return NextResponse.json({ products });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch products' }, { status: 500 });
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const authUser = await verifyAuthToken(req);
    if (!authUser || (authUser.role !== 'admin' && authUser.storeId !== params.id)) {
      return NextResponse.json({ error: 'Unauthorized to add product to this store' }, { status: 403 });
    }

    const body = await req.json();
    const newProduct: StoreProduct = {
      ...body,
      id: body.id || `prod_${Date.now()}`,
      storeId: params.id,
      inStock: body.inStock !== undefined ? body.inStock : true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveProduct(newProduct);
    return NextResponse.json({ product: saved }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to create product' }, { status: 500 });
  }
}
