import { NextRequest, NextResponse } from 'next/server';
import { dbGetStores, dbSaveStore } from '@/lib/db-adapter';
import { verifyAuthToken } from '@/lib/authMiddleware';
import { Store } from '@/types';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const city = searchParams.get('city') || undefined;
    const area = searchParams.get('area') || undefined;

    const stores = await dbGetStores({ city, area });
    return NextResponse.json({ stores });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch stores' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authUser = await verifyAuthToken(req);
    if (!authUser || (authUser.role !== 'admin' && authUser.role !== 'merchant')) {
      return NextResponse.json({ error: 'Unauthorized. Admin or Merchant role required' }, { status: 403 });
    }

    const body = await req.json();
    const newStore: Store = {
      ...body,
      id: body.id || `store_${Date.now()}`,
      merchantUid: authUser.uid,
      isVerified: authUser.role === 'admin' ? true : false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = await dbSaveStore(newStore);
    return NextResponse.json({ store: saved }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to create store' }, { status: 500 });
  }
}
