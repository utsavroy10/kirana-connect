import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/mongodb';
import { User } from '@/types';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { uid, phone, name, role = 'customer', storeId } = body;

    if (!uid) {
      return NextResponse.json({ error: 'User UID is required' }, { status: 400 });
    }

    const userData: User = {
      uid,
      phone: phone || '',
      name: name || 'Kirana Customer',
      role: role || 'customer',
      storeId: storeId || (role === 'merchant' ? 'store_shree_ram' : undefined),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      const { db } = await connectToDatabase();
      await db.collection('users').updateOne(
        { uid },
        { 
          $set: {
            phone: userData.phone,
            name: userData.name,
            role: userData.role,
            storeId: userData.storeId,
            updatedAt: userData.updatedAt,
          },
          $setOnInsert: {
            createdAt: userData.createdAt,
          }
        },
        { upsert: true }
      );
      
      const savedUser = await db.collection('users').findOne({ uid });
      return NextResponse.json({ user: savedUser || userData });
    } catch (dbErr) {
      // In-memory fallback
      return NextResponse.json({ user: userData });
    }
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Internal Server Error' }, { status: 500 });
  }
}
