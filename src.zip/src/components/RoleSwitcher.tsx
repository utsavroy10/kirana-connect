'use client';

import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'next/navigation';
import { UserRole } from '@/types';

export const RoleSwitcher: React.FC = () => {
  const { role, user, loginWithDemo, logout } = useAuth();
  const router = useRouter();

  const handleRoleChange = (newRole: UserRole) => {
    loginWithDemo(newRole);
    if (newRole === 'merchant') {
      router.push('/merchant');
    } else if (newRole === 'admin') {
      router.push('/admin');
    } else {
      router.push('/');
    }
  };

  return (
    <div className="bg-slate-900 text-white text-xs px-3 py-1.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
      <div className="flex items-center gap-2">
        <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase tracking-wider">
          POC Mode
        </span>
        <span className="text-slate-300 hidden sm:inline">Active Role:</span>
        <span className="font-semibold text-kirana-500 capitalize">{role}</span>
        {user && <span className="text-slate-400">({user.name || user.phone})</span>}
      </div>

      <div className="flex items-center gap-1.5">
        <span className="text-slate-400 text-[11px] mr-1 hidden sm:inline">Switch Persona:</span>
        <button
          onClick={() => handleRoleChange('customer')}
          className={`px-2.5 py-0.5 rounded font-medium transition-all ${
            role === 'customer'
              ? 'bg-kirana-600 text-white shadow-sm'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
          }`}
        >
          Customer
        </button>
        <button
          onClick={() => handleRoleChange('merchant')}
          className={`px-2.5 py-0.5 rounded font-medium transition-all ${
            role === 'merchant'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
          }`}
        >
          Merchant (Gupta Kirana)
        </button>
        <button
          onClick={() => handleRoleChange('admin')}
          className={`px-2.5 py-0.5 rounded font-medium transition-all ${
            role === 'admin'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
          }`}
        >
          Admin
        </button>
      </div>
    </div>
  );
};
