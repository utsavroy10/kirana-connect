'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Cart, CartItem, StoreProduct } from '@/types';
import { useAuth } from './AuthContext';

interface CartContextType {
  cart: Cart | null;
  itemCount: number;
  itemTotal: number;
  loading: boolean;
  addToCart: (product: StoreProduct, qtyDelta?: number) => Promise<boolean>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  getItemQuantity: (productId: string) => number;
  conflictModal: {
    isOpen: boolean;
    currentStoreName: string;
    pendingProduct: StoreProduct | null;
  };
  resolveConflict: (discardAndAdd: boolean) => Promise<void>;
}

const CartContext = createContext<CartContextType>({
  cart: null,
  itemCount: 0,
  itemTotal: 0,
  loading: false,
  addToCart: async () => false,
  updateQuantity: async () => {},
  clearCart: async () => {},
  getItemQuantity: () => 0,
  conflictModal: { isOpen: false, currentStoreName: '', pendingProduct: null },
  resolveConflict: async () => {},
});

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, token } = useAuth();
  const [cart, setCart] = useState<Cart | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [conflictModal, setConflictModal] = useState<{
    isOpen: boolean;
    currentStoreName: string;
    pendingProduct: StoreProduct | null;
  }>({
    isOpen: false,
    currentStoreName: '',
    pendingProduct: null,
  });

  // Fetch cart
  const fetchCart = async () => {
    try {
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;
      if (user?.uid) headers['x-user-id'] = user.uid;

      const res = await fetch('/api/cart', { headers });
      if (res.ok) {
        const data = await res.json();
        setCart(data.cart);
      }
    } catch (e) {
      console.error('Fetch cart failed', e);
    }
  };

  useEffect(() => {
    fetchCart();
  }, [user, token]);

  const addToCart = async (product: StoreProduct, qtyDelta: number = 1): Promise<boolean> => {
    const currentQty = getItemQuantity(product.id);
    const newQty = currentQty + qtyDelta;

    // Check client-side single store rule
    if (cart && cart.items.length > 0 && cart.storeId && cart.storeId !== product.storeId) {
      setConflictModal({
        isOpen: true,
        currentStoreName: cart.storeName || 'another store',
        pendingProduct: product,
      });
      return false;
    }

    return await sendCartUpdate(product.id, newQty);
  };

  const updateQuantity = async (productId: string, quantity: number) => {
    await sendCartUpdate(productId, quantity);
  };

  const sendCartUpdate = async (productId: string, quantity: number, clearPrevious: boolean = false): Promise<boolean> => {
    try {
      setLoading(true);
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      if (user?.uid) headers['x-user-id'] = user.uid;

      const res = await fetch('/api/cart', {
        method: 'POST',
        headers,
        body: JSON.stringify({ productId, quantity, clearPrevious }),
      });

      const data = await res.json();
      if (res.status === 409) {
        // Backend detected store mismatch
        setConflictModal({
          isOpen: true,
          currentStoreName: data.currentStoreName || 'Current Store',
          pendingProduct: null,
        });
        return false;
      }

      if (res.ok) {
        setCart(data.cart);
        return true;
      }
      return false;
    } catch (e) {
      console.error('Update cart failed', e);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const clearCart = async () => {
    try {
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;
      if (user?.uid) headers['x-user-id'] = user.uid;

      const res = await fetch('/api/cart', {
        method: 'DELETE',
        headers,
      });
      if (res.ok) {
        const data = await res.json();
        setCart(data.cart);
      }
    } catch (e) {
      console.error('Clear cart failed', e);
    }
  };

  const resolveConflict = async (discardAndAdd: boolean) => {
    if (discardAndAdd && conflictModal.pendingProduct) {
      const prod = conflictModal.pendingProduct;
      setConflictModal({ isOpen: false, currentStoreName: '', pendingProduct: null });
      await sendCartUpdate(prod.id, 1, true);
    } else {
      setConflictModal({ isOpen: false, currentStoreName: '', pendingProduct: null });
    }
  };

  const getItemQuantity = (productId: string): number => {
    if (!cart || !cart.items) return 0;
    const item = cart.items.find(it => it.productId === productId);
    return item ? item.quantity : 0;
  };

  const itemCount = cart?.items ? cart.items.reduce((sum, it) => sum + it.quantity, 0) : 0;
  const itemTotal = cart?.itemTotal || 0;

  return (
    <CartContext.Provider
      value={{
        cart,
        itemCount,
        itemTotal,
        loading,
        addToCart,
        updateQuantity,
        clearCart,
        getItemQuantity,
        conflictModal,
        resolveConflict,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
